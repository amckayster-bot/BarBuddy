// Metro's newer "package exports" resolution mode can conflict with how
// some Expo packages structure their package.json "exports" field for web.
// Disabling it is the standard first workaround, but in this project it
// didn't change the outcome for expo-asset specifically (confirmed: Node's
// own fs.readFileSync/readdirSync see the file completely fine — this is a
// Metro-resolver-specific quirk, not a filesystem issue). Keeping this off
// regardless since it's still a safer default.
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);
config.resolver.unstable_enablePackageExports = false;

// Targeted override: Metro's resolver was failing to resolve the bare
// `expo-asset` specifier (imported by expo-font/build/FontLoader.web.js)
// even though the target file verifiably exists and reads fine via plain
// Node fs calls. Hard-resolving it to its known real path sidesteps
// whatever in Metro's own main/exports resolution logic is going wrong,
// without needing to fully root-cause Metro's internals.
const originalResolveRequest = config.resolver.resolveRequest;
config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName === 'expo-asset') {
    return {
      type: 'sourceFile',
      filePath: path.resolve(__dirname, 'node_modules/expo/node_modules/expo-asset/build/index.js'),
    };
  }
  if (originalResolveRequest) {
    return originalResolveRequest(context, moduleName, platform);
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
