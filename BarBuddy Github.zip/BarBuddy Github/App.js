import { Platform, StyleSheet, View } from 'react-native';
import RootNavigator from './src/navigation/RootNavigator';
import { colors } from './src/theme/colors';
import { ScreenSizeContext } from './src/theme/screenSize';

const PHONE_FRAME_WIDTH = 390;
const PHONE_FRAME_HEIGHT = 844;
const PHONE_FRAME_BORDER = 8;
const PHONE_FRAME_CONTENT_SIZE = {
  width: PHONE_FRAME_WIDTH - PHONE_FRAME_BORDER * 2,
  height: PHONE_FRAME_HEIGHT - PHONE_FRAME_BORDER * 2,
};

// On web (desktop preview), constrain to a real iPhone size so it looks like
// a phone screen instead of a stretched webpage. On an actual device via
// Expo Go, the app just fills the real screen as normal.
export default function App() {
  if (Platform.OS === 'web') {
    return (
      <View style={styles.webBackdrop}>
        <View style={styles.phoneFrame}>
          <ScreenSizeContext.Provider value={PHONE_FRAME_CONTENT_SIZE}>
            <RootNavigator />
          </ScreenSizeContext.Provider>
        </View>
      </View>
    );
  }

  return <RootNavigator />;
}

const styles = StyleSheet.create({
  webBackdrop: {
    flex: 1,
    minHeight: '100vh',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#000',
  },
  phoneFrame: {
    width: PHONE_FRAME_WIDTH,
    height: PHONE_FRAME_HEIGHT,
    borderRadius: 40,
    overflow: 'hidden',
    borderWidth: PHONE_FRAME_BORDER,
    borderColor: '#1a1a1a',
    backgroundColor: colors.navyBase,
  },
});
