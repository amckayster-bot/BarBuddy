// SwipeableTabs.js
//
// Custom swipeable page container for the 5 main tabs — replaces
// React Navigation's bottom-tabs navigator, which switches tabs with an
// instant cut and has no built-in swipe gesture. There's no paging/gesture
// library installed in this project (no react-native-pager-view, no
// reanimated/gesture-handler), so this is built from RN core only:
// PanResponder for the drag, and the same plain
// requestAnimationFrame-driven "elapsed time -> React state -> style"
// pattern used everywhere else in this app (see
// AnimatedGradientBackground.js's animation-driver note) for the settle
// animation — RN's `Animated` API is confirmed broken in this exact Expo
// SDK setup, so it's never used for motion here.
//
// All 5 tab screens are rendered side by side in one wide row and slid via
// a single `transform: translateX` — dragging follows the finger 1:1, and
// on release the page settles to whichever tab the drag/velocity implies,
// with the settle *speed* scaled to how fast the release was (a hard flick
// snaps quickly; a slow drag-and-release settles at a normal pace) — that's
// the "follows the speed and velocity of the user" ask. Since all 5 stay
// mounted simultaneously (needed so the adjacent page is actually there to
// slide into view), each one keeps its own state across tab switches, same
// as React Navigation's default tab behavior.
//
// Nested-horizontal-scroll note: a couple of tabs have their own horizontal
// ScrollViews inside them (Near You's carousel on Home; the category pill
// row on Search has the same shape but is left untouched here per explicit
// instruction). Rather than try to arbitrate that with dx/dy thresholds
// (which was the original approach here, and was still letting page-swipes
// win when dragging across the carousel), those inner scrollers now report
// "I'm currently handling a touch" via a plain ref (see
// innerScrollActiveRef / setInnerScrollActive below, exposed through
// TabPagerContext) as soon as a touch lands on them — onTouchStart/onTouchEnd
// fire immediately on touch, ahead of our PanResponder's move-based
// shouldSet check, so by the time that check runs it can just defer
// entirely to the inner scroller for the rest of that gesture. No
// react-native-gesture-handler needed, but this is still a ref-based side
// channel rather than a first-class arbitration system — if more nested
// scrollers show up later, they need to opt into the same pattern.
//
// Perf note: all 5 tab screens stay mounted (so the adjacent page is there
// to slide into view), each with its own animated gradient background and
// scroll content. Without memoizing them, every onPanResponderMove call
// during a drag (fired continuously, ~60/s) re-rendered this component and,
// because plain child components always re-render along with their parent,
// re-rendered all 5 full tab trees on every single frame of the drag — that
// was the actual source of the "laggy" swipe, not the animation math
// itself. TabPage below is memoized with no props that change during a
// drag (translateX lives on the ancestor `track` View's style only), so a
// drag now only re-renders the cheap outer Views, not the tab content.
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PanResponder, StyleSheet, View } from 'react-native';
import { useScreenWidth } from '../theme/screenSize';
import { TabPagerContext } from '../context/TabPagerContext';
import { TAB_ROUTES } from './tabRoutes';
import BottomNav from '../components/BottomNav';

const TabPage = memo(function TabPage({ Screen }) {
  return <Screen />;
});

// How far (as a fraction of screen width) a drag has to travel before it
// counts as "far enough" to change pages on release, even without a fast
// flick.
const DISTANCE_RATIO = 0.32;
// How fast (px/ms) a release has to be moving to count as a deliberate
// flick, changing pages even on a short drag.
const VELOCITY_THRESHOLD = 0.35;
// Settle duration is distance / speed, clamped to this range — fast flicks
// still take a little time (feels intentional, not instant-teleport), slow
// releases still settle promptly rather than drifting forever.
const SETTLE_MIN_MS = 180;
const SETTLE_MAX_MS = 420;
// How much a drag past the first/last page resists, so hitting the edge
// feels like a soft rubber-band rather than a hard wall.
const EDGE_RESISTANCE = 0.35;

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

export default function SwipeableTabs() {
  const width = useScreenWidth();
  const count = TAB_ROUTES.length;
  const [activeIndex, setActiveIndex] = useState(0);
  const [renderX, setRenderX] = useState(0);

  const xRef = useRef(0); // current visual translateX, source of truth for the gesture math
  const gestureStartXRef = useRef(0);
  const activeIndexRef = useRef(0); // mirrors activeIndex in a ref so the PanResponder closure always reads the latest value
  const animRafRef = useRef(null);
  // True while a touch is currently down on a nested horizontal scroller
  // (see the file-level nested-horizontal-scroll note) — read by the
  // PanResponder below to fully bow out of gestures that belong to that
  // scroller instead of racing it for the page-swipe.
  const innerScrollActiveRef = useRef(false);
  const setInnerScrollActive = useCallback((active) => {
    innerScrollActiveRef.current = active;
  }, []);

  useEffect(() => {
    activeIndexRef.current = activeIndex;
  }, [activeIndex]);

  const baseXFor = useCallback((index) => -index * width, [width]);

  const stopAnim = useCallback(() => {
    if (animRafRef.current) cancelAnimationFrame(animRafRef.current);
    animRafRef.current = null;
  }, []);

  // velocityPxPerMs comes straight from the gesture (0 for a programmatic
  // jump, e.g. a BottomNav tap) — the higher it is, the faster the settle,
  // which is what makes a hard flick feel like it's still carrying its own
  // momentum into the snap rather than every transition taking the same
  // fixed duration regardless of how the user released it.
  //
  // Stabilized with useCallback (along with goToIndex/goToName below) so
  // BottomNav — memoized in BottomNav.js — actually gets to skip re-renders
  // during a drag instead of receiving a new onIndexChange function
  // identity every frame.
  const animateTo = useCallback((targetIndex, velocityPxPerMs = 0) => {
    stopAnim();
    const from = xRef.current;
    const to = baseXFor(targetIndex);
    const distance = Math.abs(to - from);
    const speed = Math.max(0.35, Math.min(1.8, Math.abs(velocityPxPerMs) || 0.7));
    const duration = distance === 0 ? 0 : Math.max(SETTLE_MIN_MS, Math.min(SETTLE_MAX_MS, distance / speed));

    if (duration === 0) {
      xRef.current = to;
      setRenderX(to);
      setActiveIndex(targetIndex);
      return;
    }

    let startTs = null;
    const step = (ts) => {
      if (startTs == null) startTs = ts;
      const t = Math.min(1, (ts - startTs) / duration);
      const eased = easeOutCubic(t);
      const x = from + (to - from) * eased;
      xRef.current = x;
      setRenderX(x);
      if (t < 1) {
        animRafRef.current = requestAnimationFrame(step);
      } else {
        xRef.current = to;
        setRenderX(to);
        setActiveIndex(targetIndex);
      }
    };
    animRafRef.current = requestAnimationFrame(step);
  }, [baseXFor, stopAnim]);

  const goToIndex = useCallback(
    (index) => {
      animateTo(Math.max(0, Math.min(count - 1, index)));
    },
    [animateTo, count]
  );

  const goToName = useCallback(
    (name) => {
      const idx = TAB_ROUTES.findIndex((r) => r.name === name);
      if (idx >= 0) goToIndex(idx);
    },
    [goToIndex]
  );

  useEffect(() => () => stopAnim(), []);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        // Deliberately NOT using the Capture variants — those fire before
        // children get a look at the touch at all, which would break every
        // button/scrollview in every tab. Using the bubbling
        // onMoveShouldSetPanResponder means a child (a Pressable, a
        // vertical ScrollView, an inner horizontal ScrollView) gets first
        // opportunity to claim the gesture for itself; this only takes
        // over once movement is clearly horizontal and past a real
        // threshold — see the file-level "Known limitation" note.
        onMoveShouldSetPanResponder: (_, g) =>
          !innerScrollActiveRef.current && Math.abs(g.dx) > 10 && Math.abs(g.dx) > Math.abs(g.dy) * 2,
        onPanResponderGrant: () => {
          stopAnim();
          gestureStartXRef.current = xRef.current;
        },
        onPanResponderMove: (_, g) => {
          let next = gestureStartXRef.current + g.dx;
          const max = baseXFor(0);
          const min = baseXFor(count - 1);
          if (next > max) next = max + (next - max) * EDGE_RESISTANCE;
          if (next < min) next = min + (next - min) * EDGE_RESISTANCE;
          xRef.current = next;
          setRenderX(next);
        },
        onPanResponderRelease: (_, g) => {
          const current = activeIndexRef.current;
          const from = baseXFor(current);
          const delta = xRef.current - from; // negative = dragged toward the next tab
          const farEnough = Math.abs(delta) > width * DISTANCE_RATIO;
          const fastEnough = Math.abs(g.vx) > VELOCITY_THRESHOLD;

          let target = current;
          if (delta < 0 && (farEnough || (fastEnough && g.vx < 0))) {
            target = current + 1;
          } else if (delta > 0 && (farEnough || (fastEnough && g.vx > 0))) {
            target = current - 1;
          }
          target = Math.max(0, Math.min(count - 1, target));
          animateTo(target, Math.abs(g.vx));
        },
        onPanResponderTerminate: () => {
          animateTo(activeIndexRef.current);
        },
      }),
    [count, width]
  );

  const ctxValue = useMemo(
    () => ({ activeIndex, goToIndex, goToName, setInnerScrollActive }),
    [activeIndex, setInnerScrollActive]
  );

  return (
    <TabPagerContext.Provider value={ctxValue}>
      <View style={styles.fill}>
        <View style={styles.clip}>
          <View
            {...panResponder.panHandlers}
            style={[styles.track, { width: width * count, transform: [{ translateX: renderX }] }]}
          >
            {TAB_ROUTES.map((route) => (
              <View key={route.name} style={{ width }}>
                <TabPage Screen={route.component} />
              </View>
            ))}
          </View>
        </View>
        <BottomNav activeIndex={activeIndex} onIndexChange={goToIndex} />
      </View>
    </TabPagerContext.Provider>
  );
}

const styles = StyleSheet.create({
  fill: {
    flex: 1,
  },
  clip: {
    flex: 1,
    overflow: 'hidden',
  },
  track: {
    flex: 1,
    flexDirection: 'row',
  },
});
