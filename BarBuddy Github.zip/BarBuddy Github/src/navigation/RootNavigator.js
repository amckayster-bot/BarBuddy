import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SwipeableTabs from './SwipeableTabs';
import VenueDetailScreen from '../screens/VenueDetailScreen';
import MapScreen from '../screens/MapScreen';
import { SearchFilterProvider } from '../context/SearchFilterContext';

const Stack = createNativeStackNavigator();

// The 5 main tabs (Home/Search/ForYou/Events/Assistant) used to be a real
// `@react-navigation/bottom-tabs` navigator. That's been replaced with
// SwipeableTabs — a custom pager supporting velocity-following swipe
// left/right between tabs, which bottom-tabs has no built-in support for
// (see SwipeableTabs.js for the full reasoning/tradeoffs). It's still
// mounted as a single Stack.Screen here, so VenueDetail/Map pushing over it
// and covering the tab bar works exactly as before.
//
// VenueDetail is a root-level stack screen (not nested in the tabs) so it
// covers the tab bar entirely when pushed — matches the mockup, which has
// its own sticky action bar as the bottom UI instead.
export default function RootNavigator() {
  return (
    <SafeAreaProvider>
      {/* Wraps everything (not just the tabs) so any future screen — not
          only Home and Search — can read/drive the same category filters
          without re-plumbing this later. */}
      <SearchFilterProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="MainTabs" component={SwipeableTabs} />
            <Stack.Screen name="VenueDetail" component={VenueDetailScreen} />
            <Stack.Screen name="Map" component={MapScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </SearchFilterProvider>
    </SafeAreaProvider>
  );
}
