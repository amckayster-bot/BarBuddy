// "Late City Minimal" design tokens — approved, see project CLAUDE.md.
export const colors = {
  navyBase: '#0C0F16',
  navySurface: '#171B24',
  amber: '#E3A857',
  textPrimary: '#F5F3EF',
  textMuted: '#8A8F9C',
  border: '#2A2F3A',

  // Aurora nebula accent blobs (background only — see AnimatedGradientBackground.js).
  // Deliberately distinct hues from `amber`: amber stays reserved for
  // functional "happening now" signals and must never appear decoratively.
  nebulaRed: '#C7323D',
  nebulaOrange: '#D9601C',

  // Rating badge scale (Top Ten list) — a different functional signal from
  // amber, so it gets its own tokens rather than borrowing amber's hex.
  ratingRed: '#E5484D',
  ratingOrange: '#FF8A3D',
  ratingYellow: '#F0B429',
  ratingGreen: '#4CD37A',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 30,
};
