import { createContext, useContext } from 'react';
import { Dimensions } from 'react-native';

// App.js knows the exact content size on web (the phone-frame is a fixed
// size), so it provides that directly instead of components trying to
// measure it themselves — onLayout wasn't resolving reliably in this setup.
// On native there's no frame constraint, so this falls back to the real
// window size.
export const ScreenSizeContext = createContext(null);

export function useScreenSize() {
  const provided = useContext(ScreenSizeContext);
  return provided ?? Dimensions.get('window');
}

export function useScreenWidth() {
  return useScreenSize().width;
}
