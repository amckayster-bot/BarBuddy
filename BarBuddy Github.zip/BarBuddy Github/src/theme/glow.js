// glow.js
//
// Shared "colored halo" shadow helper for active/selected pills (category
// filter chips, mainly). Kept intentionally subtle by default — a soft hint
// of the category's accent color around the pill, not a heavy neon blur —
// per feedback that the original glow was too strong. `shadowOffset:
// {0,0}` is what keeps the halo symmetric on every side rather than reading
// as a directional drop shadow.
//
// Note: iOS shadows need room to render outside the element's own layout
// box — a parent that tightly bounds its children (e.g. a horizontal
// ScrollView sized to exactly its content's height) will clip the glow on
// whichever edges have no extra padding. Callers should leave a few pixels
// of padding around anything using this.
export function glow(color, { opacity = 0.35, radius = 5 } = {}) {
  return {
    shadowColor: color,
    shadowOpacity: opacity,
    shadowRadius: radius,
    shadowOffset: { width: 0, height: 0 },
  };
}
