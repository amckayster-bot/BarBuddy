// searchCategories.js
//
// Category taxonomy for the Search tab, straight from the "Bar Buddy Search
// Screen" design import. Each top-level category has two accent colors:
// `color` (used for the small dot + label text in the expanded subcategory
// block header) and `fill` (used for the pill's own active border/
// background/glow, both at the top-level row and for its subcategory
// pills) — for most categories these are the same hue, but late-night-eats
// deliberately uses a brighter `color` for the header text/dot than the
// (duller, more legible-as-a-fill) `fill` used on the pills themselves.
export const CATEGORY_DEFS = [
  {
    key: 'bars',
    label: 'Bars',
    color: '#E15C3F',
    fill: '#E15C3F',
    subs: ['Dive Bars', 'Cocktail Bars', 'Sports Bars', 'Wine Bars', 'Rooftop Bars'],
  },
  {
    key: 'clubs',
    label: 'Clubs',
    color: '#D63E8F',
    fill: '#D63E8F',
    subs: ['Nightclubs', 'Dance Clubs', 'Latin Night', 'Hip-Hop & R&B'],
  },
  {
    key: 'lounges',
    label: 'Lounges',
    color: '#8B5CF6',
    fill: '#8B5CF6',
    subs: ['Speakeasies', 'Hookah Lounges', 'Cigar Lounges', 'Hotel Lounges'],
  },
  {
    key: 'breweries',
    label: 'Breweries & Taprooms',
    color: '#8B5A34',
    fill: '#8B5A34',
    subs: ['Craft Breweries', 'Taprooms', 'Beer Gardens', 'Cideries'],
  },
  {
    key: 'live-music',
    label: 'Live Music Venues',
    color: '#3E8EDE',
    fill: '#3E8EDE',
    subs: ['Concert Halls', 'Jazz Clubs', 'Karaoke Bars', 'Open Mic Nights'],
  },
  {
    key: 'late-night-eats',
    label: 'Late-Night Eats',
    color: '#D9C23A',
    fill: '#9C8C2A',
    subs: ['Diners', 'Pizza', 'Food Trucks', 'Late-Night Delivery'],
  },
  {
    key: 'arcades',
    label: 'Arcades & Game Bars',
    color: '#33B8C4',
    fill: '#2A97A1',
    subs: ['Retro Arcades', 'Bowling & Arcades', 'Pool Halls', 'Board Game Bars'],
  },
];
