// useBreathingGlow.js
//
// Drives a slow, continuous "breathing" pulse for an active pill/button's
// glow — shadowOpacity and shadowRadius gently rise and fall in a loop
// instead of sitting at a fixed value, so an active category button reads
// as alive/pressable rather than just statically highlighted. The larger
// shadowRadius swing also doubles as the "edge blur" look (native shadow
// blur is what's rendering that softness — this app never uses RN's
// `filter: blur` style, since that renders as an opaque gray box on real
// iOS devices under this Expo SDK/New Architecture combo; see
// AnimatedGradientBackground.js for the fuller writeup of that bug).
//
// `flicker: true` layers real neon-sign-style flicker on top of the
// breathing wave: every several seconds, a short burst of 2-4 quick,
// irregular stutters (a genuine neon tube doesn't dip smoothly once — it
// stutters a few times in a row, at uneven depths and gaps, then holds
// steady again). Sequences are infrequent and each one is over in well
// under half a second, so it reads as "this sign has a little character"
// rather than something distracting to look at while browsing. Off by
// default; opt in per caller.
//
// Runs its own requestAnimationFrame loop only while `active` is true, and
// tears it down the instant `active` goes false — same plain-RAF +
// elapsed-time pattern used everywhere else in this app, since RN's
// `Animated` API never progresses past its starting frame in this setup.
import { useEffect, useRef, useState } from 'react';

// Builds one flicker burst: a handful of brief dips back-to-back, each with
// its own depth and duration, separated by short flashes back to full
// brightness — the irregularity is what sells it as "neon", not a clean
// single blink. Returns { segments, totalMs } where each segment is a
// { start, end, mul } window (ms, relative to the burst's own start).
function buildFlickerBurst() {
  const stutterCount = 2 + Math.floor(Math.random() * 3); // 2-4 stutters
  let t = 0;
  const segments = [];
  for (let i = 0; i < stutterCount; i += 1) {
    // Brief full-brightness gap between stutters (skipped before the very
    // first one, so the burst starts immediately when triggered).
    t += i === 0 ? 0 : 15 + Math.random() * 45;
    const dipStart = t;
    const dipDur = 25 + Math.random() * 70;
    t += dipDur;
    segments.push({ start: dipStart, end: t, mul: 0.05 + Math.random() * 0.35 });
  }
  return { segments, totalMs: t + 20 };
}

export function useBreathingGlow(
  active,
  {
    minOpacity = 0.22,
    maxOpacity = 0.5,
    minRadius = 4,
    maxRadius = 11,
    periodMs = 1900,
    flicker = false,
  } = {}
) {
  const [phase, setPhase] = useState(0);
  const [flickerMul, setFlickerMul] = useState(1);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  // Elapsed-ms timestamp the next flicker burst should start at, and the
  // burst's own segment data once one is underway. Refs, not state — this
  // is bookkeeping the RAF loop reads/writes every frame, not something
  // that should trigger its own re-render.
  const nextBurstAtRef = useRef(null);
  const activeBurstRef = useRef(null); // { startedAt, segments, totalMs } | null

  useEffect(() => {
    if (!active) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      startRef.current = null;
      activeBurstRef.current = null;
      nextBurstAtRef.current = null;
      if (flicker) setFlickerMul(1);
      return undefined;
    }

    // First burst lands somewhere in the next 3-7s, then re-rolls a new
    // 4-9s gap after each one — random enough that side-by-side active
    // pills don't flicker in lockstep, and spaced out enough to stay a
    // subtle detail rather than a constant distraction.
    nextBurstAtRef.current = flicker ? 3000 + Math.random() * 4000 : null;

    const tick = (now) => {
      if (startRef.current == null) startRef.current = now;
      const elapsed = now - startRef.current;
      setPhase((elapsed % periodMs) / periodMs);

      if (flicker) {
        const burst = activeBurstRef.current;
        if (burst) {
          const t = elapsed - burst.startedAt;
          if (t >= burst.totalMs) {
            activeBurstRef.current = null;
            nextBurstAtRef.current = elapsed + 4000 + Math.random() * 5000;
            setFlickerMul(1);
          } else {
            const seg = burst.segments.find((s) => t >= s.start && t < s.end);
            setFlickerMul(seg ? seg.mul : 1);
          }
        } else if (nextBurstAtRef.current != null && elapsed >= nextBurstAtRef.current) {
          activeBurstRef.current = { startedAt: elapsed, ...buildFlickerBurst() };
        }
      }

      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [active, periodMs, flicker]);

  if (!active) {
    return { shadowOpacity: 0, shadowRadius: 0 };
  }

  // Cosine-based wave so the pulse eases at both the peak and the trough
  // (a linear triangle wave would feel mechanical, snapping direction at
  // the tips instead of breathing through them).
  const wave = 0.5 - 0.5 * Math.cos(phase * Math.PI * 2);
  const mul = flicker ? flickerMul : 1;

  return {
    shadowOpacity: (minOpacity + (maxOpacity - minOpacity) * wave) * mul,
    shadowRadius: (minRadius + (maxRadius - minRadius) * wave) * mul,
  };
}
