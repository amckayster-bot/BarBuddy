// SearchFilterContext.js
//
// Shared category-filter state for the Search feature, lifted out of
// SearchScreen so Home's "Need Inspiration?" chips can read/write the same
// active categories — tapping a chip on Home actually drives the Search
// tab's filters (rather than each screen keeping its own separate copy),
// and a category chip on either screen reflects the other's state.
//
// activeSubs shape: { [categoryKey]: [subLabel, ...] }
import { createContext, useCallback, useContext, useState } from 'react';

const SearchFilterContext = createContext(null);

export function SearchFilterProvider({ children }) {
  const [activeCategories, setActiveCategories] = useState([]);
  const [activeSubs, setActiveSubs] = useState({});

  const toggleCategory = useCallback((key) => {
    setActiveCategories((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
    setActiveSubs((prev) => {
      if (!prev[key]) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  // Turns a category on if it isn't already — never toggles it off. Used
  // for one-directional "make sure this filter is active" actions (Home's
  // chips ensure-activate rather than blindly toggle, so re-tapping an
  // already-active Home chip doesn't accidentally clear it out from under
  // someone mid-search).
  const ensureCategoryActive = useCallback((key) => {
    setActiveCategories((prev) => (prev.includes(key) ? prev : [...prev, key]));
  }, []);

  const toggleSub = useCallback((catKey, label) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      const on = current.includes(label);
      const next = on ? current.filter((l) => l !== label) : [...current, label];
      return { ...prev, [catKey]: next };
    });
  }, []);

  const ensureSubActive = useCallback((catKey, label) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      if (current.includes(label)) return prev;
      return { ...prev, [catKey]: [...current, label] };
    });
  }, []);

  // Explicit on/off setters (as opposed to toggleCategory/toggleSub, which
  // flip whatever the current state is). These exist for callers that need
  // to drive a category independently of a single toggle source — e.g.
  // Home's "Need Inspiration?" chips, where more than one chip can map to
  // the same underlying search category (Winery and Bars both drive
  // `bars`) and each chip needs to turn its own share of that category on
  // or off without stomping the other chip's contribution.
  const setCategoryActive = useCallback((key, isActive) => {
    setActiveCategories((prev) => {
      const has = prev.includes(key);
      if (isActive === has) return prev;
      return isActive ? [...prev, key] : prev.filter((k) => k !== key);
    });
    if (!isActive) {
      setActiveSubs((prev) => {
        if (!prev[key]) return prev;
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  }, []);

  const setSubActive = useCallback((catKey, label, isActive) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      const has = current.includes(label);
      if (isActive === has) return prev;
      const next = isActive ? [...current, label] : current.filter((l) => l !== label);
      return { ...prev, [catKey]: next };
    });
  }, []);

  const clearFilters = useCallback(() => {
    setActiveCategories([]);
    setActiveSubs({});
  }, []);

  const value = {
    activeCategories,
    activeSubs,
    toggleCategory,
    ensureCategoryActive,
    setCategoryActive,
    toggleSub,
    ensureSubActive,
    setSubActive,
    clearFilters,
  };

  return <SearchFilterContext.Provider value={value}>{children}</SearchFilterContext.Provider>;
}

export function useSearchFilters() {
  const ctx = useContext(SearchFilterContext);
  if (!ctx) {
    throw new Error('useSearchFilters must be used within a SearchFilterProvider');
  }
  return ctx;
}
