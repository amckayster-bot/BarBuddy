// TabPagerContext.js
//
// Lets any component reach the swipeable tab pager (SwipeableTabs.js)
// without needing a prop-drilled reference to it — e.g. Home's "Search"
// button (InspirationCategories) needs to jump straight to the Search tab,
// and Home's Near You carousel (NearYouSection) needs to tell the pager to
// stay out of the way of its own horizontal scroll (setInnerScrollActive —
// see the nested-horizontal-scroll note in SwipeableTabs.js). Kept in its
// own file with zero imports of screens/nav components so it can be
// imported from anywhere (including deep inside a tab screen) without
// risking a circular import back through SwipeableTabs -> tabRoutes ->
// the screens themselves.
import { createContext, useContext } from 'react';

export const TabPagerContext = createContext(null);

export function useTabPager() {
  const ctx = useContext(TabPagerContext);
  if (!ctx) {
    throw new Error('useTabPager must be used within SwipeableTabs');
  }
  return ctx;
}
