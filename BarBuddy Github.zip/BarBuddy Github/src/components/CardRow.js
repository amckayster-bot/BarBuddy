import { ScrollView, StyleSheet } from 'react-native';
import { spacing } from '../theme/colors';

// Bleeds past the parent section's 16px padding, then reapplies its own
// 16px gutter on the scrollable content itself — leading and trailing —
// so cards can scroll edge-to-edge while never sitting flush against it.
export default function CardRow({ children }) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={styles.bleed}
      contentContainerStyle={styles.content}
    >
      {children}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  bleed: {
    marginHorizontal: -spacing.lg,
  },
  content: {
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
});
