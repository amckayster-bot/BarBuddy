import { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';

// No real blur here either, same call as BottomNav — solid translucent bar.
//
// "I'm Going Tonight" interaction: tapping it pops a small firework burst
// of particles out from the button, then the whole bar (both pill buttons)
// slides down and fades out, disappearing. Driven by plain
// requestAnimationFrame + elapsed-time state rather than RN's `Animated`
// API — Animated was confirmed elsewhere in this project (see
// AnimatedGradientBackground.js's animation-driver note) to never actually
// progress past its starting frame in this exact Expo SDK 54 setup, on
// both web preview and native, so everything animated in this app uses
// this same manual RAF approach instead.
const FIREWORK_MS = 650;
const EXIT_MS = 420;
const PARTICLE_COUNT = 12;
const PARTICLE_COLORS = [colors.amber, colors.ratingYellow, colors.ratingOrange, colors.nebulaOrange, colors.textPrimary];

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

function easeInCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return c ** 3;
}

// One-shot burst config, generated fresh at click time (Math.random() here
// is fine — this only runs once per tap, not every render/frame).
function buildParticles() {
  return Array.from({ length: PARTICLE_COUNT }, (_, i) => {
    const angle = (i / PARTICLE_COUNT) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
    const distance = 34 + Math.random() * 30;
    return {
      angle,
      distance,
      size: 3 + Math.random() * 3,
      color: PARTICLE_COLORS[i % PARTICLE_COLORS.length],
      delay: Math.random() * 0.15, // as a fraction of FIREWORK_MS, so the burst isn't perfectly synchronized
    };
  });
}

export default function VenueActionBar() {
  // 'idle' -> 'fireworks' -> 'exiting' -> 'gone'
  const [phase, setPhase] = useState('idle');
  const [progress, setProgress] = useState(0); // 0..1 within the current phase
  const particles = useMemo(() => (phase === 'idle' ? [] : buildParticles()), [phase === 'idle']);
  const rafRef = useRef(null);

  useEffect(() => {
    if (phase !== 'fireworks' && phase !== 'exiting') return undefined;
    const duration = phase === 'fireworks' ? FIREWORK_MS : EXIT_MS;
    const start = performance.now ? performance.now() : Date.now();
    setProgress(0);

    const step = () => {
      const now = performance.now ? performance.now() : Date.now();
      const t = Math.min(1, (now - start) / duration);
      setProgress(t);
      if (t < 1) {
        rafRef.current = requestAnimationFrame(step);
      } else if (phase === 'fireworks') {
        setPhase('exiting');
      } else {
        setPhase('gone');
      }
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [phase]);

  if (phase === 'gone') return null;

  const handlePress = () => {
    if (phase !== 'idle') return;
    setPhase('fireworks');
  };

  const exitT = phase === 'exiting' ? easeInCubic(progress) : 0;
  const barStyle = {
    opacity: 1 - exitT,
    transform: [{ translateY: exitT * 60 }],
  };

  return (
    <View style={[styles.bar, barStyle]} pointerEvents={phase === 'idle' ? 'auto' : 'none'}>
      <View style={styles.goingWrap}>
        <Pressable
          onPress={handlePress}
          disabled={phase !== 'idle'}
          style={({ pressed }) => [styles.btn, styles.btnFilled, pressed && styles.btnPressed]}
        >
          <Svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke={colors.navyBase} strokeWidth={2}>
            <Path d="M20 6L9 17l-5-5" />
          </Svg>
          <Text style={styles.btnTextFilled}>I'm Going Tonight</Text>
        </Pressable>

        {phase === 'fireworks' && (
          <View style={styles.particleField} pointerEvents="none">
            {particles.map((p, i) => {
              const localT = Math.max(0, Math.min(1, (progress - p.delay) / (1 - p.delay)));
              const eased = easeOutCubic(localT);
              const dx = Math.cos(p.angle) * p.distance * eased;
              const dy = Math.sin(p.angle) * p.distance * eased - 10 * eased; // slight upward drift
              const opacity = 1 - easeOutCubic(localT);
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    left: '50%',
                    top: '50%',
                    width: p.size,
                    height: p.size,
                    borderRadius: p.size / 2,
                    backgroundColor: p.color,
                    opacity,
                    transform: [{ translateX: dx }, { translateY: dy }],
                  }}
                />
              );
            })}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 24,
    backgroundColor: 'rgba(12,15,22,0.92)',
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  btn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    borderRadius: 12,
    paddingVertical: 13,
  },
  btnFilled: {
    backgroundColor: colors.amber,
  },
  btnPressed: {
    opacity: 0.85,
  },
  btnTextFilled: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13.5,
    color: colors.navyBase,
  },
  goingWrap: {
    flex: 1,
    position: 'relative',
  },
  // Sized bigger than the button itself so particles have room to fly
  // outward past the button's own edges without getting clipped.
  particleField: {
    position: 'absolute',
    top: -40,
    left: -40,
    right: -40,
    bottom: -40,
  },
});
