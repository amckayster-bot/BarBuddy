import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import StarRating from './StarRating';

export default function ReviewCard({ author, rating, text }) {
  return (
    <View style={styles.card}>
      <View style={styles.top}>
        <Text style={styles.author}>{author}</Text>
        <StarRating rating={rating} size={11} />
      </View>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
  },
  top: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  author: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 13.5,
    color: colors.textPrimary,
  },
  text: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    lineHeight: 19.5,
    color: colors.textMuted,
  },
});
