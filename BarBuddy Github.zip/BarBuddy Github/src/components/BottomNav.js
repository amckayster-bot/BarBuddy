import { memo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { glow } from '../theme/glow';
import { useBreathingGlow } from '../hooks/useBreathingGlow';
import NavIcon from './NavIcons';
import { TAB_ROUTES } from '../navigation/tabRoutes';

// One tab's icon + label. Its own component (rather than inline JSX in the
// .map() below) purely so useBreathingGlow — a hook — can legally be called
// once per tab instance, same reasoning as CatPill in SearchScreen.js.
function NavItem({ route, isFocused, onPress }) {
  const { shadowOpacity, shadowRadius } = useBreathingGlow(isFocused, { periodMs: 2400 });
  // Selected tab reads as a glowing white rather than the amber "happening
  // now" signal used elsewhere (attendance pulse, ranking numerals) — amber
  // stays reserved for that one meaning, per theme/colors.js.
  const color = isFocused ? colors.textPrimary : colors.textMuted;

  return (
    <Pressable onPress={onPress} style={styles.item} hitSlop={8}>
      <View style={[isFocused && glow(colors.textPrimary), isFocused && { shadowOpacity, shadowRadius }]}>
        <NavIcon name={route.iconName} color={color} />
      </View>
      <Text style={[styles.label, { color }]}>{route.label}</Text>
    </Pressable>
  );
}

// Tab bar for SwipeableTabs (see navigation/SwipeableTabs.js) — this used
// to be React Navigation's custom tabBar (receiving {state, descriptors,
// navigation} from a real Tab.Navigator), but that navigator was replaced
// with a custom swipeable pager, so this now just takes a plain active
// index + a callback instead.
//
// Memoized: SwipeableTabs re-renders on every single onPanResponderMove
// during a drag (its translateX lives in state), and without memo that
// re-rendered this whole tab bar — including 5 useBreathingGlow RAF loops
// — on every frame of every drag along with it. activeIndex/onIndexChange
// (the latter now stabilized via useCallback in SwipeableTabs) only
// actually change when a tab switch completes, so memo lets this skip all
// of those in-between re-renders.
function BottomNav({ activeIndex, onIndexChange }) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.nav, { paddingBottom: 14 + insets.bottom }]}>
      {TAB_ROUTES.map((route, index) => (
        <NavItem
          key={route.name}
          route={route}
          isFocused={activeIndex === index}
          onPress={() => onIndexChange(index)}
        />
      ))}
    </View>
  );
}

export default memo(BottomNav);

const styles = StyleSheet.create({
  nav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    // No real blur in this pass (see chat) — opacity bumped up from the
    // mockup's 0.72 to keep labels readable against the moving gradient.
    backgroundColor: 'rgba(12,15,22,0.92)',
  },
  item: {
    alignItems: 'center',
    gap: 5,
  },
  label: {
    fontFamily: fonts.bodyMedium,
    fontSize: 10,
  },
});
