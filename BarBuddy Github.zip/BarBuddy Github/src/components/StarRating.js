import { View } from 'react-native';
import Svg, { Polygon } from 'react-native-svg';
import { colors } from '../theme/colors';

const STAR_POINTS = '12 2 15 9 22 9.5 17 14.5 18.5 22 12 18 5.5 22 7 14.5 2 9.5 9 9';

// Note: the source mockup referenced a `url(#half)` gradient fill for half
// stars that was never actually defined (a latent bug there) — this clips a
// full filled star to its left half instead, so half ratings render correctly.
function Star({ size, fillAmount }) {
  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} viewBox="0 0 24 24" style={{ position: 'absolute' }}>
        <Polygon points={STAR_POINTS} fill="none" stroke={colors.amber} strokeWidth={1.4} />
      </Svg>
      {fillAmount > 0 && (
        <View
          style={{
            position: 'absolute',
            width: fillAmount >= 1 ? size : size / 2,
            height: size,
            overflow: 'hidden',
          }}
        >
          <Svg width={size} height={size} viewBox="0 0 24 24">
            <Polygon points={STAR_POINTS} fill={colors.amber} stroke={colors.amber} strokeWidth={1.4} />
          </Svg>
        </View>
      )}
    </View>
  );
}

export default function StarRating({ rating, size = 13 }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  const stars = [];
  for (let i = 0; i < 5; i++) {
    const fillAmount = i < full ? 1 : i === full && half ? 0.5 : 0;
    stars.push(<Star key={i} size={size} fillAmount={fillAmount} />);
  }
  return <View style={{ flexDirection: 'row', gap: 2 }}>{stars}</View>;
}
