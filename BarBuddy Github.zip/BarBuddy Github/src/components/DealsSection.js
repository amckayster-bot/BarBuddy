// DealsSection.js
//
// "Deals" row on Home, above Need Inspiration and Top Ten — for the segment
// of people whose main question isn't "what's nearby" but "what's nearby
// with something good going on right now." Same horizontal-scroll card
// pattern as Near You (see MiniCard), but with a deal badge/tag instead of
// category+distance, and a distinct accent color (green — money/savings —
// deliberately different from amber, which stays reserved for the "happening
// now" attendance signal elsewhere in the app) so it reads as its own kind
// of card at a glance.
import { Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';

function DealCard({ deal }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('VenueDetail', { venueId: deal.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.photoWrap}>
        <Image source={deal.photo} style={styles.photo} />
        <View style={styles.tagBadge}>
          <Text style={styles.tagBadgeText}>{deal.tag}</Text>
        </View>
      </View>
      <Text style={styles.name} numberOfLines={1}>
        {deal.name}
      </Text>
      <Text style={styles.dealText} numberOfLines={2}>
        {deal.text}
      </Text>
      <Text style={styles.meta} numberOfLines={1}>
        {deal.neighborhood}
        {deal.endsLabel ? ` · ${deal.endsLabel}` : ''}
      </Text>
    </Pressable>
  );
}

export default function DealsSection({ deals }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.content}>
      {deals.map((deal) => (
        <DealCard key={deal.id} deal={deal} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: {
    gap: spacing.md,
    // Small vertical padding so the pressed-state opacity/shadow on the
    // first/last card doesn't read as clipped against the row's own edge.
    paddingVertical: 4,
  },
  card: {
    width: 168,
  },
  pressed: {
    opacity: 0.85,
  },
  photoWrap: {
    height: 100,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 8,
    backgroundColor: colors.navySurface,
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  tagBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: colors.ratingGreen,
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  tagBadgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 10.5,
    color: colors.navyBase,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  dealText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textPrimary,
    opacity: 0.85,
    lineHeight: 16,
    marginBottom: 3,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
  },
});
