// NearYouSection.js
//
// Wraps the "Near you" label + carousel in a full-width dark banner module
// (navy-surface background, edge-to-edge / square sides so it reads as a
// strip cutting across the screen).
//
// No auto-scroll anymore — plain, manual horizontal scroll only. This used
// to auto-drift continuously (first via imperative scrollTo() calls, later
// via a transform-based driver), but kept causing tapping problems
// elsewhere on Home in ways that were hard to fully pin down across
// several rounds of fixes. Per direct instruction, the auto-scroll is
// removed outright rather than patched again — simplicity and reliable
// tapping win over the ambient-motion effect here.
//
// Swipe-conflict note: this is one of the two nested horizontal scrollers
// that used to fight with SwipeableTabs' own left/right page swipe (see the
// nested-horizontal-scroll note in SwipeableTabs.js) — dragging across this
// carousel could change the page instead of scrolling it. onTouchStart/
// onTouchEnd/onTouchCancel here flag "a touch is down on this scroller" to
// the pager via TabPagerContext for the duration of the touch, so the pager
// bows out entirely and this always just scrolls, never swipes the page.
import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';
import { useTabPager } from '../context/TabPagerContext';
import MiniCard from './MiniCard';

const CARD_GAP = spacing.md;
const BANNER_PADDING = spacing.lg;

export default function NearYouSection({ places }) {
  const { setInnerScrollActive } = useTabPager();

  return (
    <Pressable style={styles.banner}>
      <Text style={styles.label}>Near you</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.content}
        onTouchStart={() => setInnerScrollActive(true)}
        onTouchEnd={() => setInnerScrollActive(false)}
        onTouchCancel={() => setInnerScrollActive(false)}
      >
        {places.map((place) => (
          <MiniCard key={place.id} place={place} />
        ))}
      </ScrollView>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  // No border radius and no side borders — this banner is meant to bleed
  // full-width, edge to edge (the negative horizontal margin that achieves
  // that lives on the wrapping section in HomeScreen.js).
  banner: {
    // 60% opacity navySurface (rgba, not the opacity prop — opacity would
    // also fade the cards/text inside it, not just the panel fill) so the
    // nebula background shows through the banner slightly instead of being
    // fully hidden behind a solid panel.
    backgroundColor: 'rgba(23,27,36,0.6)',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
    paddingVertical: BANNER_PADDING,
  },
  label: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 12,
    marginHorizontal: BANNER_PADDING,
  },
  content: {
    paddingHorizontal: BANNER_PADDING,
    gap: CARD_GAP,
  },
});
