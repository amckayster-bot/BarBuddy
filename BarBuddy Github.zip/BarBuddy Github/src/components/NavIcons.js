import Svg, { Circle, Path, Rect } from 'react-native-svg';

// Shared icon set for the main tabs — used by both the bottom tab bar and
// each tab's placeholder screen (so the big centered icon matches its tab).
export default function NavIcon({ name, color, size = 20 }) {
  switch (name) {
    case 'home':
      return (
        <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8}>
          <Path d="M3 11l9-8 9 8M5 10v10h14V10" />
        </Svg>
      );
    case 'foryou':
      return (
        <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8}>
          <Path d="M12 17l-6.16 3.24 1.18-6.88L2 8.76l6.92-1L12 1.5l3.08 6.26 6.92 1-5.02 4.6 1.18 6.88z" />
        </Svg>
      );
    case 'search':
      return (
        <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8}>
          <Circle cx={11} cy={11} r={7} />
          <Path d="M21 21l-4.3-4.3" />
        </Svg>
      );
    case 'events':
      return (
        <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8}>
          <Rect x={3} y={4} width={18} height={17} rx={2} />
          <Path d="M16 2v4M8 2v4M3 10h18" />
        </Svg>
      );
    case 'assistant':
      return (
        <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8}>
          <Path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
        </Svg>
      );
    default:
      return null;
  }
}
