import { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import bostonVenues from '../data/bostonVenues.json';
import { TD_GARDEN, venueMarkers } from '../data/mapCoords';
import { buildLeafletMapHtml } from './leafletMapHtml';

// Real mini preview of the map (same Leaflet + CARTO "Dark Matter" engine as
// the full interactive MapScreen, via the shared buildLeafletMapHtml
// helper) — actual streets/roads, the real nearby venues plotted as pins,
// and a red "you are here" marker (red here specifically to read as
// distinct from the amber "landmark" marker style used on the full map).
// Non-interactive: zoom/pan/tap-to-open-popup are all disabled on the
// WebView itself, and pointerEvents="none" lets taps pass straight through
// to the wrapping Pressable so the whole card still opens the real map.
export default function MapPlaceholder({ nearbyCount, onPress }) {
  const markers = useMemo(() => venueMarkers(bostonVenues), []);
  const html = useMemo(
    () =>
      buildLeafletMapHtml({
        center: TD_GARDEN,
        zoom: 12.5,
        markers,
        highlightMarker: {
          lat: TD_GARDEN.lat,
          lng: TD_GARDEN.lng,
          color: colors.ratingRed,
        },
        interactive: false,
      }),
    [markers]
  );

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.box, pressed && styles.pressed]}
    >
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        style={styles.webview}
        javaScriptEnabled
        domStorageEnabled
        scrollEnabled={false}
        bounces={false}
        // Preview only — never interactive, so let taps fall through to the
        // Pressable underneath rather than being swallowed by the WebView.
        pointerEvents="none"
      />
      <View style={styles.pill}>
        <Svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={2}>
          <Path d="M12 21s-7-6.2-7-11a7 7 0 0114 0c0 4.8-7 11-7 11z" />
          <Circle cx={12} cy={10} r={2.5} />
        </Svg>
        <Text style={styles.pillText}>{nearbyCount} spots nearby</Text>
      </View>
      <View style={styles.expandChip}>
        <Svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2}>
          <Path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
        </Svg>
        <Text style={styles.expandText}>Explore map</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  box: {
    height: 150,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pressed: {
    opacity: 0.85,
  },
  webview: {
    flex: 1,
    backgroundColor: colors.navySurface,
  },
  pill: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(12,15,22,0.65)',
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  pillText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.textPrimary,
  },
  expandChip: {
    position: 'absolute',
    top: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(12,15,22,0.65)',
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 20,
  },
  expandText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.textPrimary,
  },
});
