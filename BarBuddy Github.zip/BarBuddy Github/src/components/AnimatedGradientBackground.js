// AnimatedGradientBackground.js
//
// Aurora UI nebula background: soft "breathing" purple and steel-blue blobs
// stay dominant, joined by smaller, lower-opacity red and orange accent
// blobs, plus a static starfield layer (small white dots that twinkle).
// Built with `expo-linear-gradient` + plain React state (no expo-gl / raw
// WebGL, and deliberately no React Native `Animated` either — see note
// below).
//
// Design note: amber is deliberately NOT one of the blob colors. Amber's
// one job in this app is the "happening now" signal (attendance pulse,
// active nav tab, ranking numerals) — keeping it out of the ambient
// background keeps that meaning intact. The red/orange accent blobs use
// their own `nebulaRed` / `nebulaOrange` tokens (see theme/colors.js),
// which are deliberately different, more saturated hues than `amber` —
// never the amber hex itself.
//
// Animation-driver note: this was originally built on RN's `Animated`
// API (Animated.loop + Animated.timing). Confirmed by live-measuring the
// rendered transform over several seconds that it never progresses past
// its starting frame in this project's exact setup (Expo SDK 54 downgrade +
// react-native-web 0.21.2) — true with useNativeDriver both on and off, no
// console errors either time. Same failure mode hit earlier building the
// Home/Detail gradient. So this drives everything with plain state + a
// timer instead, computing each blob's own sine-eased position from
// elapsed time — same visual curve, verified to actually move.
//
// Sizing note: blob sizes/positions are derived from the actual screen size
// via useScreenSize() rather than Dimensions.get('window') at module load —
// on the web preview the app renders inside a fixed-size phone frame that's
// narrower than the real browser window, so a module-level Dimensions read
// would size the blobs against the wrong box.
//
// Blur note: blobs were originally built on RN's cross-platform `filter`
// style (`[{ blur: n }]`). On a real iOS device that turned out to render
// each blob's full square bounding box as an opaque gray/white block behind
// the soft circular glow — the blur filter's offscreen render target isn't
// coming back through with real alpha on iOS in this Expo SDK 54 / New
// Architecture setup, even though it looked fine in the web preview. Rather
// than fight that platform gap, blobs are now drawn as an SVG radial
// gradient (Circle filled with a RadialGradient that fades to fully
// transparent at the edge, via react-native-svg — already a dependency used
// elsewhere in the app). That gives the same soft, edgeless glow look
// without a native blur filter at all, so there's no offscreen-buffer
// behavior to differ between platforms.
//
// Teleport note: on top of the constant subtle "breathing" pulse, each blob
// now also periodically fades fully to invisible and reappears at a new,
// randomized spot on screen — rather than breathing forever in one fixed
// place. The new spot is derived deterministically from elapsed time (a
// seeded pseudo-random keyed on the blob + a cycle index), not
// Math.random() at render time, so it's stable within a cycle and only
// changes when a new cycle begins.

import { useEffect, useMemo, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg';
import { colors } from '../theme/colors';
import { useScreenSize } from '../theme/screenSize';

const TICK_MS = 100;

function buildBlobs(width, height) {
  return [
    {
      colors: ['#4C2E7E', '#2E1F4F'], // deep purple
      size: width * 1.1,
      breatheDuration: 7000,
      breatheDelay: 0,
      minScale: 0.85,
      maxScale: 1.18,
      minOpacity: 0.28,
      maxOpacity: 0.58,
      blur: 75,
      seed: 11,
      cycleMs: 17000,
      holdRatio: 0.62,
    },
    {
      colors: ['#2E4A78', '#1E3252'], // steel blue
      size: width * 1.0,
      breatheDuration: 8400,
      breatheDelay: 900,
      minScale: 0.82,
      maxScale: 1.15,
      minOpacity: 0.24,
      maxOpacity: 0.5,
      blur: 75,
      seed: 29,
      cycleMs: 19500,
      holdRatio: 0.6,
    },
    {
      colors: ['#3A2A5E', '#1C1830'], // navy-purple blend, ties the two together
      size: width * 0.85,
      breatheDuration: 6200,
      breatheDelay: 400,
      minScale: 0.88,
      maxScale: 1.12,
      minOpacity: 0.2,
      maxOpacity: 0.4,
      blur: 68,
      seed: 47,
      cycleMs: 15500,
      holdRatio: 0.65,
    },
    // Aurora accent blobs — smaller and lower-opacity than the purple/blue
    // pair above, which stay dominant. Colors from theme/colors.js
    // (nebulaRed / nebulaOrange), never the amber token. Blurred slightly
    // more than the main blobs since they're meant to read as soft glow
    // accents rather than distinct shapes, and they teleport on a shorter
    // cycle so the accent color keeps turning up somewhere new.
    {
      colors: [colors.nebulaRed, '#3D1418'],
      size: width * 0.55,
      breatheDuration: 9000,
      breatheDelay: 1600,
      minScale: 0.8,
      maxScale: 1.08,
      minOpacity: 0.1,
      maxOpacity: 0.22,
      blur: 80,
      seed: 71,
      cycleMs: 13000,
      holdRatio: 0.55,
    },
    {
      colors: [colors.nebulaOrange, '#3D200D'],
      size: width * 0.6,
      breatheDuration: 7600,
      breatheDelay: 2200,
      minScale: 0.82,
      maxScale: 1.1,
      minOpacity: 0.08,
      maxOpacity: 0.18,
      blur: 80,
      seed: 83,
      cycleMs: 14500,
      holdRatio: 0.55,
    },
  ];
}

// Static starfield — small white dots scattered across the screen with a
// very slow twinkle (subtle opacity drift, not a blink). Positions are
// randomized once per screen size via useMemo below, not re-rolled on every
// render, so stars don't jump around as the background re-renders.
const STAR_COUNT = 46;

function buildStars(width, height) {
  const stars = [];
  for (let i = 0; i < STAR_COUNT; i++) {
    stars.push({
      top: Math.random() * height,
      left: Math.random() * width,
      size: 1 + Math.random() * 1.6,
      baseOpacity: 0.25 + Math.random() * 0.45,
      twinkleAmount: 0.15 + Math.random() * 0.25,
      duration: 3200 + Math.random() * 3600,
      delay: Math.random() * 4000,
    });
  }
  return stars;
}

function Star({ star, elapsedMs }) {
  // blobProgress eases 0 -> 1 -> 0 on a loop; remapping that to -1 -> 1
  // makes the star dim below its base as well as brighten above it, so the
  // twinkle actually reads as a twinkle rather than a one-directional glow.
  const t = blobProgress(elapsedMs, star) * 2 - 1;
  const opacity = Math.max(0.12, Math.min(1, star.baseOpacity + star.twinkleAmount * t));

  return (
    <View
      style={{
        position: 'absolute',
        top: star.top,
        left: star.left,
        width: star.size,
        height: star.size,
        borderRadius: star.size / 2,
        backgroundColor: '#F5F3EF',
        opacity,
      }}
    />
  );
}

// Matches Easing.inOut(Easing.sin): slow start, slow end, fast middle.
function easeInOutSine(t) {
  const clamped = Math.max(0, Math.min(1, t));
  return -(Math.cos(Math.PI * clamped) - 1) / 2;
}

// Same shape as the original Animated.loop(sequence([timing 0->1, timing
// 1->0])): hold at 0 for `delay`, ease up to 1 over `duration`, ease back
// down to 0 over `duration`, repeat. Used for the constant subtle
// "breathing" scale/opacity pulse (config.breatheDuration/breatheDelay).
function blobProgress(elapsedMs, config) {
  const duration = config.duration ?? config.breatheDuration;
  const delay = config.delay ?? config.breatheDelay;
  const cycleMs = delay + duration * 2;
  const cyclePos = elapsedMs % cycleMs;
  if (cyclePos < delay) return 0;
  const t = cyclePos - delay;
  if (t < duration) return easeInOutSine(t / duration);
  return 1 - easeInOutSine((t - duration) / duration);
}

// Deterministic pseudo-random in [0, 1) from a numeric seed — used instead
// of Math.random() so a blob's teleport position only changes when its
// cycle index changes, not on every render.
function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function positionForCycle(config, cycleIndex, width, height) {
  const rx = seededRandom(config.seed + cycleIndex * 97.13);
  const ry = seededRandom(config.seed + cycleIndex * 57.71 + 13);
  // Allow the same slight off-screen bleed the original fixed positions
  // had, so teleported blobs can still land partly off-edge.
  const left = -config.size * 0.25 + rx * (width - config.size * 0.5);
  const top = -config.size * 0.25 + ry * (height - config.size * 0.5);
  return { top, left };
}

// Where in its teleport cycle the blob currently is: fully visible and
// holding position for most of the cycle, then fading out, teleporting
// (instantly, while invisible), and fading back in at the new spot.
function teleportPhase(elapsedMs, config) {
  const { cycleMs, holdRatio } = config;
  const holdMs = cycleMs * holdRatio;
  const fadeMs = (cycleMs - holdMs) / 2;
  const cycleIndex = Math.floor(elapsedMs / cycleMs);
  const cyclePos = elapsedMs % cycleMs;

  if (cyclePos < holdMs) {
    return { opacityFactor: 1, posIndex: cycleIndex };
  }
  if (cyclePos < holdMs + fadeMs) {
    const t = (cyclePos - holdMs) / fadeMs;
    return { opacityFactor: 1 - t, posIndex: cycleIndex };
  }
  const t = (cyclePos - holdMs - fadeMs) / fadeMs;
  return { opacityFactor: t, posIndex: cycleIndex + 1 };
}

// Higher `blur` config values now control how early the radial gradient
// starts fading (a smaller solid core, more edge softness) rather than a
// literal blur radius — same knob, same intent ("softer/glowier"), just
// applied through gradient stops instead of a filter.
function softnessStop(blur) {
  return Math.max(18, Math.min(48, 58 - blur * 0.45));
}

function Blob({ config, elapsedMs, width, height }) {
  const breathe = blobProgress(elapsedMs, config);
  const scale = config.minScale + (config.maxScale - config.minScale) * breathe;
  const breatheOpacity = config.minOpacity + (config.maxOpacity - config.minOpacity) * breathe;

  const { opacityFactor, posIndex } = teleportPhase(elapsedMs, config);
  const { top, left } = positionForCycle(config, posIndex, width, height);
  const opacity = breatheOpacity * opacityFactor;
  const gradientId = `blob-grad-${config.seed}`;
  const coreStop = softnessStop(config.blur);

  return (
    <View
      style={{
        position: 'absolute',
        top,
        left,
        width: config.size,
        height: config.size,
        opacity,
        transform: [{ scale }],
      }}
    >
      <Svg width="100%" height="100%" viewBox="0 0 100 100">
        <Defs>
          <RadialGradient id={gradientId} cx="50%" cy="50%" r="50%">
            <Stop offset="0%" stopColor={config.colors[0]} stopOpacity={1} />
            <Stop offset={`${coreStop}%`} stopColor={config.colors[0]} stopOpacity={0.65} />
            <Stop offset={`${Math.min(96, coreStop + 30)}%`} stopColor={config.colors[1]} stopOpacity={0.22} />
            <Stop offset="100%" stopColor={config.colors[1]} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx="50" cy="50" r="50" fill={`url(#${gradientId})`} />
      </Svg>
    </View>
  );
}

export default function AnimatedGradientBackground() {
  const { width, height } = useScreenSize();
  const blobs = useMemo(() => buildBlobs(width, height), [width, height]);
  const stars = useMemo(() => buildStars(width, height), [width, height]);
  const [elapsedMs, setElapsedMs] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const id = setInterval(() => {
      setElapsedMs(Date.now() - start);
    }, TICK_MS);
    return () => clearInterval(id);
  }, []);

  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      {/* Base fill — same navy as the rest of the app */}
      <View style={[StyleSheet.absoluteFillObject, { backgroundColor: colors.navyBase }]} />
      {blobs.map((b, i) => (
        <Blob key={i} config={b} elapsedMs={elapsedMs} width={width} height={height} />
      ))}
      {stars.map((s, i) => (
        <Star key={i} star={s} elapsedMs={elapsedMs} />
      ))}
    </View>
  );
}
