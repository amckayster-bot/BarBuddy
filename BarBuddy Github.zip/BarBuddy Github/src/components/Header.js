// Header.js
//
// No enclosing banner/box anymore — the "Tonight." title, location row, and
// avatar sit directly on the nebula background like every other section on
// Home, rather than inside their own navy-surface panel. (Previously this
// had a full-bleed dark banner treatment matching Near You; removed per
// explicit request — the background itself already reads well behind it.)
//
// Top-safe-area note: HomeScreen's outer SafeAreaView deliberately does NOT
// inset its top edge (see its `edges` prop), so this component absorbs the
// safe-area inset itself (via useSafeAreaInsets) as its own top padding —
// otherwise iOS would leave an odd gap of background above the header
// before the notch/status-area inset kicked in.
import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';

export default function Header() {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.banner, { paddingTop: insets.top + spacing.lg }]}>
      <View style={styles.row}>
        <View>
          <Text style={styles.eyebrow}>Tonight.</Text>
          <View style={styles.locationRow}>
            <View style={styles.locationDot} />
            <Text style={styles.locationText}>Boston</Text>
            <Svg
              width={10}
              height={10}
              viewBox="0 0 24 24"
              fill="none"
              stroke={colors.textMuted}
              strokeWidth={2.5}
              style={styles.chevron}
            >
              <Path d="M6 9l6 6 6-6" />
            </Svg>
          </View>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarLetter}>A</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // No background/border anymore — just the safe-area-aware spacing.
  banner: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    // paddingTop is set inline above (safe-area inset + spacing.lg)
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  eyebrow: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 22,
    color: colors.textPrimary,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 6,
  },
  locationDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: colors.textMuted,
  },
  locationText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  chevron: {
    marginLeft: 2,
    opacity: 0.8,
  },
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.navyBase,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarLetter: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 15,
    color: colors.textPrimary,
  },
});
