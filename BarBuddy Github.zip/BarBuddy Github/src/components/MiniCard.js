import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import PhotoTag from './PhotoTag';

export default function MiniCard({ place }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('VenueDetail', { venueId: place.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.photoWrap}>
        <Image source={place.photo} style={styles.photo} />
        <PhotoTag label={place.ageAccess} small style={styles.tagPosition} />
      </View>
      <Text style={styles.name} numberOfLines={1}>
        {place.name}
      </Text>
      <Text style={styles.meta} numberOfLines={1}>
        {place.category} · {place.distance}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 150,
  },
  pressed: {
    opacity: 0.85,
  },
  photoWrap: {
    height: 110,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 8,
    backgroundColor: colors.navySurface,
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  tagPosition: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textMuted,
  },
});
