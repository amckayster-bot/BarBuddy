// TopTenList.js
//
// Inline "Top Ten in Boston" list — replaces the old single "This week"
// tile that linked out to a separate ranked page. Shows 5 venue rows at a
// time in a fixed-height window; the rest (up to 10) are reachable via an
// internal vertical scroll, so Home doesn't get overwhelmed by a long list
// but nothing is hidden either.
//
// Each row: rank + venue name on the left, no photo, and a rating-out-of-10
// badge on the right. The badge color is a continuous gradient across the
// 0-10 scale (red -> orange -> yellow -> green) rather than four hard
// buckets, so two close scores (5.9 vs 6.1) land on visibly close colors
// instead of jumping straight from orange to yellow.
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';

const VISIBLE_ROWS = 5;
const ROW_HEIGHT = 68;

// Color stops the badge interpolates between, keyed by score (0-10).
const COLOR_STOPS = [
  { at: 0, color: colors.ratingRed },
  { at: 4, color: colors.ratingOrange },
  { at: 6, color: colors.ratingYellow },
  { at: 8, color: colors.ratingGreen },
  { at: 10, color: '#2ECC71' }, // slightly deeper green for a true top score
];

function hexToRgb(hex) {
  const clean = hex.replace('#', '');
  return {
    r: parseInt(clean.substring(0, 2), 16),
    g: parseInt(clean.substring(2, 4), 16),
    b: parseInt(clean.substring(4, 6), 16),
  };
}

function mixHex(hexA, hexB, t) {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  const r = Math.round(a.r + (b.r - a.r) * t);
  const g = Math.round(a.g + (b.g - a.g) * t);
  const bch = Math.round(a.b + (b.b - a.b) * t);
  return `rgb(${r}, ${g}, ${bch})`;
}

function badgeColor(score) {
  const clamped = Math.max(0, Math.min(10, score));
  for (let i = 0; i < COLOR_STOPS.length - 1; i++) {
    const lower = COLOR_STOPS[i];
    const upper = COLOR_STOPS[i + 1];
    if (clamped >= lower.at && clamped <= upper.at) {
      const span = upper.at - lower.at;
      const t = span === 0 ? 0 : (clamped - lower.at) / span;
      return mixHex(lower.color, upper.color, t);
    }
  }
  return COLOR_STOPS[COLOR_STOPS.length - 1].color;
}

export default function TopTenList({ venues }) {
  const navigation = useNavigation();
  const windowHeight = Math.min(venues.length, VISIBLE_ROWS) * ROW_HEIGHT;

  return (
    <View style={[styles.list, { height: windowHeight }]}>
      <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled>
        {venues.map((venue, i) => (
          <Pressable
            key={venue.id}
            onPress={() => navigation.navigate('VenueDetail', { venueId: venue.id })}
            style={({ pressed }) => [
              styles.row,
              i === venues.length - 1 && styles.lastRow,
              pressed && styles.rowPressed,
            ]}
          >
            <View style={styles.left}>
              <Text style={styles.rank}>{i + 1}</Text>
              <Text style={styles.name} numberOfLines={1}>
                {venue.name}
              </Text>
            </View>
            <View style={[styles.badge, { backgroundColor: badgeColor(venue.score) }]}>
              <Text style={styles.badgeText}>{venue.score.toFixed(1)}</Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  list: {
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    overflow: 'hidden',
  },
  row: {
    height: ROW_HEIGHT,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  lastRow: {
    borderBottomWidth: 0,
  },
  rowPressed: {
    backgroundColor: colors.navyBase,
  },
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flexShrink: 1,
  },
  rank: {
    fontFamily: fonts.displayBold,
    fontSize: 15,
    color: colors.textMuted,
    width: 20,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 16,
    color: colors.textPrimary,
    flexShrink: 1,
  },
  badge: {
    minWidth: 48,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 9,
    alignItems: 'center',
  },
  badgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13.5,
    color: colors.navyBase,
  },
});
