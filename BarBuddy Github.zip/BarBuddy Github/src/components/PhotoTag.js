import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';

// The age-access pill badge overlaid on a photo's top-right corner — a
// consistent pattern on every photo card, not just Featured.
export default function PhotoTag({ label, small, style }) {
  return (
    <View style={[styles.tag, small && styles.tagSmall, style]}>
      <Text style={[styles.label, small && styles.labelSmall]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  tag: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    backgroundColor: 'rgba(12,15,22,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.25)',
  },
  tagSmall: {
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  label: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.textPrimary,
  },
  labelSmall: {
    fontSize: 10,
  },
});
