// InspirationCategories.js
//
// "Need Inspiration?" category-browsing chips on Home. These are real
// filters, not decorative — tapping one activates that category in the
// same shared filter state the Search tab reads/writes (see
// SearchFilterContext), highlighting in that chip's own accent color.
// Tapping a chip stays right here on Home; it does NOT jump to Search. A
// "Search" button below the chip row is the only thing that navigates over
// to the Search tab, carrying whatever categories are currently selected —
// so picking categories and committing to see results are two separate
// steps.
//
// Home's category set doesn't map 1:1 onto Search's taxonomy (Home has no
// "Winery" chip in Search — it's a Bars subcategory there), hence
// CATEGORY_LINKS below: each Home chip names the Search category key it
// drives, plus an optional specific subcategory to activate alongside it.
//
// Visual selection state is tracked locally (`selectedChips`) rather than
// derived from `activeCategories.includes(cat.searchKey)`. That derivation
// was the original bug: Winery and Bars both drive `searchKey: 'bars'`, so
// activating Winery turned on 'bars' in the shared filter state, which
// made the Bars chip *also* read as active even though it was never
// tapped. Tracking each chip's own on/off state locally, and only ever
// asking the shared context to turn `bars` fully off once no other
// selected chip still needs it, keeps Winery and Bars visually independent
// while still filtering correctly underneath.
import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Line, Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { useSearchFilters } from '../context/SearchFilterContext';
import { useBreathingGlow } from '../hooks/useBreathingGlow';
import { useTabPager } from '../context/TabPagerContext';

function iconProps(color) {
  return {
    width: 16,
    height: 16,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: color,
    strokeWidth: 1.8,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
  };
}

// General umbrella categories — subcategories (Karaoke, Pool, Trivia, Dive,
// Rooftop, etc.) live one level deeper, inside Search's own filtering once
// a category is picked, rather than as their own top-level chips here.
//
// `color` is this chip's own accent — deliberately NOT always the same as
// its `searchKey`'s color in searchCategories.js (Winery is red even
// though the "bars" category it drives is orange, so it reads as its own
// distinct thing on Home).
const CATEGORY_LINKS = [
  {
    key: 'bars',
    label: 'Bars',
    searchKey: 'bars',
    color: '#E15C3F',
    icon: (color) => (
      // Martini glass
      <Svg {...iconProps(color)}>
        <Path d="M4 4h16l-7 8.5v6.5M12 18.5H8m4 0h4" />
        <Path d="M9.5 4l2.5 5.5L14.5 4" />
      </Svg>
    ),
  },
  {
    key: 'clubs',
    label: 'Clubs',
    searchKey: 'clubs',
    color: '#D63E8F',
    icon: (color) => (
      <Svg {...iconProps(color)}>
        <Circle cx={12} cy={12} r={9} />
        <Circle cx={12} cy={12} r={2.4} fill={color} stroke="none" />
      </Svg>
    ),
  },
  {
    key: 'lounges',
    label: 'Lounges',
    searchKey: 'lounges',
    color: '#8B5CF6',
    icon: (color) => (
      // Sofa
      <Svg {...iconProps(color)}>
        <Path d="M5 12a2 2 0 012-2h10a2 2 0 012 2v3H5v-3z" />
        <Path d="M4 13v3a1 1 0 001 1h1v-2m13-2v3a1 1 0 01-1 1h-1v-2" />
        <Line x1={6} y1={17} x2={6} y2={19} />
        <Line x1={18} y1={17} x2={18} y2={19} />
      </Svg>
    ),
  },
  {
    key: 'live-music',
    label: 'Live Music Venues',
    searchKey: 'live-music',
    color: '#3E8EDE',
    icon: (color) => (
      // Music note
      <Svg {...iconProps(color)}>
        <Path d="M9 18V6l11-2v12" />
        <Circle cx={7} cy={18} r={2.5} />
        <Circle cx={18} cy={16} r={2.5} />
      </Svg>
    ),
  },
  {
    key: 'winery',
    label: 'Winery',
    // Search has no standalone "Winery" category — Wine Bars is a Bars
    // subcategory there, so this chip drives both. Its own chip color is
    // independent of Bars' color (red vs. orange) precisely so it doesn't
    // read as "the same thing as Bars" even though it shares a searchKey.
    searchKey: 'bars',
    searchSub: 'Wine Bars',
    color: '#D8453E',
    icon: (color) => (
      // Wine glass
      <Svg {...iconProps(color)}>
        <Path d="M8 3h8l-1 6.5a3 3 0 01-6 0L8 3z" />
        <Line x1={12} y1={12.5} x2={12} y2={19} />
        <Line x1={8.5} y1={19} x2={15.5} y2={19} />
      </Svg>
    ),
  },
  {
    key: 'breweries',
    label: 'Breweries',
    searchKey: 'breweries',
    color: '#8B5A34',
    icon: (color) => (
      // Beer mug
      <Svg {...iconProps(color)}>
        <Path d="M5 8h9v10a2 2 0 01-2 2H7a2 2 0 01-2-2V8z" />
        <Path d="M14 10.5h1.5a2 2 0 012 2v1.5a2 2 0 01-2 2H14" />
        <Line x1={7.5} y1={5} x2={11.5} y2={5} />
      </Svg>
    ),
  },
  {
    key: 'arcade-bars',
    label: 'Arcade Bars',
    searchKey: 'arcades',
    color: '#2A97A1',
    icon: (color) => (
      // Game controller
      <Svg {...iconProps(color)}>
        <Path d="M6 10h2m-1-1v2" />
        <Circle cx={15} cy={10.5} r={0.9} fill={color} stroke="none" />
        <Circle cx={17.3} cy={12.3} r={0.9} fill={color} stroke="none" />
        <Path d="M4.5 12.5a4 4 0 014-4h7a4 4 0 014 4v2.5a2.6 2.6 0 01-4.6 1.6l-.6-.8a1.6 1.6 0 00-1.3-.6h-2a1.6 1.6 0 00-1.3.6l-.6.8a2.6 2.6 0 01-4.6-1.6v-2.5z" />
      </Svg>
    ),
  },
];

// One chip in the row. Its own component (rather than inline JSX in a
// .map()) purely so useBreathingGlow — a hook — can legally be called once
// per chip instance.
function CategoryChip({ cat, active, onPress }) {
  // Punchier range than the default + a random flicker glitch layered on
  // top — the "buttons act as neon lights" push: a stronger, more
  // saturated-reading glow that occasionally dips like an unstable tube,
  // rather than a perfectly smooth static halo.
  const { shadowOpacity, shadowRadius } = useBreathingGlow(active, {
    minOpacity: 0.3,
    maxOpacity: 0.75,
    minRadius: 5,
    maxRadius: 15,
    flicker: true,
  });
  const iconColor = active ? cat.color : colors.textPrimary;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        active && {
          borderWidth: 2,
          borderColor: cat.color,
          backgroundColor: `${cat.color}29`,
          shadowColor: cat.color,
          shadowOpacity,
          shadowRadius,
          shadowOffset: { width: 0, height: 0 },
        },
        pressed && styles.pressed,
      ]}
    >
      {cat.icon(iconColor)}
      <Text
        style={[
          styles.label,
          active && {
            color: cat.color,
            fontWeight: '600',
            // Text glow on top of the pill's own shadow — RN's Text
            // textShadow* props are plain native text rendering, not the
            // `filter: blur` style that broke on iOS, so this is safe to
            // use here. Scaled down from the pill's own radius so it reads
            // as a tight glow around the letters rather than a blur.
            textShadowColor: cat.color,
            textShadowRadius: shadowRadius * 0.6,
            textShadowOffset: { width: 0, height: 0 },
          },
        ]}
      >
        {cat.label}
      </Text>
    </Pressable>
  );
}

export default function InspirationCategories() {
  const { goToName } = useTabPager();
  const { activeCategories, setCategoryActive, setSubActive } = useSearchFilters();
  const [selectedChips, setSelectedChips] = useState(() => new Set());
  const hasSelection = selectedChips.size > 0;

  // If filters get wiped out from elsewhere (e.g. Search screen's "Clear
  // All"), drop Home's local selection too so chips don't keep reading as
  // active after the underlying filters are gone.
  useEffect(() => {
    if (activeCategories.length === 0 && selectedChips.size > 0) {
      setSelectedChips(new Set());
    }
    // Only reacting to activeCategories going empty, not to selectedChips —
    // this is a one-directional "someone else cleared everything" sync.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeCategories]);

  // IMPORTANT: this builds `next` and calls setSelectedChips with a plain
  // value, then calls the context's setters (setCategoryActive/
  // setSubActive) as separate, sibling statements — not from inside a
  // setSelectedChips functional updater. Calling another component's
  // setState (SearchFilterProvider's, via these context setters) from
  // within this component's own updater function counts, to React, as
  // "updating SearchFilterProvider while rendering InspirationCategories"
  // — which is exactly the warning/error this used to throw. That broken
  // render pass was also why every button in the app needed a second tap
  // to actually navigate: the first tap's gesture was registering, but the
  // corrupted render cycle it kicked off swallowed the resulting
  // navigation until a second tap forced things to settle. Keeping all of
  // this as plain top-level calls in the event handler (React batches them
  // normally) fixes both.
  const handleChipPress = (cat) => {
    const isSelected = selectedChips.has(cat.key);
    const next = new Set(selectedChips);
    if (isSelected) {
      next.delete(cat.key);
    } else {
      next.add(cat.key);
    }
    setSelectedChips(next);

    if (isSelected) {
      // Only turn the underlying search category fully off once no other
      // selected chip still needs it (Winery + Bars share `bars`).
      const stillNeeded = CATEGORY_LINKS.some((c) => next.has(c.key) && c.searchKey === cat.searchKey);
      if (!stillNeeded) {
        setCategoryActive(cat.searchKey, false);
      } else if (cat.searchSub) {
        setSubActive(cat.searchKey, cat.searchSub, false);
      }
    } else {
      setCategoryActive(cat.searchKey, true);
      if (cat.searchSub) {
        setSubActive(cat.searchKey, cat.searchSub, true);
      }
    }
  };

  // Deliberately restrained radius/opacity compared to the category chips
  // above — this button has no colored background tint to absorb the
  // glow, so a wide/strong blur here doesn't read as "a lit border", it
  // reads as "the middle filled in white". Keeping both low makes the
  // light hug the edge instead of washing the whole button.
  const { shadowOpacity: searchGlowOpacity, shadowRadius: searchGlowRadius } = useBreathingGlow(hasSelection, {
    minOpacity: 0.25,
    maxOpacity: 0.55,
    minRadius: 2,
    maxRadius: 6,
    flicker: true,
  });

  return (
    <View>
      <View style={styles.wrap}>
        {CATEGORY_LINKS.map((cat) => (
          <CategoryChip
            key={cat.key}
            cat={cat}
            active={selectedChips.has(cat.key)}
            onPress={() => handleChipPress(cat)}
          />
        ))}
      </View>

      {/* Empty/outlined until at least one category above is selected, then
          its border lights up white with a tight, restrained breathing +
          flickering glow — edge only, deliberately not blurred wide enough
          to wash the transparent middle white. This is the only thing
          here that navigates to the Search tab; the categories selected
          above carry over via the shared filter state, so Search opens
          with results already filtered. */}
      <Pressable
        onPress={() => hasSelection && goToName('Search')}
        disabled={!hasSelection}
        style={({ pressed }) => [
          styles.searchBtn,
          hasSelection ? styles.searchBtnActive : styles.searchBtnInactive,
          hasSelection && {
            shadowColor: colors.textPrimary,
            shadowOpacity: searchGlowOpacity,
            shadowRadius: searchGlowRadius,
            shadowOffset: { width: 0, height: 0 },
          },
          pressed && hasSelection && styles.searchBtnPressed,
        ]}
      >
        <Svg
          width={16}
          height={16}
          viewBox="0 0 24 24"
          fill="none"
          stroke={hasSelection ? colors.textPrimary : colors.textMuted}
          strokeWidth={2.2}
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <Circle cx={11} cy={11} r={7} />
          <Path d="M21 21l-4.3-4.3" />
        </Svg>
        <Text style={[styles.searchBtnText, { color: hasSelection ? colors.textPrimary : colors.textMuted }]}>
          Search
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    // Gives active chips' glow room to render fully instead of being
    // clipped flush against the row's own edge.
    padding: 6,
    margin: -6,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 22,
  },
  pressed: {
    opacity: 0.7,
  },
  label: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textPrimary,
  },
  searchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 46,
    borderRadius: 23,
    marginTop: 14,
  },
  // Empty/inert look until a category is picked.
  searchBtnInactive: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'transparent',
  },
  // "Lit up and ready" look once at least one category is active — white
  // border only, no solid fill (the breathing glow shadow, applied inline
  // where this is used, is what actually makes it read as lit up).
  searchBtnActive: {
    borderWidth: 2,
    borderColor: colors.textPrimary,
    backgroundColor: 'transparent',
  },
  searchBtnPressed: {
    opacity: 0.85,
  },
  searchBtnText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 14,
  },
});
