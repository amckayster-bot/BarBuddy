import { StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';

export default function RankingTile({ rank, title, subtitle }) {
  return (
    <View style={styles.tile}>
      <Text style={styles.number}>{rank}</Text>
      <View style={styles.textWrap}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>
      <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
        <Path d="M5 12h14M13 6l6 6-6 6" />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 16,
  },
  number: {
    fontFamily: fonts.displayBold,
    fontSize: 26,
    color: colors.amber,
    lineHeight: 26,
  },
  textWrap: {
    flex: 1,
  },
  title: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 15,
    color: colors.textPrimary,
    marginBottom: 3,
  },
  subtitle: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textMuted,
  },
});
