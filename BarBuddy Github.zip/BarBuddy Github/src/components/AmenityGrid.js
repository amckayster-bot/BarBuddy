import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Path, Rect } from 'react-native-svg';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';

// Known amenity -> icon mapping for the fixture data's exact labels.
// Anything not listed here falls back to a generic checkmark icon, since
// the full fixture set (across all 8 Boston venues) covers ~30 distinct
// amenity strings — not practical to hand-draw an icon for every one yet.
const ICONS = {
  'Reservations Required': (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
      <Rect x={4} y={3} width={16} height={18} rx={2} />
      <Path d="M9 8h6M9 12h6M9 16h3" />
    </Svg>
  ),
  'Live Piano': (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
      <Circle cx={12} cy={8} r={4} />
      <Path d="M12 12v9M8 21h8" />
    </Svg>
  ),
  'Small Plates': (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
      <Path d="M4 19h16M6 19V9l6-5 6 5v10" />
    </Svg>
  ),
  'Quiet Enough to Talk': (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
      <Path d="M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
    </Svg>
  ),
};

function GenericIcon() {
  return (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
      <Circle cx={12} cy={12} r={9} />
      <Path d="M9 12l2 2 4-4" />
    </Svg>
  );
}

export default function AmenityGrid({ items }) {
  return (
    <View style={styles.grid}>
      {items.map((label) => (
        <View key={label} style={styles.item}>
          {ICONS[label] || <GenericIcon />}
          <Text style={styles.label}>{label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    rowGap: 10,
  },
  item: {
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    padding: 12,
  },
  label: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12.5,
    color: colors.textPrimary,
    flexShrink: 1,
  },
});
