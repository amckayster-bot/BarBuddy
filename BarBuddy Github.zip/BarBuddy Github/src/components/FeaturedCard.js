import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import PhotoTag from './PhotoTag';

export default function FeaturedCard({ place }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('VenueDetail', { venueId: place.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <Image source={place.photo} style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={['rgba(12,15,22,0)', 'rgba(12,15,22,0.94)']}
        locations={[0.38, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.tagRow}>
        <PhotoTag label={place.ageAccess} />
      </View>
      <View style={styles.content}>
        <Text style={styles.name}>{place.name}</Text>
        <Text style={styles.meta}>
          {place.category} · {place.neighborhood}
        </Text>
        <View style={styles.pulse}>
          <View style={styles.dot} />
          <Text style={styles.pulseText}>{place.attending} going tonight</Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.85,
  },
  card: {
    height: 220,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
  },
  tagRow: {
    position: 'absolute',
    top: 14,
    left: 14,
  },
  content: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    right: 16,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 20,
    color: colors.textPrimary,
    marginBottom: 4,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    marginBottom: 10,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.amber,
  },
});
