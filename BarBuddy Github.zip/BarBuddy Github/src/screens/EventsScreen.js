import PlaceholderScreen from './PlaceholderScreen';

export default function EventsScreen() {
  return (
    <PlaceholderScreen
      iconName="events"
      title="Events Near Me"
      subtitle="Live music, DJ sets, trivia nights, karaoke, and happy hours — user-reported and curated listings land here."
    />
  );
}
