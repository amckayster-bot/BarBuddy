import PlaceholderScreen from './PlaceholderScreen';

export default function AssistantScreen() {
  return (
    <PlaceholderScreen
      iconName="assistant"
      title="AI Assistant"
      subtitle="A full night-out itinerary planner, not just single-place recommendations. Planned for v2."
    />
  );
}
