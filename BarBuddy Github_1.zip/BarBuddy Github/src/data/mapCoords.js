// mapCoords.js
//
// Shared map coordinate data — used by both the full interactive MapScreen
// and the small Home preview (MapPlaceholder), so the two stay in sync
// rather than drifting apart with their own separate copies.
//
// Approximate neighborhood-center coordinates (the fixture data only has
// street addresses, not lat/lng) — close enough for a visual placeholder,
// not meant to be precise geocoding.
import { colors } from '../theme/colors';

export const TD_GARDEN = { name: 'TD Garden', lat: 42.3662, lng: -71.0621 };

export const NEIGHBORHOOD_COORDS = {
  Seaport: [42.3506, -71.0459],
  'South End': [42.3428, -71.0729],
  'Theater District': [42.3517, -71.0648],
  'Beacon Hill': [42.3588, -71.0616],
  'Back Bay': [42.3467, -71.0862],
  'Fort Point': [42.3466, -71.0439],
  Fenway: [42.3467, -71.0975],
  Downtown: [42.3576, -71.0598],
  'Jamaica Plain': [42.3097, -71.1151],
};

// Same rating-badge color scale already used elsewhere (see colors.js's
// "Rating badge scale" tokens) — reused here so a venue's map pin and its
// rating badge anywhere else in the app agree on what "a 4.5" looks like,
// rather than the map inventing its own separate color meaning.
function ratingColor(rating) {
  if (rating >= 4.5) return colors.ratingGreen;
  if (rating >= 4.0) return colors.ratingYellow;
  if (rating >= 3.5) return colors.ratingOrange;
  return colors.ratingRed;
}

// Maps bostonVenues.json entries to plottable {name, category, neighborhood,
// lat, lng, rating, color} markers, skipping any venue whose neighborhood
// isn't in the coordinate table above. `color` is pre-computed here (rather
// than inside the injected map HTML) so leafletMapHtml.js doesn't need its
// own copy of the rating-threshold logic.
export function venueMarkers(venues) {
  return venues
    .filter((v) => NEIGHBORHOOD_COORDS[v.neighborhood])
    .map((v) => {
      const [lat, lng] = NEIGHBORHOOD_COORDS[v.neighborhood];
      return {
        name: v.name,
        category: v.category,
        neighborhood: v.neighborhood,
        lat,
        lng,
        rating: v.rating,
        color: ratingColor(v.rating),
      };
    });
}
