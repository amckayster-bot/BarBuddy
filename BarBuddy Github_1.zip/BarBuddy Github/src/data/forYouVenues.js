// forYouVenues.js
//
// Powers the "For You" AI-planner chat (ForYouScreen.js). This was ported
// from a Claude Design export (`Bar Buddy For You Page.dc.html`) that shipped
// with its own separate hardcoded venue array — but that array turned out to
// use the exact same 10 venue ids as the app's existing SEARCH_VENUES fixture
// (see searchVenues.js), so rather than duplicate venue data a second time,
// this file just layers the one thing SEARCH_VENUES doesn't have — a short
// "vibe" keyword string per venue, lifted straight from the design — on top
// of it. name/photo/category/etc. all stay sourced from SEARCH_VENUES, so a
// venue only ever needs to be edited in one place.
import { SEARCH_VENUES } from './searchVenues';

const VIBE_KEYWORDS = {
  'wharf-house': 'upscale scenic rooftop cocktails skyline views date night',
  'iron-anchor': 'dive bar cheap drinks kitschy no cover casual low-key',
  frequency: 'high energy dance club dj nightlife loud late',
  'velvet-owl': 'speakeasy intimate cocktails quiet moody low-key jazz-adjacent',
  'strike-barrel': 'games bowling arcade group fun casual no cover',
  'harborlight-brewing': 'craft beer casual taproom relaxed daytime-friendly',
  'sundown-sports': 'sports bar big screens loud group friendly casual',
  'noir-newbury': 'wine bar quiet intimate date night low-key elegant',
  'the-sinclair': 'live music concert energetic loud bands',
  'mikes-diner': 'late night food casual comfort no cover',
};

export const FOR_YOU_VENUES = SEARCH_VENUES.map((v) => ({
  ...v,
  vibe: VIBE_KEYWORDS[v.id] || '',
}));

// A default trio to fall back on when a request doesn't match anything by
// keyword, so the itinerary never comes back empty — one bar, one
// activity, one lower-key option, mirroring the design's own fallback set.
const FALLBACK_IDS = ['wharf-house', 'strike-barrel', 'harborlight-brewing'];

// Same scoring approach as the design: split the request into words, score
// each venue by how many of those words show up across its category,
// subcategory, neighborhood, and vibe tags, then take the top 3 with a
// score above zero. No backend/LLM involved — this is a local, deterministic
// keyword match, consistent with how the rest of the app stands in for a
// real backend (see placeholderData.js).
export function pickVenuesByKeyword(query, venues = FOR_YOU_VENUES) {
  const q = query.toLowerCase();
  const words = q.split(/[\s,]+/).filter((w) => w.length > 2);

  const scored = venues.map((v) => {
    const hay = `${v.category} ${v.subcategory} ${v.neighborhood} ${v.vibe}`.toLowerCase();
    const score = words.reduce((n, word) => (hay.includes(word) ? n + 1 : n), 0);
    return { v, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored.filter((s) => s.score > 0).slice(0, 3).map((s) => s.v);
  if (top.length >= 2) return top;

  return FALLBACK_IDS.map((id) => venues.find((v) => v.id === id)).filter(Boolean);
}

// Warm, varied itinerary pitches built from the matched venues — the local
// stand-in for the design's window.claude.complete() call (that global only
// exists inside the Claude Design preview sandbox, not in the real app).
// Picking randomly between a few templates keeps repeated requests from
// reading like a form letter.
const TEMPLATES = [
  (text, names) => `Here's a night built around "${text}": ${names.join(' → ')}.`,
  (text, names) =>
    names.length > 2
      ? `Picture this: start at ${names[0]}, drift over to ${names[1]}, and wind down at ${names[2]}, a night that matches "${text}".`
      : `Picture this: start at ${names[0]} and drift over to ${names[1]}, a night that matches "${text}".`,
  (text, names) => `For "${text}," I'd map it out as ${names.join(' → ')}. Each stop keeps building on the last.`,
  (text, names) => `"${text}" - got it. ${names.join(', then ')} should cover it nicely.`,
];

export function buildItineraryReply(text, venues) {
  const names = venues.map((v) => v.name);
  const template = TEMPLATES[Math.floor(Math.random() * TEMPLATES.length)];
  return template(text.trim(), names);
}
