// events.js
//
// Events fixture data for the Events tab skeleton (per CLAUDE.md's "Events
// screen skeleton" item this round) — visual-only placeholder data, no real
// backend/scraper yet, same honesty-about-placeholder approach as the rest
// of this app's fixtures (see placeholderData.js's DISTANCES note).
//
// Each event happens AT one of the existing 9 bostonVenues.json venues, and
// borrows that venue's real photo, rating, description, atmosphere,
// address, and reviews for Event Detail — rather than inventing a second,
// parallel set of fake venue details.
//
// `category` is pulled from searchVenues.js's existing per-venue category
// assignment (bars/clubs/lounges/etc.), so each event card's color dot
// reuses the exact same CATEGORY_DEFS colors already used throughout
// Search — one category-color system, not a second one just for Events.
import bostonVenues from './bostonVenues.json';
import { SEARCH_VENUES } from './searchVenues';

function venueFor(id) {
  const venue = bostonVenues.find((v) => v.id === id);
  const search = SEARCH_VENUES.find((v) => v.id === id);
  if (!venue || !search) throw new Error(`Unknown venue id in events.js: ${id}`);
  return { venue, search };
}

// dayOffset: 0 = Today, 1 = Tomorrow, 2+ = further out. Spread out on
// purpose (like placeholderData.js's DEALS) so the date strip has something
// most days rather than everything clustering on "Today."
const RAW_EVENTS = [
  { id: 'iron-anchor-trivia', venueId: 'iron-anchor', title: 'Anchor Trivia Night', eventType: 'Trivia Night', dayOffset: 0, startMinutes: 19 * 60, startLabel: '7:00 PM', going: 38 },
  { id: 'frequency-saturday', venueId: 'frequency', title: 'Saturday Set', eventType: 'DJ Set', dayOffset: 0, startMinutes: 22 * 60, startLabel: '10:00 PM', going: 210 },
  { id: 'velvet-owl-jazz', venueId: 'velvet-owl', title: 'Late Night Jazz', eventType: 'Live Music', dayOffset: 0, startMinutes: 21 * 60, startLabel: '9:00 PM', going: 64 },
  { id: 'sundown-happy-hour', venueId: 'sundown-sports', title: 'Happy Hour Kickoff', eventType: 'Happy Hour', dayOffset: 0, startMinutes: 17 * 60, startLabel: '5:00 PM', going: 52 },
  { id: 'backbeat-locals', venueId: 'backbeat-lounge', title: 'Local Acts Showcase', eventType: 'Live Music', dayOffset: 1, startMinutes: 20 * 60 + 30, startLabel: '8:30 PM', going: 47 },
  { id: 'noir-wine-tasting', venueId: 'noir-newbury', title: 'Wine Flight Tasting', eventType: 'Tasting', dayOffset: 1, startMinutes: 18 * 60 + 30, startLabel: '6:30 PM', going: 29 },
  { id: 'strike-league-night', venueId: 'strike-barrel', title: 'League Night Open Play', eventType: 'Bowling', dayOffset: 2, startMinutes: 19 * 60 + 30, startLabel: '7:30 PM', going: 33 },
  { id: 'harborlight-tap-takeover', venueId: 'harborlight-brewing', title: 'Guest Brewer Tap Takeover', eventType: 'Tap Takeover', dayOffset: 2, startMinutes: 18 * 60, startLabel: '6:00 PM', going: 41 },
  { id: 'wharf-house-karaoke', venueId: 'wharf-house', title: 'Rooftop Karaoke', eventType: 'Karaoke', dayOffset: 3, startMinutes: 20 * 60, startLabel: '8:00 PM', going: 58 },
];

export const EVENTS = RAW_EVENTS.map((e) => {
  const { venue, search } = venueFor(e.venueId);
  return {
    id: e.id,
    title: e.title,
    eventType: e.eventType,
    venueId: venue.id,
    venueName: venue.name,
    neighborhood: venue.neighborhood,
    category: search.category,
    dayOffset: e.dayOffset,
    startMinutes: e.startMinutes,
    startLabel: e.startLabel,
    goingTonight: e.going,
    photo: venue.photos[0],
    ageAccess: venue.ageAccess,
    rating: venue.rating,
    reviewCount: venue.reviewCount,
    description: `${e.eventType} at ${venue.name}. ${venue.description}`,
    atmosphere: venue.atmosphere,
    address: venue.address,
    reviewsUrl: venue.reviewsUrl,
    reviews: venue.reviews,
  };
});

export function eventById(id) {
  return EVENTS.find((e) => e.id === id) || null;
}

export function eventsForDay(dayOffset) {
  return EVENTS.filter((e) => e.dayOffset === dayOffset)
    .slice()
    .sort((a, b) => a.startMinutes - b.startMinutes);
}

export function trendingTonight(limit = 6) {
  return EVENTS.filter((e) => e.dayOffset === 0)
    .slice()
    .sort((a, b) => b.goingTonight - a.goingTonight)
    .slice(0, limit);
}

// Runs on the user's phone at render time (not inside any script sandbox),
// so a real Date is exactly right here — this just labels the date strip's
// pills, it doesn't drive any fixture generation.
export function dayLabel(dayOffset) {
  if (dayOffset === 0) return 'Today';
  if (dayOffset === 1) return 'Tomorrow';
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}
