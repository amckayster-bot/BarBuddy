// Home screen card data, derived from the shared Boston fixture dataset —
// so a venue tapped on Home resolves to the same real id VenueDetailScreen
// looks up.
//
// bostonVenues.json now holds real, currently-operating Boston venues (name,
// address, neighborhood, category) with real free-license photography —
// only the ratings/review counts/reviews/"going tonight" numbers are still
// illustrative placeholders, since there's no backend yet. The `id` slugs
// (wharf-house, velvet-owl, etc.) are historical from the original fictional
// fixture data and no longer describe the real venue now in that slot
// (e.g. "velvet-owl" -> Carrie Nation Cocktail Club) — left as-is rather
// than renamed, since they're internal keys other code references, not
// anything shown to a user.
import bostonVenues from './bostonVenues.json';

function findVenue(id) {
  const venue = bostonVenues.find((v) => v.id === id);
  if (!venue) throw new Error(`Unknown venue id in placeholderData: ${id}`);
  return venue;
}

function photoFor(venue) {
  return { uri: venue.photos[0] };
}

// Illustrative-only distances — no real geolocation yet. Values match the
// approved home-final-skeleton.html template's Near You wheel exactly
// (ascending order top to bottom).
const DISTANCES = {
  'iron-anchor': '0.4 mi',
  'wharf-house': '0.9 mi',
  'velvet-owl': '1.1 mi',
  'strike-barrel': '1.4 mi',
  'harborlight-brewing': '1.6 mi',
  'sundown-sports': '1.8 mi',
  'noir-newbury': '2.0 mi',
  frequency: '2.1 mi',
  'backbeat-lounge': '2.3 mi',
};

function toCard(id) {
  const venue = findVenue(id);
  return {
    id: venue.id,
    name: venue.name,
    photo: photoFor(venue),
    category: venue.category,
    distance: DISTANCES[venue.id] || 'N/A',
    ageAccess: venue.ageAccess,
  };
}

const featuredVenue = findVenue('frequency');
export const featuredPlace = {
  id: featuredVenue.id,
  name: featuredVenue.name,
  photo: photoFor(featuredVenue),
  category: featuredVenue.category,
  neighborhood: featuredVenue.neighborhood,
  ageAccess: featuredVenue.ageAccess,
  attending: featuredVenue.goingTonight,
  // Added this round — Featured's new tap-to-reveal interaction (see
  // FeaturedCard.js) shows a star rating as part of its staggered text
  // reveal, same as Venue/Event Detail's own Rating block.
  rating: featuredVenue.rating,
};

// All 9 fixture venues, in the wheel's approved display order — the Near
// You "wheel" (see NearYouSection.js) shows all of them, not a curated
// subset like the old horizontal-carousel version did.
export const nearYouPlaces = [
  'iron-anchor',
  'wharf-house',
  'velvet-owl',
  'strike-barrel',
  'harborlight-brewing',
  'sundown-sports',
  'noir-newbury',
  'frequency',
  'backbeat-lounge',
].map(toCard);

export const mapNearbyCount = 6;

// --- Below this point: superseded by the Home screen rebuild to the
// CLAUDE.md "Home Screen (FINAL)" spec — HomeScreen.js no longer imports
// topTenBoston, homeDeals, or DEALS. Left in place rather than deleted
// (nothing currently reads them) in case they're useful again for a
// dedicated "Top Places" / "Deals" screen later, per the Browse row's
// utility tiles pointing at not-yet-built destinations. ---

// Top Ten in Boston — fixture ratings are out of 5; doubled here to out of
// 10 per the rating-badge scale. Sourced straight from bostonVenues.json.
export const topTenBoston = bostonVenues
  .slice()
  .sort((a, b) => b.rating - a.rating)
  .slice(0, 10)
  .map((venue) => ({
    id: venue.id,
    name: venue.name,
    score: Math.round(venue.rating * 2 * 10) / 10,
  }));

// Deals — for the segment of people whose main question is "who's got
// something good going on nearby right now," not just "what's nearby."
// Illustrative copy (no real deals backend yet),
// same honesty-about-placeholder-data approach as DISTANCES above. Each
// entry pairs a short badge (`tag`, shown on the card) with the fuller
// one-line description (`text`); `endsLabel` is optional urgency copy
// ("Ends 7PM") for time-boxed deals, omitted for standing/every-night ones.
//
// `days` is which days of the week (0 = Sunday ... 6 = Saturday, matching
// Date#getDay()) the deal is actually running — drives the "Today" badge on
// DealsSection's cards. Spread out on purpose so most days of the week have
// at least one deal live, rather than everything clustering on the same
// couple of days.
const DEALS = [
  {
    id: 'sundown-sports',
    tag: 'Happy Hour',
    text: '$5 drafts and half-off apps',
    endsLabel: 'Ends 7PM',
    days: [1, 2, 3, 4, 5], // Mon-Fri
  },
  {
    id: 'harborlight-brewing',
    tag: 'Flight Deal',
    text: 'Buy one flight, get one half off',
    endsLabel: 'Thursdays',
    days: [4], // Thu
  },
  {
    id: 'iron-anchor',
    tag: 'All Night',
    text: '$3 PBR pints, no cover',
    days: [5, 6], // Fri-Sat
  },
  {
    id: 'strike-barrel',
    tag: 'Bowling Special',
    text: 'Free duckpin lane with any drink purchase',
    endsLabel: 'Ends 8PM',
    days: [0], // Sun
  },
  {
    id: 'wharf-house',
    tag: 'Golden Hour',
    text: '$2 off every cocktail on the rooftop',
    endsLabel: 'Ends 6PM',
    days: [2, 3], // Tue-Wed
  },
  {
    id: 'noir-newbury',
    tag: 'Happy Hour',
    text: '25% off all wine flights',
    endsLabel: 'Ends 7PM',
    days: [1, 2], // Mon-Tue
  },
];

const todayIndex = new Date().getDay();

export const homeDeals = DEALS.map((deal) => {
  const venue = findVenue(deal.id);
  return {
    id: venue.id,
    name: venue.name,
    photo: photoFor(venue),
    neighborhood: venue.neighborhood,
    tag: deal.tag,
    text: deal.text,
    endsLabel: deal.endsLabel ?? null,
    isActiveToday: deal.days.includes(todayIndex),
  };
});
