// searchVenues.js
//
// Search results list — the 9 real, curated Boston venues from
// bostonVenues.json (re-tagged here with the Search screen's own
// category/subcategory taxonomy, see searchCategories.js), plus 2 extra
// venues that were part of the original "Bar Buddy Search Screen" design
// mock but aren't in the curated fixture set. Those 2 don't have a full
// VenueDetailScreen record, so SearchScreen only pushes to venue detail
// for entries with `linksToDetail: true`.
import bostonVenues from './bostonVenues.json';

const CATEGORY_ASSIGNMENTS = {
  'wharf-house': { category: 'bars', subcategory: 'Rooftop Bars' },
  'iron-anchor': { category: 'bars', subcategory: 'Dive Bars' },
  frequency: { category: 'clubs', subcategory: 'Nightclubs' },
  'velvet-owl': { category: 'lounges', subcategory: 'Speakeasies' },
  'strike-barrel': { category: 'arcades', subcategory: 'Bowling & Arcades' },
  'harborlight-brewing': { category: 'breweries', subcategory: 'Craft Breweries' },
  'sundown-sports': { category: 'bars', subcategory: 'Sports Bars' },
  'noir-newbury': { category: 'bars', subcategory: 'Wine Bars' },
  // Added along with the new Home "Near You" wheel's 9th row — see
  // bostonVenues.json.
  'backbeat-lounge': { category: 'live-music', subcategory: 'Jazz Clubs' },
};

const EXTRA_VENUES = [
  {
    id: 'the-sinclair',
    name: 'The Sinclair',
    category: 'live-music',
    subcategory: 'Concert Halls',
    neighborhood: 'Allston',
    ageAccess: '18+',
    photo: 'https://images.unsplash.com/photo-1781873278537-52613f38eb6c?w=1000&h=700&fit=crop&q=80',
  },
  {
    id: 'mikes-diner',
    name: "Mike's All-Night Diner",
    category: 'late-night-eats',
    subcategory: 'Diners',
    neighborhood: 'Cambridge',
    ageAccess: 'All Ages',
    photo: 'https://images.unsplash.com/photo-1759171053149-d5cce4261405?w=1000&h=700&fit=crop&q=80',
  },
];

export const SEARCH_VENUES = [
  ...bostonVenues
    .filter((v) => CATEGORY_ASSIGNMENTS[v.id])
    .map((v) => ({
      id: v.id,
      name: v.name,
      category: CATEGORY_ASSIGNMENTS[v.id].category,
      subcategory: CATEGORY_ASSIGNMENTS[v.id].subcategory,
      neighborhood: v.neighborhood,
      ageAccess: v.ageAccess,
      photo: v.photos[0],
      linksToDetail: true,
    })),
  ...EXTRA_VENUES.map((v) => ({ ...v, linksToDetail: false })),
];
