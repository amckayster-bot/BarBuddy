// SearchScreen.js
//
// Implements the "Bar Buddy Search Screen" design import: a search bar,
// horizontal category-pill row, per-category expandable subcategory filter
// blocks, and a filtered venue results list (or an empty state). Wired up
// as its own bottom tab (see RootNavigator.js / BottomNav.js) rather than a
// pushed stack screen, which is the one deliberate departure from the
// design — the header's circular icon chip is a plain search glyph instead
// of a back chevron, since a root tab has nothing to go "back" to.
//
// Animation note: category-block enter/exit and subcategory-pill stagger
// fade-ins are driven by plain requestAnimationFrame + elapsed time, not
// RN's `Animated` API or CSS transitions (the design used CSS transitions,
// which don't exist in React Native) — same reasoning as the rest of this
// app's animated pieces, see AnimatedGradientBackground.js's
// animation-driver note.
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View, Image } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import { glow } from '../theme/glow';
import { useBreathingGlow } from '../hooks/useBreathingGlow';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import { CATEGORY_DEFS } from '../data/searchCategories';
import { SEARCH_VENUES } from '../data/searchVenues';
import { useSearchFilters } from '../context/SearchFilterContext';

const SUB_FADE_MS = 220;
const SUB_STAGGER_MS = 60;
const BLOCK_EXIT_MS = 280;

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

// One subcategory pill inside a category block — fades/slides in once on
// mount, staggered by `delayMs`, mirroring the design's bbFadeInLeft
// keyframe + per-index animationDelay.
function SubPill({ label, active, color, fill, delayMs, onPress }) {
  const [t, setT] = useState(0);
  const rafRef = useRef(null);

  useEffect(() => {
    const start = performance.now();
    const tick = (now) => {
      const elapsed = now - start - delayMs;
      if (elapsed < 0) {
        rafRef.current = requestAnimationFrame(tick);
        return;
      }
      const p = Math.min(1, elapsed / SUB_FADE_MS);
      setT(p);
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // Intentionally empty deps — this is a one-shot mount animation, not
    // something that should re-fire when `active` toggles later.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const eased = easeOutCubic(t);

  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.subPill,
        {
          opacity: eased,
          transform: [{ translateX: (1 - eased) * -10 }],
          borderWidth: active ? 1.5 : 1,
          borderColor: active ? fill : `${color}55`,
          backgroundColor: active ? `${fill}1F` : 'transparent',
        },
        active && glow(fill),
      ]}
    >
      <Text style={[styles.subPillText, { color: active ? fill : colors.textMuted, fontWeight: active ? '600' : '400' }]}>
        {label}
      </Text>
    </Pressable>
  );
}

// One expanded category's subcategory block. Stays mounted (and animates
// its own opacity/translateX out) for BLOCK_EXIT_MS after `active` flips to
// false, then tells the parent to actually remove it via `onExited` — same
// two-phase "displayCategories vs activeCategories" split the design used,
// just driven by RAF instead of a CSS transition + setTimeout pair.
function CategoryBlock({ def, active, activeSubs, onToggleSub, onExited }) {
  const [exitT, setExitT] = useState(0);
  const wasActiveRef = useRef(active);
  const rafRef = useRef(null);

  useEffect(() => {
    if (wasActiveRef.current && !active) {
      const start = performance.now();
      const tick = (now) => {
        const p = Math.min(1, (now - start) / BLOCK_EXIT_MS);
        setExitT(p);
        if (p < 1) {
          rafRef.current = requestAnimationFrame(tick);
        } else {
          onExited(def.key);
        }
      };
      rafRef.current = requestAnimationFrame(tick);
    }
    wasActiveRef.current = active;
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  const activeList = activeSubs[def.key] || [];

  return (
    <View style={{ opacity: 1 - exitT, transform: [{ translateX: -8 * exitT }] }}>
      <View style={styles.blockHeader}>
        <View style={[styles.blockDot, { backgroundColor: def.color }]} />
        <Text style={[styles.blockLabel, { color: def.color }]}>{def.label}</Text>
      </View>
      <View style={styles.subRow}>
        {def.subs.map((label, idx) => (
          <SubPill
            key={label}
            label={label}
            active={activeList.includes(label)}
            color={def.color}
            fill={def.fill}
            delayMs={idx * SUB_STAGGER_MS}
            onPress={() => onToggleSub(def.key, label)}
          />
        ))}
      </View>
    </View>
  );
}

// One top-level category pill. Its own component (rather than inline JSX
// in a .map()) purely so useBreathingGlow — a hook — can legally be called
// once per pill instance, matching the equivalent chip on Home (see
// InspirationCategories.js).
function CatPill({ def, active, onPress }) {
  const { shadowOpacity, shadowRadius } = useBreathingGlow(active);

  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.catPill,
        {
          borderWidth: active ? 1.5 : 1,
          borderColor: active ? def.fill : colors.border,
          backgroundColor: active ? `${def.fill}1F` : 'transparent',
        },
        active && {
          shadowColor: def.fill,
          shadowOpacity,
          shadowRadius,
          shadowOffset: { width: 0, height: 0 },
        },
      ]}
    >
      <Text style={[styles.catPillText, { color: active ? def.fill : colors.textMuted, fontWeight: active ? '600' : '400' }]}>
        {def.label}
      </Text>
    </Pressable>
  );
}

function VenueResultCardBody({ venue }) {
  return (
    <>
      <View style={styles.resultPhotoWrap}>
        <Image source={{ uri: venue.photo }} style={styles.resultPhoto} resizeMode="cover" />
        <View style={styles.ageBadge}>
          <Text style={styles.ageBadgeText}>{venue.ageAccess}</Text>
        </View>
      </View>
      <View style={styles.resultInfo}>
        <Text style={styles.resultName}>{venue.name}</Text>
        <Text style={styles.resultMeta}>
          {venue.subcategory} · {venue.neighborhood}
        </Text>
      </View>
    </>
  );
}

// The 2 extra venues that aren't in bostonVenues.json (see searchVenues.js)
// don't have a real detail page to push to, so they render as a plain,
// non-interactive card instead of a Pressable one.
function VenueResultCard({ venue, onPress }) {
  if (!venue.linksToDetail) {
    return (
      <View style={styles.resultCard}>
        <VenueResultCardBody venue={venue} />
      </View>
    );
  }
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.resultCard, pressed && styles.resultCardPressed]}>
      <VenueResultCardBody venue={venue} />
    </Pressable>
  );
}

export default function SearchScreen() {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [fontsLoaded] = useAppFonts();

  // activeCategories/activeSubs are shared with Home's "Need Inspiration?"
  // chips via context (see SearchFilterContext) — a category picked on
  // either screen shows as active on both. displayCategories stays local:
  // it's purely an animation bookkeeping list (which category blocks are
  // still mounted, including ones currently playing their fade-out), not
  // filter state anything else needs to read.
  const {
    activeCategories,
    activeSubs,
    toggleCategory,
    toggleSub,
    clearFilters: clearContextFilters,
    pendingQuery,
    clearPendingQuery,
  } = useSearchFilters();
  const [searchText, setSearchText] = useState('');
  const [displayCategories, setDisplayCategories] = useState(() => [...activeCategories]);

  // Picks up categories that became active from somewhere other than this
  // screen's own pill row (i.e. a Home chip) and mounts their block here
  // too. A category deactivated elsewhere is left alone until its
  // CategoryBlock finishes its own exit animation, same as a local toggle.
  useEffect(() => {
    setDisplayCategories((prev) => {
      const missing = activeCategories.filter((k) => !prev.includes(k));
      return missing.length ? [...prev, ...missing] : prev;
    });
  }, [activeCategories]);

  // Picks up a query handed off from Home's Compact Search Bar
  // (CompactSearchBar.js submits it via SearchFilterContext's
  // submitSearchQuery) and drops it straight into this screen's own search
  // box, then clears it — so it behaves exactly like the text was typed and
  // submitted right here, and doesn't linger to reappear on a later visit.
  useEffect(() => {
    if (pendingQuery != null) {
      setSearchText(pendingQuery);
      clearPendingQuery();
    }
  }, [pendingQuery, clearPendingQuery]);

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  const handleBlockExited = (key) => {
    setDisplayCategories((prev) => prev.filter((k) => k !== key));
  };

  // Clear All wipes activeCategories AND displayCategories in the same
  // update, so blocks unmount instantly rather than playing their exit
  // animation — matching the design, where individual pill toggle-off
  // animates but the bulk "Clear All" doesn't.
  const clearFilters = () => {
    clearContextFilters();
    setDisplayCategories([]);
  };

  const clearFiltersAndSearch = () => {
    clearFilters();
    setSearchText('');
  };

  const q = searchText.trim().toLowerCase();
  const filteredVenues = SEARCH_VENUES.filter((v) => {
    if (activeCategories.length && !activeCategories.includes(v.category)) return false;
    const subsForCat = activeSubs[v.category];
    if (subsForCat && subsForCat.length && !subsForCat.includes(v.subcategory)) return false;
    if (q) {
      const hay = `${v.name} ${v.subcategory} ${v.neighborhood}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const count = filteredVenues.length;
  const hasActiveCategories = activeCategories.length > 0;
  const hasDisplayCategories = displayCategories.length > 0;

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + spacing.lg }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerRow}>
          <View style={styles.headerIcon}>
            <Svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
              <Circle cx={11} cy={11} r={7} />
              <Path d="M21 21l-4.3-4.3" />
            </Svg>
          </View>
          <Text style={styles.headerTitle}>Search</Text>
        </View>

        <View style={styles.searchBar}>
          <Svg width={17} height={17} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
            <Circle cx={11} cy={11} r={7} />
            <Path d="M21 21l-4.3-4.3" />
          </Svg>
          <TextInput
            value={searchText}
            onChangeText={setSearchText}
            placeholder="Search venues, events, neighborhoods..."
            placeholderTextColor={colors.textMuted}
            style={styles.searchInput}
          />
          {searchText.length > 0 && (
            <Pressable onPress={() => setSearchText('')} style={styles.clearChip} hitSlop={8}>
              <Svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2.4} strokeLinecap="round">
                <Path d="M6 6l12 12M18 6L6 18" />
              </Svg>
            </Pressable>
          )}
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catRow}>
          {CATEGORY_DEFS.map((c) => (
            <CatPill key={c.key} def={c} active={activeCategories.includes(c.key)} onPress={() => toggleCategory(c.key)} />
          ))}
        </ScrollView>

        {hasDisplayCategories && (
          <View style={styles.blocksWrap}>
            {displayCategories.map((key) => {
              const def = CATEGORY_DEFS.find((c) => c.key === key);
              if (!def) return null;
              return (
                <CategoryBlock
                  key={key}
                  def={def}
                  active={activeCategories.includes(key)}
                  activeSubs={activeSubs}
                  onToggleSub={toggleSub}
                  onExited={handleBlockExited}
                />
              );
            })}
          </View>
        )}

        <View style={styles.resultsHeaderRow}>
          <Text style={styles.resultsLabel}>
            {count} result{count === 1 ? '' : 's'}
          </Text>
          {hasActiveCategories && (
            <Pressable onPress={clearFilters} hitSlop={6}>
              <Text style={styles.clearAllText}>Clear All</Text>
            </Pressable>
          )}
        </View>

        {count > 0 ? (
          <View style={styles.resultsList}>
            {filteredVenues.map((v) => (
              <VenueResultCard
                key={v.id}
                venue={v}
                onPress={() => navigation.navigate('VenueDetail', { venueId: v.id })}
              />
            ))}
          </View>
        ) : (
          <View style={styles.emptyState}>
            <View style={styles.emptyIcon}>
              <Svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
                <Circle cx={11} cy={11} r={7} />
                <Path d="M21 21l-4.3-4.3" />
              </Svg>
            </View>
            <Text style={styles.emptyTitle}>No matches found</Text>
            <Text style={styles.emptyBody}>
              Try a different search term, or clear your filters to see everything nearby.
            </Text>
            <Pressable onPress={clearFiltersAndSearch} style={styles.emptyClearBtn}>
              <Text style={styles.emptyClearText}>Clear Filters</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 28,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 18,
  },
  headerIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(23,27,36,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontFamily: fonts.displayBold,
    fontSize: 20,
    color: colors.textPrimary,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    color: colors.textPrimary,
    padding: 0,
  },
  clearChip: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  // The horizontal ScrollView sizes its own height to exactly this content
  // container's height — with no vertical padding, that left zero room for
  // the active pills' glow to render above/below them, so it was getting
  // clipped top and bottom (visible only left/right). paddingVertical gives
  // the halo somewhere to actually draw.
  catRow: {
    gap: 8,
    paddingVertical: 10,
  },
  catPill: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
  },
  catPillText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
  },
  blocksWrap: {
    gap: 10,
    marginTop: 14,
  },
  blockHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 7,
  },
  blockDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  blockLabel: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  subRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 7,
  },
  subPill: {
    paddingHorizontal: 13,
    paddingVertical: 7,
    borderRadius: 16,
  },
  subPillText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
  },
  resultsHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 20,
    marginBottom: 12,
  },
  resultsLabel: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  clearAllText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13,
    color: colors.textPrimary,
  },
  resultsList: {
    gap: 14,
  },
  resultCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
    overflow: 'hidden',
  },
  resultCardPressed: {
    opacity: 0.85,
  },
  resultPhotoWrap: {
    height: 150,
    position: 'relative',
  },
  resultPhoto: {
    width: '100%',
    height: '100%',
  },
  ageBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    backgroundColor: 'rgba(12,15,22,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.25)',
  },
  ageBadgeText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.textPrimary,
  },
  resultInfo: {
    padding: 14,
    paddingTop: 12,
  },
  resultName: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 16,
    color: colors.textPrimary,
    marginBottom: 3,
  },
  resultMeta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 24,
  },
  emptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(23,27,36,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 16,
    color: colors.textPrimary,
    marginBottom: 6,
  },
  emptyBody: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 19.5,
    textAlign: 'center',
    maxWidth: 230,
    marginBottom: 20,
  },
  emptyClearBtn: {
    paddingHorizontal: 22,
    paddingVertical: 11,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(23,27,36,0.6)',
  },
  emptyClearText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13,
    color: colors.textPrimary,
  },
});
