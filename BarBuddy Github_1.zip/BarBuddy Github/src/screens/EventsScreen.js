// EventsScreen.js
//
// First-pass skeleton per CLAUDE.md's Events tab spec: a horizontal date
// strip at the top, a "Trending Tonight" rail below it, then a vertical
// list of the selected day's events sorted by start time. Visual only for
// now, consistent with the rest of the app's current phase — this replaces
// the earlier bare PlaceholderScreen stand-in.
import { useMemo, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import DateStrip from '../components/DateStrip';
import TrendingRail from '../components/TrendingRail';
import EventCard from '../components/EventCard';
import { eventsForDay, trendingTonight } from '../data/events';

export default function EventsScreen() {
  const [fontsLoaded] = useAppFonts();
  const [selectedDay, setSelectedDay] = useState(0);

  const dayEvents = useMemo(() => eventsForDay(selectedDay), [selectedDay]);
  const trending = useMemo(() => trendingTonight(), []);

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      {/* This screen's own vertical scroll is a plain-content scroll (not a
          horizontal carousel), so — same reasoning as Near You's wheel in
          HomeScreen.js — it's fine as RN core's ScrollView; the page
          pager's failOffsetY already bows out of vertical drags on its own.
          DateStrip and TrendingRail below are a different story — they're
          HORIZONTAL scrollers nested inside this vertical one, which is
          nested inside the horizontally-swipeable tab pager, so they use
          gesture-handler's ScrollView + the TabPagerContext touch flag
          instead (see their own files) — the exact fix Near You/Deals
          needed back when they were horizontal carousels. */}
      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.pageTitle}>Events</Text>

        <View style={styles.section}>
          <DateStrip selected={selectedDay} onSelect={setSelectedDay} />
        </View>

        {trending.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Trending Tonight</Text>
            <TrendingRail events={trending} />
          </View>
        )}

        <View style={[styles.section, styles.lastSection]}>
          <Text style={styles.sectionLabel}>{dayEvents.length > 0 ? 'All Events' : 'No Events Yet'}</Text>
          {dayEvents.length > 0 ? (
            dayEvents.map((event) => <EventCard key={event.id} event={event} />)
          ) : (
            <Text style={styles.empty}>Nothing on the books for this day yet. Check another day above.</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 28,
  },
  pageTitle: {
    fontFamily: fonts.displayBold,
    fontSize: 22,
    color: colors.textPrimary,
    marginTop: 8,
    marginBottom: spacing.xl,
  },
  section: {
    marginBottom: spacing.xxl,
  },
  lastSection: {
    marginBottom: 0,
  },
  sectionLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 12,
  },
  empty: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
});
