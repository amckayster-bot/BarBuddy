// MapScreen.js
//
// Real interactive map — pan/zoom, actual streets and roads — opened by
// tapping the Map preview on Home. Built with Leaflet (via a WebView)
// rendering CARTO's free "Dark Matter" tile set (see leafletMapHtml.js for
// the shared HTML builder both this screen and the Home preview use).
//
// Why WebView + Leaflet instead of react-native-maps: this project runs
// entirely through Expo Go for preview (no Mac/Xcode — see project
// CLAUDE.md), and react-native-maps needs a custom dev client / EAS build
// to work, plus a Google Maps API key on Android. react-native-webview
// works in plain Expo Go with zero extra setup, so this keeps the
// "scan the QR code and it just works" preview flow intact.
//
// TD Garden is the map's main point of reference — the map opens centered
// on it, and it gets its own highlighted amber marker (amber = "here"/
// landmark, matching the app's existing amber-for-current-spot convention)
// so it reads as the anchor rather than just another venue. The real
// venues from bostonVenues.json plot around it as colored rating-badge
// pins (see leafletMapHtml.js / mapCoords.js's venueMarkers()) — each pin
// shows that venue's rating, colored on the same red/orange/yellow/green
// scale used for rating badges elsewhere in the app.
import { useMemo } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Path } from 'react-native-svg';
import { StatusBar } from 'expo-status-bar';
import { colors } from '../theme/colors';
import bostonVenues from '../data/bostonVenues.json';
import { TD_GARDEN, venueMarkers } from '../data/mapCoords';
import { buildLeafletMapHtml } from '../components/leafletMapHtml';

export default function MapScreen() {
  const navigation = useNavigation();
  const markers = useMemo(() => venueMarkers(bostonVenues), []);
  const html = useMemo(
    () =>
      buildLeafletMapHtml({
        center: TD_GARDEN,
        zoom: 14,
        markers,
        highlightMarker: {
          lat: TD_GARDEN.lat,
          lng: TD_GARDEN.lng,
          color: colors.amber,
          label: `<b>${TD_GARDEN.name}</b><br/>Home base - Celtics & Bruins`,
          openPopup: true,
        },
        interactive: true,
      }),
    [markers]
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <StatusBar style="light" />
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        style={styles.webview}
        javaScriptEnabled
        domStorageEnabled
        // These two together are what makes the map pannable/zoomable by
        // touch inside the WebView, rather than the outer screen trying to
        // scroll/refresh instead.
        scrollEnabled={false}
        bounces={false}
      />
      <Pressable onPress={() => navigation.goBack()} style={styles.backChip} hitSlop={8}>
        <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2}>
          <Path d="M15 18l-6-6 6-6" />
        </Svg>
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  webview: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  backChip: {
    position: 'absolute',
    top: 18,
    left: 16,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(12,15,22,0.75)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
