// ForYouScreen.js
//
// Implements the "Bar Buddy For You Page" design import: an AI-planner chat
// where the user describes a vibe and gets back a short itinerary pitch
// sequencing 2-3 real Bar Buddy venues. Replaces the previous placeholder
// (see PlaceholderScreen.js — still used by Events/Assistant... actually no,
// see tabRoutes.js: this was the last tab still on the placeholder).
//
// "Backend" note: the design's own JS called `window.claude.complete()` for
// the itinerary text — that's a Claude Design preview-sandbox-only global
// and doesn't exist here. There's also no real backend anywhere else in
// this app (see placeholderData.js / searchVenues.js), so this screen
// follows the same convention: a local, deterministic keyword match against
// the app's real venue dataset (see data/forYouVenues.js, built on top of
// SEARCH_VENUES rather than duplicating venue data a second time) stands in
// for both the venue lookup and the itinerary write-up.
//
// No per-screen bottom tab bar here — BottomNav is already rendered once by
// SwipeableTabs (see navigation/SwipeableTabs.js), so the design's own tab
// bar markup at the bottom of the .dc.html is intentionally not ported.
//
// Animation note: the thinking-dots indicator uses plain requestAnimationFrame
// + elapsed time, not RN's Animated API — same reasoning as the rest of this
// app's animated pieces (see AnimatedGradientBackground.js's animation-driver
// note).
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import Svg, { Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import NavIcon from '../components/NavIcons';
import { pickVenuesByKeyword, buildItineraryReply } from '../data/forYouVenues';

// How long the "thinking" indicator stays up before the reply lands — there's
// no real network/LLM call happening, so this is just enough of a pause for
// the exchange to still feel like a considered answer rather than an instant
// canned response.
const THINK_MS_MIN = 650;
const THINK_MS_MAX = 1100;

const STEP_COLORS = ['#E15C3F', '#8B5CF6', '#3E8EDE', '#2FA37A'];

function ThinkingDots() {
  const [elapsedMs, setElapsedMs] = useState(0);
  const rafRef = useRef(null);

  useEffect(() => {
    const start = performance.now();
    const tick = (now) => {
      setElapsedMs(now - start);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <View style={styles.thinkingBubble}>
      {[0, 150, 300].map((delayMs) => {
        const cycle = 1100;
        const t = ((elapsedMs - delayMs) % cycle + cycle) % cycle;
        const p = t < cycle * 0.4 ? Math.sin((t / (cycle * 0.4)) * Math.PI) : 0;
        return (
          <View
            key={delayMs}
            style={[
              styles.thinkingDot,
              { opacity: 0.25 + p * 0.75, transform: [{ translateY: -3 * p }] },
            ]}
          />
        );
      })}
    </View>
  );
}

function VenueStepCardBody({ venue, stepNumber, stepColor }) {
  return (
    <>
      <View style={styles.stepPhotoWrap}>
        <Image source={{ uri: venue.photo }} style={styles.stepPhoto} resizeMode="cover" />
      </View>
      <View style={styles.stepInfo}>
        <View style={styles.stepHeaderRow}>
          <View style={[styles.stepBadge, { backgroundColor: stepColor }]}>
            <Text style={styles.stepBadgeText}>{stepNumber}</Text>
          </View>
          <Text style={styles.stepName} numberOfLines={1}>
            {venue.name}
          </Text>
        </View>
        <Text style={styles.stepMeta}>
          {venue.subcategory} · {venue.neighborhood}
        </Text>
        <View style={styles.ageBadge}>
          <Text style={styles.ageBadgeText}>{venue.ageAccess}</Text>
        </View>
      </View>
    </>
  );
}

// Mirrors SearchScreen's VenueResultCard convention: only the 8 real curated
// venues (linksToDetail: true) push to VenueDetail — the 2 design-only extras
// (the-sinclair, mikes-diner) don't have a real detail record to open.
function VenueStepCard({ venue, stepNumber, stepColor, onPress }) {
  if (!venue.linksToDetail) {
    return (
      <View style={styles.stepCard}>
        <VenueStepCardBody venue={venue} stepNumber={stepNumber} stepColor={stepColor} />
      </View>
    );
  }
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.stepCard, pressed && styles.stepCardPressed]}>
      <VenueStepCardBody venue={venue} stepNumber={stepNumber} stepColor={stepColor} />
    </Pressable>
  );
}

function UserBubble({ text }) {
  return (
    <View style={styles.userBubble}>
      <Text style={styles.userBubbleText}>{text}</Text>
    </View>
  );
}

function AssistantBubble({ text, venues, onVenuePress }) {
  return (
    <View style={styles.assistantBubbleWrap}>
      <View style={styles.assistantBubble}>
        <Text style={styles.assistantBubbleText}>{text}</Text>
        {venues && venues.length > 0 && (
          <View style={styles.stepList}>
            {venues.map((v, i) => (
              <VenueStepCard
                key={v.id}
                venue={v}
                stepNumber={i + 1}
                stepColor={STEP_COLORS[i % STEP_COLORS.length]}
                onPress={() => onVenuePress(v.id)}
              />
            ))}
          </View>
        )}
      </View>
    </View>
  );
}

export default function ForYouScreen() {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [fontsLoaded] = useAppFonts();
  const [draftText, setDraftText] = useState('');
  const [messages, setMessages] = useState([]);
  const [isThinking, setIsThinking] = useState(false);
  const scrollRef = useRef(null);
  const thinkTimerRef = useRef(null);

  useEffect(
    () => () => {
      if (thinkTimerRef.current) clearTimeout(thinkTimerRef.current);
    },
    []
  );

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  const hasDraft = draftText.trim().length > 0;

  const handleSend = () => {
    const text = draftText.trim();
    if (!text || isThinking) return;

    setMessages((prev) => [...prev, { id: `u-${prev.length}`, isUser: true, text }]);
    setDraftText('');
    setIsThinking(true);

    const venues = pickVenuesByKeyword(text);
    const delay = THINK_MS_MIN + Math.random() * (THINK_MS_MAX - THINK_MS_MIN);
    thinkTimerRef.current = setTimeout(() => {
      const replyText = buildItineraryReply(text, venues);
      setIsThinking(false);
      setMessages((prev) => [
        ...prev,
        { id: `a-${prev.length}`, isAssistant: true, text: replyText, venues },
      ]);
    }, delay);
  };

  const handleVenuePress = (venueId) => {
    navigation.navigate('VenueDetail', { venueId });
  };

  const isEmpty = messages.length === 0;

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={[styles.headerWrap, { paddingTop: insets.top + spacing.lg }]}>
          <Text style={styles.headerTitle}>For You</Text>
          <Text style={styles.headerSubtitle}>Tell me the vibe, I'll plan the night.</Text>
        </View>

        <View style={styles.inputRow}>
          <TextInput
            value={draftText}
            onChangeText={setDraftText}
            onSubmitEditing={handleSend}
            placeholder="Describe the type of night you want..."
            placeholderTextColor={colors.textMuted}
            style={styles.input}
            returnKeyType="send"
          />
          <Pressable
            onPress={handleSend}
            disabled={!hasDraft}
            style={[styles.sendButton, hasDraft && styles.sendButtonActive]}
            hitSlop={6}
          >
            <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={hasDraft ? colors.navyBase : colors.textMuted} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
              <Path d="M5 12h14M13 5l7 7-7 7" />
            </Svg>
          </Pressable>
        </View>

        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
        >
          {isEmpty && !isThinking ? (
            <View style={styles.emptyState}>
              <View style={styles.emptyIcon}>
                <NavIcon name="foryou" color={colors.amber} size={22} />
              </View>
              <Text style={styles.emptyTitle}>What's the vibe tonight?</Text>
              <Text style={styles.emptyBody}>
                Describe the mood, amenities, or type of spot, and I'll build a night out from real
                Bar Buddy venues.
              </Text>
            </View>
          ) : (
            messages.map((msg) =>
              msg.isUser ? (
                <UserBubble key={msg.id} text={msg.text} />
              ) : (
                <AssistantBubble
                  key={msg.id}
                  text={msg.text}
                  venues={msg.venues}
                  onVenuePress={handleVenuePress}
                />
              )
            )
          )}

          {isThinking && <ThinkingDots />}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  flex: {
    flex: 1,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  // paddingTop is set inline (insets.top + spacing.lg) to match Search's
  // header exactly — see SearchScreen.js's headerRow/scrollContent, which
  // adds the same insets.top + spacing.lg since its SafeAreaView (like this
  // one) only applies the 'left'/'right'/'bottom' edges, not 'top'. Without
  // that, the title renders right under the status bar / notch.
  headerWrap: {
    paddingHorizontal: spacing.lg,
    marginBottom: 18,
  },
  headerTitle: {
    fontFamily: fonts.displayBold,
    fontSize: 20,
    color: colors.textPrimary,
  },
  headerSubtitle: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 2,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
    paddingLeft: 16,
    paddingRight: 8,
    marginHorizontal: spacing.lg,
    marginBottom: 12,
  },
  input: {
    flex: 1,
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    color: colors.textPrimary,
    padding: 0,
  },
  sendButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonActive: {
    backgroundColor: colors.amber,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 24,
    gap: 14,
  },
  emptyState: {
    alignItems: 'center',
    textAlign: 'center',
    paddingTop: 56,
    paddingHorizontal: 20,
  },
  emptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(23,27,36,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 16,
    color: colors.textPrimary,
    marginBottom: 6,
    textAlign: 'center',
  },
  emptyBody: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 19.5,
    textAlign: 'center',
    maxWidth: 250,
  },
  userBubble: {
    alignSelf: 'flex-end',
    maxWidth: '80%',
    backgroundColor: 'rgba(245,243,239,0.14)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.22)',
    borderRadius: 14,
    borderBottomRightRadius: 3,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  userBubbleText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    lineHeight: 19.6,
    color: colors.textPrimary,
  },
  assistantBubbleWrap: {
    alignSelf: 'flex-start',
    width: '92%',
  },
  // Neutral dark grey rather than the design's original navy-tinted
  // (#232838/#363c4d) — a deliberate departure from the app's usual
  // blue-leaning surface color so the AI reply tile reads as its own
  // distinct "voice" in the conversation, not just another navy card.
  assistantBubble: {
    backgroundColor: '#2A2A2E',
    borderWidth: 1,
    borderColor: '#3D3D42',
    borderRadius: 15,
    borderBottomLeftRadius: 3,
    padding: 12,
  },
  assistantBubbleText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13.5,
    lineHeight: 21,
    color: colors.textPrimary,
  },
  stepList: {
    gap: 10,
    marginTop: 12,
  },
  stepCard: {
    flexDirection: 'row',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
    overflow: 'hidden',
  },
  stepCardPressed: {
    opacity: 0.85,
  },
  stepPhotoWrap: {
    width: 96,
  },
  stepPhoto: {
    width: '100%',
    height: '100%',
  },
  stepInfo: {
    flex: 1,
    minWidth: 0,
    padding: 10,
    paddingRight: 12,
    position: 'relative',
  },
  stepHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  stepBadge: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBadgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 10,
    color: colors.navyBase,
  },
  stepName: {
    flex: 1,
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
  },
  stepMeta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 3,
  },
  ageBadge: {
    position: 'absolute',
    top: 8,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    backgroundColor: 'rgba(12,15,22,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.2)',
  },
  ageBadgeText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 10,
    color: colors.textPrimary,
  },
  thinkingBubble: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    gap: 5,
    backgroundColor: 'rgba(23,27,36,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.15)',
    borderRadius: 18,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  thinkingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.textMuted,
  },
});
