// EventDetailScreen.js
//
// New screen this round — Event Detail, built to the exact same
// CLAUDE.md "Venue/Event Detail — Transition & Structure Rules" as
// VenueDetailScreen.js (photo-enlarge entrance, enlarged back/bookmark
// buttons, Name -> Rating -> Description+Atmosphere -> Location -> Reviews
// -> "I'm Going" order). Deliberately mirrors VenueDetailScreen's structure
// rather than trying to share a single generic component between them —
// the two screens' data shapes are similar but not identical (an event has
// no separate Amenities grid, its "photos" is really just one borrowed
// venue photo, etc.), so keeping them as sibling files stayed simpler than
// building an abstraction for two call sites.
import { ActivityIndicator, Linking, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import { eventById } from '../data/events';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import HeroGallery from '../components/HeroGallery';
import StarRating from '../components/StarRating';
import ReviewCard from '../components/ReviewCard';
import VenueActionBar from '../components/VenueActionBar';
import { useDetailReveal } from '../hooks/useDetailReveal';
import { useSaved } from '../context/SavedContext';

const BLOCK_TITLE = 0;
const BLOCK_RATING = 1;
const BLOCK_ABOUT = 2; // Description + Atmosphere
const BLOCK_LOCATION = 3;
const BLOCK_REVIEWS = 4;
const BLOCK_ACTION_BAR = 5;
const BLOCK_COUNT = 6;

export default function EventDetailScreen({ route, navigation }) {
  const [fontsLoaded] = useAppFonts();
  const event = eventById(route.params?.eventId);
  const { isSaved, toggleSaved } = useSaved();
  const { heroStyle, getBlockStyle, isBlockRevealed } = useDetailReveal(BLOCK_COUNT, {
    skipHero: !!route.params?.skipEntryAnimation,
  });

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  if (!event) {
    return (
      <View style={styles.loading}>
        <Text style={styles.notFound}>Event not found.</Text>
      </View>
    );
  }

  const bookmarked = isSaved('event', event.id);
  const [street, ...restAddress] = event.address.split(', ');
  const locationLine2 = [event.neighborhood, ...restAddress].join(', ');

  const openInAppleMaps = () => {
    const query = encodeURIComponent(`${event.venueName}, ${event.address}`);
    Linking.openURL(`https://maps.apple.com/?q=${query}&address=${encodeURIComponent(event.address)}`);
  };

  const openAllReviews = () => {
    if (event.reviewsUrl) Linking.openURL(event.reviewsUrl);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <ScrollView
        style={styles.scroll}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={[styles.heroBlock, heroStyle]}>
          <HeroGallery
            photos={[{ uri: event.photo }]}
            ageAccess={event.ageAccess}
            onBack={() => navigation.goBack()}
            bookmarked={bookmarked}
            onToggleBookmark={() => toggleSaved('event', event.id)}
          />

          <View style={styles.overlapContent}>
            <View style={[styles.titleBlock, getBlockStyle(BLOCK_TITLE)]}>
              <Text style={styles.eventName}>{event.title}</Text>
              <Text style={styles.eventMeta}>
                {event.eventType} · {event.venueName} · {event.startLabel}
              </Text>
            </View>

            <View style={getBlockStyle(BLOCK_RATING)}>
              <View style={styles.ratingRow}>
                <StarRating rating={event.rating} size={14} />
                <Text style={styles.ratingNum}>{event.rating.toFixed(1)}</Text>
                <View style={styles.dotSep} />
                <Text style={styles.reviewCount}>{event.reviewCount} venue reviews</Text>
              </View>

              <View style={styles.pulse}>
                <View style={styles.pulseDot} />
                <Text style={styles.pulseText}>{event.goingTonight} going</Text>
              </View>
            </View>
          </View>

          {/* Bug fix: this used to fade to a flat colors.navyBase, but the
              actual screen background is AnimatedGradientBackground's
              nebula gradient, not a flat navy fill — that mismatch was
              exactly the "hard break between the image and the background"
              seam. Fading to nebulaBaseBottom (the nebula gradient's own
              darkest anchor tone) over a taller region blends into what's
              actually rendered behind it — see VenueDetailScreen.js's
              matching fix for the full explanation. */}
          <LinearGradient
            colors={['transparent', colors.nebulaBaseBottom]}
            style={styles.bottomFade}
            pointerEvents="none"
          />
        </View>

        <View style={styles.content}>
          <View style={[styles.section, getBlockStyle(BLOCK_ABOUT)]}>
            <Text style={styles.sectionLabel}>About</Text>
            <Text style={styles.description}>{event.description}</Text>
            <Text style={[styles.description, styles.atmosphereText]}>{event.atmosphere}</Text>
          </View>

          <View style={[styles.section, getBlockStyle(BLOCK_LOCATION)]}>
            <Text style={styles.sectionLabel}>Location</Text>
            <Pressable
              onPress={openInAppleMaps}
              style={({ pressed }) => [styles.locationCard, pressed && styles.pressedCard]}
            >
              <Svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={2}>
                <Path d="M12 21s-7-6.2-7-11a7 7 0 0114 0c0 4.8-7 11-7 11z" />
                <Circle cx={12} cy={10} r={2.5} />
              </Svg>
              <View style={styles.locationTextWrap}>
                <Text style={styles.locationStreet}>{street}</Text>
                <Text style={styles.locationRest}>{locationLine2}</Text>
              </View>
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
                <Path d="M9 18l6-6-6-6" />
              </Svg>
            </Pressable>
          </View>

          <View style={[styles.section, styles.lastSection, getBlockStyle(BLOCK_REVIEWS)]}>
            <Text style={styles.sectionLabel}>Reviews</Text>
            <Text style={styles.reviewsHint}>Reviews are for {event.venueName}. This specific event doesn't have its own review history yet.</Text>
            {event.reviews.map((review) => (
              <ReviewCard key={review.author} author={review.author} rating={review.rating} text={review.text} />
            ))}
            <Pressable onPress={openAllReviews} hitSlop={6}>
              <Text style={styles.seeAll}>See all {event.reviewCount} venue reviews</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>

      <VenueActionBar style={getBlockStyle(BLOCK_ACTION_BAR)} interactive={isBlockRevealed(BLOCK_ACTION_BAR)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  notFound: {
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    color: colors.textMuted,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 130,
  },
  heroBlock: {
    position: 'relative',
    overflow: 'hidden',
  },
  overlapContent: {
    paddingHorizontal: spacing.lg,
    marginTop: -40,
  },
  // Widened from 10px, same reasoning as VenueDetailScreen.js's matching
  // style — too thin to read as an actual gradient blend.
  bottomFade: {
    height: 46,
  },
  content: {
    paddingHorizontal: spacing.lg,
  },
  titleBlock: {
    marginBottom: 14,
  },
  eventName: {
    fontFamily: fonts.displayBold,
    fontSize: 26,
    color: colors.textPrimary,
    marginBottom: 4,
  },
  eventMeta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  ratingNum: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
  },
  dotSep: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: colors.textMuted,
  },
  reviewCount: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  pulseDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.amber,
  },
  section: {
    marginBottom: 26,
  },
  lastSection: {
    marginBottom: 0,
  },
  sectionLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 10,
  },
  description: {
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    lineHeight: 21.7,
    color: colors.textMuted,
  },
  atmosphereText: {
    marginTop: 10,
  },
  reviewsHint: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11.5,
    fontStyle: 'italic',
    color: colors.textMuted,
    opacity: 0.75,
    marginBottom: 10,
  },
  pressedCard: {
    opacity: 0.7,
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 14,
  },
  locationTextWrap: {
    flex: 1,
  },
  locationStreet: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13.5,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  locationRest: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 18.2,
  },
  seeAll: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.amber,
    textAlign: 'center',
    paddingTop: 4,
  },
});
