import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import { featuredPlace, nearYouPlaces, mapNearbyCount } from '../data/placeholderData';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import Header from '../components/Header';
import CompactSearchBar from '../components/CompactSearchBar';
import FeaturedCard from '../components/FeaturedCard';
import NearYouSection from '../components/NearYouSection';
import MapPlaceholder from '../components/MapPlaceholder';
import BrowseRow from '../components/BrowseRow';

// A full-bounce pull (finger dragged all the way, then released) covers
// roughly this much distance on a typical phone. The refresh trigger fires
// at a quarter of that — a short, easy pull rather than a long deliberate
// one — since there's no native RefreshControl involved here (see the pull-
// to-refresh note below) to fall back on a platform-defined threshold.
const FULL_PULL_DISTANCE = 160;
const REFRESH_TRIGGER_DISTANCE = FULL_PULL_DISTANCE * 0.25;
const REFRESH_SPIN_MS = 900; // no backend yet, so this just simulates a reload

export default function HomeScreen() {
  const navigation = useNavigation();
  const [fontsLoaded] = useAppFonts();
  const [refreshing, setRefreshing] = useState(false);
  // Tracks the most negative (furthest overscrolled) contentOffset.y seen
  // during the current drag, reset at the start of every drag. Checked on
  // release rather than driving anything native, which is what lets the
  // trigger point sit at a quarter-pull instead of a full one.
  const pullMinYRef = useRef(0);
  const refreshTimerRef = useRef(null);

  useEffect(
    () => () => {
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    },
    []
  );

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  const handleScrollBeginDrag = () => {
    pullMinYRef.current = 0;
  };

  const handleScroll = (e) => {
    const y = e.nativeEvent.contentOffset.y;
    if (y < pullMinYRef.current) pullMinYRef.current = y;
  };

  const handleScrollEndDrag = () => {
    const pulled = -pullMinYRef.current;
    if (pulled >= REFRESH_TRIGGER_DISTANCE && !refreshing) {
      setRefreshing(true);
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
      refreshTimerRef.current = setTimeout(() => setRefreshing(false), REFRESH_SPIN_MS);
    }
    pullMinYRef.current = 0;
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      {refreshing && (
        <View style={styles.refreshIndicator} pointerEvents="none">
          <ActivityIndicator color={colors.amber} />
        </View>
      )}

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        scrollEventThrottle={16}
        onScroll={handleScroll}
        onScrollBeginDrag={handleScrollBeginDrag}
        onScrollEndDrag={handleScrollEndDrag}
        // Needed for CompactSearchBar's dropdown — without this, RN's
        // default ("never") treats a tap on one of the dropdown's own
        // Pressables (a recent search, a category chip) as "dismiss the
        // keyboard first" instead of registering the press, since the
        // search box is still focused underneath it. See
        // CompactSearchBar.js's own note for the full reasoning.
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerWrap}>
          <Header />
        </View>

        <CompactSearchBar />

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Featured</Text>
          <FeaturedCard place={featuredPlace} />
        </View>

        {/* NearYouSection renders its own "Near you"/"See all" header and
            isn't full-bleed anymore (no enclosing banner — see the
            component for why), so it doesn't need the section wrapper's
            label or fullBleedSection treatment the old carousel used. */}
        <NearYouSection places={nearYouPlaces} />

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Map</Text>
          <MapPlaceholder nearbyCount={mapNearbyCount} onPress={() => navigation.navigate('Map')} />
        </View>

        {/* BrowseRow renders its own "Browse" header and its own bottom
            margin, same reasoning as NearYouSection above. Last section on
            the page per CLAUDE.md. */}
        <BrowseRow />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  refreshIndicator: {
    position: 'absolute',
    top: 14,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 10,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 28,
  },
  section: {
    marginBottom: spacing.xxl,
  },
  // Header no longer has its own banner background, so it just sits in the
  // normal content flow (no full-bleed negative margin needed anymore).
  headerWrap: {
    marginBottom: spacing.xl,
  },
  sectionLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 12,
  },
});
