// ProfileScreen.js
//
// New account/settings screen replacing the old "Assistant" tab, per
// CLAUDE.md — the AI itinerary planner is unaffected and stays under "For
// You" (ForYouScreen.js); this is a fresh screen, not a repurposed one.
// Standard mobile-app profile layout: avatar + name/email up top, grouped
// setting rows below, sign out at the bottom. Everything here is visual
// only — no real account exists yet (no auth, see CLAUDE.md's Tech Stack
// Decision), so every row is a plain Pressable with no destination wired up
// yet, same phase as Browse's own utility tiles.
import { ActivityIndicator, StyleSheet, Text, View, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import Svg, { Path, Circle, Rect } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';

function RowIcon({ children }) {
  return <View style={styles.rowIcon}>{children}</View>;
}

function ChevronRight() {
  return (
    <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
      <Path d="M9 18l6-6-6-6" />
    </Svg>
  );
}

function SettingRow({ icon, label, danger }) {
  return (
    <Pressable style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
      <RowIcon>{icon}</RowIcon>
      <Text style={[styles.rowLabel, danger && styles.rowLabelDanger]}>{label}</Text>
      {!danger && <ChevronRight />}
    </Pressable>
  );
}

export default function ProfileScreen() {
  const [fontsLoaded] = useAppFonts();

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <View style={styles.content}>
        <Text style={styles.pageTitle}>Profile</Text>

        <View style={styles.identity}>
          <View style={styles.avatar}>
            <Text style={styles.avatarInitial}>A</Text>
          </View>
          <View style={styles.identityText}>
            <Text style={styles.name}>Alexander</Text>
            <Text style={styles.email}>amckayster@gmail.com</Text>
          </View>
        </View>

        <View style={styles.group}>
          <Text style={styles.groupLabel}>Account</Text>
          <SettingRow
            label="Edit Profile"
            icon={
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
                <Circle cx={12} cy={8} r={4} />
                <Path d="M4 21c0-4 3.6-7 8-7s8 3 8 7" />
              </Svg>
            }
          />
          <SettingRow
            label="Age & Access"
            icon={
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
                <Rect x={4} y={4} width={16} height={16} rx={3} />
                <Path d="M8 12h8M12 8v8" />
              </Svg>
            }
          />
        </View>

        <View style={styles.group}>
          <Text style={styles.groupLabel}>Preferences</Text>
          <SettingRow
            label="Vibe & Venue Tags"
            icon={
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
                <Path d="M12 17l-6.16 3.24 1.18-6.88L2 8.76l6.92-1L12 1.5l3.08 6.26 6.92 1-5.02 4.6 1.18 6.88z" />
              </Svg>
            }
          />
          <SettingRow
            label="Notifications"
            icon={
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
                <Path d="M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
                <Path d="M13.73 21a2 2 0 01-3.46 0" />
              </Svg>
            }
          />
        </View>

        <View style={styles.group}>
          <Text style={styles.groupLabel}>Support</Text>
          <SettingRow
            label="Help & Feedback"
            icon={
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}>
                <Circle cx={12} cy={12} r={9} />
                <Path d="M9.5 9.5a2.5 2.5 0 015 .5c0 1.5-2 1.5-2.5 3M12 17h.01" />
              </Svg>
            }
          />
        </View>

        <Pressable style={({ pressed }) => [styles.signOut, pressed && styles.rowPressed]}>
          <Text style={styles.signOutText}>Sign Out</Text>
        </Pressable>

        <Text style={styles.version}>BarBuddy · v1.0.0</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.lg,
  },
  pageTitle: {
    fontFamily: fonts.displayBold,
    fontSize: 22,
    color: colors.textPrimary,
    marginTop: 8,
    marginBottom: spacing.xl,
  },
  identity: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: spacing.xxl,
  },
  avatar: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.amber,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarInitial: {
    fontFamily: fonts.displayBold,
    fontSize: 22,
    color: colors.amber,
  },
  identityText: {
    flex: 1,
    minWidth: 0,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 18,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  email: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  group: {
    marginBottom: spacing.xl,
  },
  groupLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.3,
    color: colors.textMuted,
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 13,
    marginBottom: 8,
  },
  rowPressed: {
    opacity: 0.8,
  },
  rowIcon: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: 'rgba(227,168,87,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowLabel: {
    flex: 1,
    fontFamily: fonts.bodyMedium,
    fontSize: 14,
    color: colors.textPrimary,
  },
  rowLabelDanger: {
    color: colors.ratingRed,
  },
  signOut: {
    alignItems: 'center',
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.ratingRed,
    backgroundColor: `${colors.ratingRed}14`,
    marginTop: 4,
  },
  signOutText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 14,
    color: colors.ratingRed,
  },
  version: {
    textAlign: 'center',
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
    marginTop: 16,
    opacity: 0.6,
  },
});
