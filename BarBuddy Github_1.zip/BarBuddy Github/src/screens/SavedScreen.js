// SavedScreen.js
//
// New this round — the destination Browse's "Saved" utility tile points at,
// and the missing other half of the new bookmark button on Venue/Event
// Detail (see HeroGallery.js / SavedContext.js). Lists whatever the user
// has bookmarked so far, split into Venues and Events. Pushed as a root
// stack screen (like VenueDetail/EventDetail/Map) so it covers the tab bar
// the same way those do.
import { ActivityIndicator, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Svg, { Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import bostonVenues from '../data/bostonVenues.json';
import { eventById } from '../data/events';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import { useSaved } from '../context/SavedContext';

function BackChip({ onPress }) {
  return (
    <Pressable onPress={onPress} style={styles.backChip} hitSlop={8}>
      <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2}>
        <Path d="M15 18l-6-6 6-6" />
      </Svg>
    </Pressable>
  );
}

function SavedRow({ title, subtitle, onPress }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
      <View style={styles.rowText}>
        <Text style={styles.rowTitle} numberOfLines={1}>
          {title}
        </Text>
        <Text style={styles.rowSubtitle} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
        <Path d="M9 18l6-6-6-6" />
      </Svg>
    </Pressable>
  );
}

export default function SavedScreen({ navigation }) {
  const [fontsLoaded] = useAppFonts();
  const { savedVenueIds, savedEventIds } = useSaved();

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  const savedVenues = savedVenueIds.map((id) => bostonVenues.find((v) => v.id === id)).filter(Boolean);
  const savedEvents = savedEventIds.map((id) => eventById(id)).filter(Boolean);
  const isEmpty = savedVenues.length === 0 && savedEvents.length === 0;

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <View style={styles.topbar}>
        <BackChip onPress={() => navigation.goBack()} />
        <Text style={styles.pageTitle}>Saved</Text>
        <View style={styles.backChipSpacer} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {isEmpty && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>Nothing saved yet</Text>
            <Text style={styles.emptyBody}>
              Tap the bookmark icon on any venue or event to keep it here.
            </Text>
          </View>
        )}

        {savedVenues.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Venues</Text>
            {savedVenues.map((venue) => (
              <SavedRow
                key={venue.id}
                title={venue.name}
                subtitle={`${venue.category} · ${venue.neighborhood}`}
                onPress={() => navigation.navigate('VenueDetail', { venueId: venue.id })}
              />
            ))}
          </View>
        )}

        {savedEvents.length > 0 && (
          <View style={[styles.section, styles.lastSection]}>
            <Text style={styles.sectionLabel}>Events</Text>
            {savedEvents.map((event) => (
              <SavedRow
                key={event.id}
                title={event.title}
                subtitle={`${event.eventType} · ${event.venueName}`}
                onPress={() => navigation.navigate('EventDetail', { eventId: event.id })}
              />
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  topbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: 8,
    paddingBottom: spacing.lg,
  },
  backChip: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backChipSpacer: {
    width: 38,
  },
  pageTitle: {
    fontFamily: fonts.displayBold,
    fontSize: 18,
    color: colors.textPrimary,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 28,
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 17,
    color: colors.textPrimary,
    marginBottom: 8,
  },
  emptyBody: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    textAlign: 'center',
    lineHeight: 19,
  },
  section: {
    marginBottom: spacing.xxl,
  },
  lastSection: {
    marginBottom: 0,
  },
  sectionLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 14,
    marginBottom: 8,
  },
  rowPressed: {
    opacity: 0.8,
  },
  rowText: {
    flex: 1,
    minWidth: 0,
  },
  rowTitle: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  rowSubtitle: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textMuted,
  },
});
