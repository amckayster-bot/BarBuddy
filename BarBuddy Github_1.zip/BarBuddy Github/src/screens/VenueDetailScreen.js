import { ActivityIndicator, Linking, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts, useAppFonts } from '../theme/typography';
import bostonVenues from '../data/bostonVenues.json';
import AnimatedGradientBackground from '../components/AnimatedGradientBackground';
import HeroGallery from '../components/HeroGallery';
import StarRating from '../components/StarRating';
import VibeTag from '../components/VibeTag';
import AmenityGrid from '../components/AmenityGrid';
import ReviewCard from '../components/ReviewCard';
import VenueActionBar from '../components/VenueActionBar';
import { useDetailReveal } from '../hooks/useDetailReveal';
import { useSaved } from '../context/SavedContext';

// Sandbox fixture data (Boston, 9 real venues) for building against — not
// the Chicago launch dataset. Hero photos come straight from each venue's
// `photos` array in bostonVenues.json (real, free-license photography).
function heroPhotos(venue) {
  return venue.photos.map((uri) => ({ uri }));
}

// Six staggered reveal blocks, matching CLAUDE.md's locked content order
// exactly: Name -> Rating -> Description+Atmosphere -> Location -> Reviews
// -> "I'm Going" button. Amenities isn't its own named block in that list —
// per the confirmed answer, it stays on the page folded right next to
// Description+Atmosphere (block 2), rather than getting removed.
const BLOCK_TITLE = 0;
const BLOCK_RATING = 1;
const BLOCK_ABOUT = 2; // Description + Atmosphere + Amenities
const BLOCK_LOCATION = 3;
const BLOCK_REVIEWS = 4;
const BLOCK_ACTION_BAR = 5;
const BLOCK_COUNT = 6;

export default function VenueDetailScreen({ route, navigation }) {
  const [fontsLoaded] = useAppFonts();
  const venue = bostonVenues.find((v) => v.id === route.params?.venueId);
  const { isSaved, toggleSaved } = useSaved();
  // route.params?.skipEntryAnimation: set by Home's Featured card, whose own
  // exception (per CLAUDE.md) already did an in-place text reveal before
  // navigating here — see FeaturedCard.js. Everywhere else this is
  // undefined/false, so the normal photo-enlarge entrance plays.
  const { heroStyle, getBlockStyle, isBlockRevealed } = useDetailReveal(BLOCK_COUNT, {
    skipHero: !!route.params?.skipEntryAnimation,
  });

  if (!fontsLoaded) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.amber} />
      </View>
    );
  }

  if (!venue) {
    return (
      <View style={styles.loading}>
        <Text style={styles.notFound}>Venue not found.</Text>
      </View>
    );
  }

  const bookmarked = isSaved('venue', venue.id);
  const [street, ...restAddress] = venue.address.split(', ');
  const locationLine2 = [venue.neighborhood, ...restAddress].join(', ');

  // Opens the venue's location in Apple Maps with its address pre-filled
  // and selected. maps.apple.com is a universal link — iOS routes it
  // straight into the Apple Maps app rather than a browser; the address is
  // real (bostonVenues.json), so this drops a real pin, not a placeholder.
  const openInAppleMaps = () => {
    const query = encodeURIComponent(`${venue.name}, ${venue.address}`);
    Linking.openURL(`https://maps.apple.com/?q=${query}&address=${encodeURIComponent(venue.address)}`);
  };

  // "See all N reviews" opens the venue's real Yelp listing, since there's
  // no backend of our own yet to hold a full review list — this is where
  // the real reviews shown above actually live.
  const openAllReviews = () => {
    if (venue.reviewsUrl) Linking.openURL(venue.reviewsUrl);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      <AnimatedGradientBackground />

      <ScrollView
        style={styles.scroll}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* heroStyle (from useDetailReveal) is the "photo enlarges to fill
            the screen" landing animation — starts slightly inset/rounded
            and closes to edge-to-edge over the entrance. See the hook's own
            header comment for why this is a mount-time animation rather
            than a literal cross-screen shared-element transition. */}
        <View style={[styles.heroBlock, heroStyle]}>
          <HeroGallery
            photos={heroPhotos(venue)}
            ageAccess={venue.ageAccess}
            onBack={() => navigation.goBack()}
            bookmarked={bookmarked}
            onToggleBookmark={() => toggleSaved('venue', venue.id)}
          />

          <View style={styles.overlapContent}>
            <View style={[styles.titleBlock, getBlockStyle(BLOCK_TITLE)]}>
              <Text style={styles.venueName}>{venue.name}</Text>
              <Text style={styles.venueMeta}>
                {venue.category} · {venue.neighborhood} · {venue.priceLevel}
              </Text>
            </View>

            <View style={getBlockStyle(BLOCK_RATING)}>
              <View style={styles.ratingRow}>
                <StarRating rating={venue.rating} size={14} />
                <Text style={styles.ratingNum}>{venue.rating.toFixed(1)}</Text>
                <View style={styles.dotSep} />
                <Text style={styles.reviewCount}>{venue.reviewCount} reviews</Text>
              </View>

              {venue.reservationsRecommended && (
                <View style={styles.reservationBadge}>
                  <Text style={styles.reservationBadgeText}>Reservations Recommended</Text>
                </View>
              )}

              <View style={styles.pulse}>
                <View style={styles.pulseDot} />
                <Text style={styles.pulseText}>{venue.goingTonight} going tonight</Text>
              </View>

              <View style={styles.tagStrip}>
                {venue.vibeTags.map((tag) => (
                  <VibeTag key={tag} label={tag} />
                ))}
              </View>
            </View>
          </View>

          {/* Localized fade at just the very bottom of the hero block, so
              the drop into "About" reads as a soft blend rather than a hard
              cut — without tinting the photo or title/rating/tag zone
              above it the way the old full-block overlay did.
              Bug fix: this used to fade to a flat colors.navyBase, but the
              actual screen background is AnimatedGradientBackground's
              nebula gradient (rose/purple/brown blooms, not a flat navy
              fill) — fading to navyBase created a visible hard seam where
              this rectangle's edge met the differently-colored background
              around it. Fading to nebulaBaseBottom (the nebula gradient's
              own darkest anchor tone) instead, over a taller region, reads
              as a real blend into what's actually behind it. */}
          <LinearGradient
            colors={['transparent', colors.nebulaBaseBottom]}
            style={styles.bottomFade}
            pointerEvents="none"
          />
        </View>

        <View style={styles.content}>
          {/* "Description + Atmosphere" — the doc's own merged section name.
              Amenities stays folded in right after it (see BLOCK_ABOUT
              comment above) rather than dropped, per the confirmed answer. */}
          <View style={[styles.section, getBlockStyle(BLOCK_ABOUT)]}>
            <Text style={styles.sectionLabel}>About</Text>
            <Text style={styles.description}>{venue.description}</Text>
            <Text style={[styles.description, styles.atmosphereText]}>{venue.atmosphere}</Text>
            <AmenityGrid items={venue.amenities} />
          </View>

          <View style={[styles.section, getBlockStyle(BLOCK_LOCATION)]}>
            <Text style={styles.sectionLabel}>Location</Text>
            <Pressable
              onPress={openInAppleMaps}
              style={({ pressed }) => [styles.locationCard, pressed && styles.pressedCard]}
            >
              <Svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={2}>
                <Path d="M12 21s-7-6.2-7-11a7 7 0 0114 0c0 4.8-7 11-7 11z" />
                <Circle cx={12} cy={10} r={2.5} />
              </Svg>
              <View style={styles.locationTextWrap}>
                <Text style={styles.locationStreet}>{street}</Text>
                <Text style={styles.locationRest}>{locationLine2}</Text>
              </View>
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
                <Path d="M9 18l6-6-6-6" />
              </Svg>
            </Pressable>
          </View>

          <View style={[styles.section, styles.lastSection, getBlockStyle(BLOCK_REVIEWS)]}>
            <Text style={styles.sectionLabel}>Reviews</Text>
            {venue.reviews.map((review) => (
              <ReviewCard key={review.author} author={review.author} rating={review.rating} text={review.text} />
            ))}
            <Pressable onPress={openAllReviews} hitSlop={6}>
              <Text style={styles.seeAll}>See all {venue.reviewCount} reviews</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>

      <VenueActionBar style={getBlockStyle(BLOCK_ACTION_BAR)} interactive={isBlockRevealed(BLOCK_ACTION_BAR)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.navyBase,
  },
  loading: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.navyBase,
  },
  notFound: {
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    color: colors.textMuted,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 130,
  },
  // Wraps HeroGallery + the title/rating/pulse/tag zone that overlaps the
  // bottom of the photo, plus the small bottomFade gradient below. Also the
  // element useDetailReveal's heroStyle animates (marginHorizontal/
  // marginTop/borderRadius) for the "photo lands" entrance.
  heroBlock: {
    position: 'relative',
    overflow: 'hidden',
  },
  // -40 (rather than the previous -54) is tuned to roughly the height of
  // just the venue name text below (~fontSize 26 + its own marginBottom) —
  // enough for the taller hero photo (see HeroGallery.js) to clearly run
  // underneath the whole name, without also eating into the meta/rating
  // line beneath it.
  overlapContent: {
    paddingHorizontal: spacing.lg,
    marginTop: -40,
  },
  // Widened back out from the earlier 10px — that was too thin to read as
  // an actual gradient (see the color-fix note above this style's usage),
  // basically amounting to a hard cut either way. Tall enough now to be a
  // genuine, visible blend.
  bottomFade: {
    height: 46,
  },
  content: {
    paddingHorizontal: spacing.lg,
  },
  titleBlock: {
    marginBottom: 14,
  },
  venueName: {
    fontFamily: fonts.displayBold,
    fontSize: 26,
    color: colors.textPrimary,
    marginBottom: 4,
  },
  venueMeta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  ratingNum: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
  },
  dotSep: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: colors.textMuted,
  },
  reviewCount: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginBottom: 18,
  },
  pulseDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.amber,
  },
  tagStrip: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 0,
  },
  // Small red flag for venues where reservations are recommended — pulled
  // out of the Amenities grid entirely (it isn't a feature/amenity, it's a
  // heads-up) and placed here near the top of the page instead.
  reservationBadge: {
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: colors.ratingRed,
    backgroundColor: `${colors.ratingRed}1F`,
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginBottom: 14,
  },
  reservationBadgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 11.5,
    color: colors.ratingRed,
  },
  section: {
    marginBottom: 26,
  },
  lastSection: {
    marginBottom: 0,
  },
  sectionLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 10,
  },
  description: {
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    lineHeight: 21.7,
    color: colors.textMuted,
  },
  // Atmosphere text follows Description directly in the same merged "About"
  // block — a little breathing room above it and above the AmenityGrid that
  // follows, but no separate heading of its own anymore.
  atmosphereText: {
    marginTop: 10,
    marginBottom: 16,
  },
  pressedCard: {
    opacity: 0.7,
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 14,
  },
  locationTextWrap: {
    flex: 1,
  },
  locationStreet: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13.5,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  locationRest: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 18.2,
  },
  seeAll: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.amber,
    textAlign: 'center',
    paddingTop: 4,
  },
});
