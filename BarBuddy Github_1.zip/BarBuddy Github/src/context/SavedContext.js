// SavedContext.js
//
// Tracks which venues/events the user has bookmarked, in memory only (no
// backend/persistence yet — same "visual only, no real data" phase as the
// rest of the app, see CLAUDE.md's Tech Stack Decision). This is what the
// enlarged bookmark button on Venue/Event Detail now writes to, and what
// Browse's new "Saved" utility tile reads from — added together this round
// because "Saved" was otherwise a destination with nothing to point at.
//
// Keys are namespaced `${type}:${id}` (e.g. "venue:iron-anchor",
// "event:frequency-saturday") so a venue and an event that happen to share
// an id string can never collide.
import { createContext, useCallback, useContext, useMemo, useState } from 'react';

const SavedContext = createContext(null);

function keyFor(type, id) {
  return `${type}:${id}`;
}

export function SavedProvider({ children }) {
  const [savedKeys, setSavedKeys] = useState(() => new Set());

  const isSaved = useCallback((type, id) => savedKeys.has(keyFor(type, id)), [savedKeys]);

  const toggleSaved = useCallback((type, id) => {
    setSavedKeys((prev) => {
      const next = new Set(prev);
      const key = keyFor(type, id);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  }, []);

  const savedVenueIds = useMemo(
    () =>
      Array.from(savedKeys)
        .filter((k) => k.startsWith('venue:'))
        .map((k) => k.slice('venue:'.length)),
    [savedKeys]
  );

  const savedEventIds = useMemo(
    () =>
      Array.from(savedKeys)
        .filter((k) => k.startsWith('event:'))
        .map((k) => k.slice('event:'.length)),
    [savedKeys]
  );

  const value = useMemo(
    () => ({ isSaved, toggleSaved, savedVenueIds, savedEventIds }),
    [isSaved, toggleSaved, savedVenueIds, savedEventIds]
  );

  return <SavedContext.Provider value={value}>{children}</SavedContext.Provider>;
}

export function useSaved() {
  const ctx = useContext(SavedContext);
  if (!ctx) {
    throw new Error('useSaved must be used within SavedProvider');
  }
  return ctx;
}
