// SearchFilterContext.js
//
// Shared category-filter state for the Search feature, lifted out of
// SearchScreen so Home's "Need Inspiration?" chips can read/write the same
// active categories — tapping a chip on Home actually drives the Search
// tab's filters (rather than each screen keeping its own separate copy),
// and a category chip on either screen reflects the other's state.
//
// activeSubs shape: { [categoryKey]: [subLabel, ...] }
//
// pendingQuery/recentSearches: added for Home's new Compact Search Bar
// (CompactSearchBar.js) — it's a shortcut INTO Search, not a second search
// implementation, so submitting a query there doesn't run its own search
// logic; it just stashes the text here as `pendingQuery` and switches to
// the Search tab. SearchScreen.js reads pendingQuery once (via a mount
// effect) to seed its own local search box, then clears it — so it behaves
// exactly like the user had typed and submitted it directly in Search.
// recentSearches is a simple in-memory list (no backend yet, same as the
// rest of the app's placeholder data), capped so it doesn't grow forever.
import { createContext, useCallback, useContext, useState } from 'react';

const SearchFilterContext = createContext(null);
const MAX_RECENT_SEARCHES = 5;

export function SearchFilterProvider({ children }) {
  const [activeCategories, setActiveCategories] = useState([]);
  const [activeSubs, setActiveSubs] = useState({});
  const [pendingQuery, setPendingQuery] = useState(null);
  const [recentSearches, setRecentSearches] = useState([]);

  const toggleCategory = useCallback((key) => {
    setActiveCategories((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
    setActiveSubs((prev) => {
      if (!prev[key]) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  // Turns a category on if it isn't already — never toggles it off. Used
  // for one-directional "make sure this filter is active" actions (Home's
  // chips ensure-activate rather than blindly toggle, so re-tapping an
  // already-active Home chip doesn't accidentally clear it out from under
  // someone mid-search).
  const ensureCategoryActive = useCallback((key) => {
    setActiveCategories((prev) => (prev.includes(key) ? prev : [...prev, key]));
  }, []);

  const toggleSub = useCallback((catKey, label) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      const on = current.includes(label);
      const next = on ? current.filter((l) => l !== label) : [...current, label];
      return { ...prev, [catKey]: next };
    });
  }, []);

  const ensureSubActive = useCallback((catKey, label) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      if (current.includes(label)) return prev;
      return { ...prev, [catKey]: [...current, label] };
    });
  }, []);

  // Explicit on/off setters (as opposed to toggleCategory/toggleSub, which
  // flip whatever the current state is). These exist for callers that need
  // to drive a category independently of a single toggle source — e.g.
  // Home's "Need Inspiration?" chips, where more than one chip can map to
  // the same underlying search category (Winery and Bars both drive
  // `bars`) and each chip needs to turn its own share of that category on
  // or off without stomping the other chip's contribution.
  const setCategoryActive = useCallback((key, isActive) => {
    setActiveCategories((prev) => {
      const has = prev.includes(key);
      if (isActive === has) return prev;
      return isActive ? [...prev, key] : prev.filter((k) => k !== key);
    });
    if (!isActive) {
      setActiveSubs((prev) => {
        if (!prev[key]) return prev;
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  }, []);

  const setSubActive = useCallback((catKey, label, isActive) => {
    setActiveSubs((prev) => {
      const current = prev[catKey] || [];
      const has = current.includes(label);
      if (isActive === has) return prev;
      const next = isActive ? [...current, label] : current.filter((l) => l !== label);
      return { ...prev, [catKey]: next };
    });
  }, []);

  const clearFilters = useCallback(() => {
    setActiveCategories([]);
    setActiveSubs({});
  }, []);

  // Stashes a query for Search to pick up, and records it as a recent
  // search (deduped — resubmitting the same text just bumps it back to the
  // top rather than creating a duplicate entry).
  const submitSearchQuery = useCallback((text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setPendingQuery(trimmed);
    setRecentSearches((prev) => [trimmed, ...prev.filter((q) => q.toLowerCase() !== trimmed.toLowerCase())].slice(0, MAX_RECENT_SEARCHES));
  }, []);

  const clearPendingQuery = useCallback(() => {
    setPendingQuery(null);
  }, []);

  const value = {
    activeCategories,
    activeSubs,
    toggleCategory,
    ensureCategoryActive,
    setCategoryActive,
    toggleSub,
    ensureSubActive,
    setSubActive,
    clearFilters,
    pendingQuery,
    submitSearchQuery,
    clearPendingQuery,
    recentSearches,
  };

  return <SearchFilterContext.Provider value={value}>{children}</SearchFilterContext.Provider>;
}

export function useSearchFilters() {
  const ctx = useContext(SearchFilterContext);
  if (!ctx) {
    throw new Error('useSearchFilters must be used within a SearchFilterProvider');
  }
  return ctx;
}
