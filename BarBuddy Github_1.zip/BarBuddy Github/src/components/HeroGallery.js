import { useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Path } from 'react-native-svg';
import { colors } from '../theme/colors';
import { useScreenWidth } from '../theme/screenSize';
import PhotoTag from './PhotoTag';

// Enlarged from the original 34px per CLAUDE.md's new Venue/Event Detail
// rules ("bookmark and back buttons are enlarged... both need to be
// comfortably tappable, larger than the current icon-chip size").
const ICON_CHIP_SIZE = 44;

function IconChip({ children, onPress }) {
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={styles.iconChip} hitSlop={8}>
        {children}
      </Pressable>
    );
  }
  return <View style={styles.iconChip}>{children}</View>;
}

// A slide with an explicit pixel width — percentage width doesn't work here:
// a horizontal ScrollView's content width is meant to be driven BY its
// children (so there's something to scroll through), so a percentage-width
// child is a circular reference that resolves to 0. Also shows a visible
// fallback icon if the photo fails to load, instead of blank space.
function Slide({ photo, width }) {
  const [failed, setFailed] = useState(false);

  return (
    <View style={{ width, height: '100%' }}>
      {failed ? (
        <View style={[StyleSheet.absoluteFill, styles.fallback]}>
          <Svg width={32} height={32} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={1.5}>
            <Path d="M4 15l4.6-4.6a2 2 0 012.8 0L15 14m-2-2l1.6-1.6a2 2 0 012.8 0L20 13M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1z" />
            <Path d="M9 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" fill={colors.textMuted} />
          </Svg>
        </View>
      ) : (
        <Image
          source={photo}
          style={StyleSheet.absoluteFill}
          resizeMode="cover"
          onError={() => setFailed(true)}
        />
      )}
      {/* Darkening tint at top/bottom of the photo — colored to match
          nebulaBaseBottom (the page background's own darkest tone, see
          theme/colors.js) rather than flat navyBase, so this blends into
          the actual AnimatedGradientBackground behind the screen instead of
          reading as a differently-colored rectangle sitting on top of it. */}
      <LinearGradient
        colors={['rgba(23,10,20,0.55)', 'rgba(23,10,20,0)', 'rgba(23,10,20,0)', 'rgba(23,10,20,0.96)']}
        locations={[0, 0.28, 0.62, 1]}
        style={StyleSheet.absoluteFill}
      />
    </View>
  );
}

// bookmarked/onToggleBookmark: new this round — the second IconChip used to
// be purely decorative (no onPress at all). Now it's a real toggle, and it
// recolors to amber when saved, so it reads as a functional control rather
// than another back-style icon. See SavedContext.js for where the saved
// state actually lives (Venue/Event Detail owns the toggle call, this
// component just renders whatever state it's given).
export default function HeroGallery({ photos, ageAccess, onBack, bookmarked = false, onToggleBookmark }) {
  const width = useScreenWidth();
  const [activeIndex, setActiveIndex] = useState(0);
  const lastCount = photos.length - 1;

  // Bug fix: the dots indicator used to only listen for
  // onMomentumScrollEnd, which — on a `pagingEnabled` ScrollView — doesn't
  // reliably fire on every swipe. When a drag's release already lands
  // exactly on the next page (common with paging), iOS sometimes settles
  // there without ever entering a "momentum" phase, so
  // onMomentumScrollEnd never fires and the dots stay stuck on whichever
  // one was last correctly recorded (in practice, the first). Tracking the
  // index continuously via onScroll instead — not just at the end of a
  // gesture — means the dots update in real time and can't get stranded.
  const updateActiveIndex = (e) => {
    const w = e.nativeEvent.layoutMeasurement.width || width;
    if (!w) return;
    const idx = Math.round(e.nativeEvent.contentOffset.x / w);
    setActiveIndex(Math.max(0, Math.min(lastCount, idx)));
  };

  return (
    <View style={styles.hero}>
      <ScrollView
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={updateActiveIndex}
        scrollEventThrottle={32}
        onMomentumScrollEnd={updateActiveIndex}
      >
        {photos.map((photo, i) => (
          <Slide key={i} photo={photo} width={width} />
        ))}
      </ScrollView>

      <View style={styles.topbar}>
        <IconChip onPress={onBack}>
          <Svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.textPrimary} strokeWidth={2}>
            <Path d="M15 18l-6-6 6-6" />
          </Svg>
        </IconChip>
        <IconChip onPress={onToggleBookmark}>
          <Svg
            width={19}
            height={19}
            viewBox="0 0 24 24"
            fill={bookmarked ? colors.amber : 'none'}
            stroke={bookmarked ? colors.amber : colors.textPrimary}
            strokeWidth={2}
          >
            <Path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z" />
          </Svg>
        </IconChip>
      </View>

      <PhotoTag label={ageAccess} style={styles.ageTag} />

      <View style={styles.dotsRow} pointerEvents="none">
        {photos.map((_, i) => (
          <View key={i} style={[styles.dot, i === activeIndex && styles.dotActive]} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Taller than before so the photo comfortably runs underneath the venue
  // name in VenueDetailScreen's overlapping title block, instead of just
  // barely reaching it — see that screen's `overlapContent` comment for how
  // the overlap amount is tuned to the name specifically (not the meta/
  // rating line below it).
  hero: {
    height: 340,
    overflow: 'hidden',
  },
  fallback: {
    backgroundColor: colors.navySurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconChip: {
    width: ICON_CHIP_SIZE,
    height: ICON_CHIP_SIZE,
    borderRadius: ICON_CHIP_SIZE / 2,
    backgroundColor: 'rgba(12,15,22,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(245,243,239,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topbar: {
    position: 'absolute',
    top: 18,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ageTag: {
    position: 'absolute',
    top: 68,
    left: 16,
  },
  dotsRow: {
    position: 'absolute',
    bottom: 82,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: 'rgba(245,243,239,0.4)',
  },
  dotActive: {
    backgroundColor: colors.amber,
    width: 14,
    borderRadius: 3,
  },
});
