// AnimatedGradientBackground.js
//
// Muted nebula background, per CLAUDE.md's locked "Design System" spec:
// three soft, desaturated blooms — dusty rose, muted purple, muted warm
// brown — breathing and slowly roaming over a near-black base gradient
// (nebulaBaseTop -> nebulaBaseBottom). This supersedes the earlier, more
// vividly-colored "Aurora" version (5 more-saturated blobs plus a twinkling
// starfield) — the doc's own spec has no starfield and describes a more
// restrained, "static gradient composite... implement as layered
// expo-linear-gradient/RadialGradient views" look, so the starfield layer
// was dropped and the blob count trimmed from 5 to the 3 the doc actually
// calls for. The doc's "no gradient blobs" line (in its intro, about
// avoiding the generic "AI-generated app" look) reads as being about
// isolated decorative blob *shapes* as foreground ornamentation — not this
// ambient, edgeless, full-screen wash, which is exactly what its own
// concrete "Background:" bullet describes building.
//
// Built with `expo-linear-gradient` (for the base) + `react-native-svg`
// (for the blobs) + plain React state — deliberately no React Native
// `Animated` (see note below).
//
// Design note: amber is deliberately NOT one of the blob colors. Amber's
// one job in this app is the "happening now" signal (attendance pulse,
// active nav tab, ranking numerals) — keeping it out of the ambient
// background keeps that meaning intact. The blob colors use their own
// `nebulaRose` / `nebulaPurple` / `nebulaOrange` tokens (see
// theme/colors.js), which are deliberately different, more muted hues than
// `amber` — never the amber hex itself.
//
// Animation-driver note: this was originally built on RN's `Animated`
// API (Animated.loop + Animated.timing). Confirmed by live-measuring the
// rendered transform over several seconds that it never progresses past
// its starting frame in this project's exact setup (Expo SDK 54 downgrade +
// react-native-web 0.21.2) — true with useNativeDriver both on and off, no
// console errors either time. Same failure mode hit earlier building the
// Home/Detail gradient. So this drives everything with plain state + a
// timer instead, computing each blob's own sine-eased position from
// elapsed time — same visual curve, verified to actually move.
//
// Sizing note: blob sizes/positions are derived from the actual screen size
// via useScreenSize() rather than Dimensions.get('window') at module load —
// on the web preview the app renders inside a fixed-size phone frame that's
// narrower than the real browser window, so a module-level Dimensions read
// would size the blobs against the wrong box.
//
// Blur note: blobs were originally built on RN's cross-platform `filter`
// style (`[{ blur: n }]`). On a real iOS device that turned out to render
// each blob's full square bounding box as an opaque gray/white block behind
// the soft circular glow — the blur filter's offscreen render target isn't
// coming back through with real alpha on iOS in this Expo SDK 54 / New
// Architecture setup, even though it looked fine in the web preview. Rather
// than fight that platform gap, blobs are now drawn as an SVG radial
// gradient (Circle filled with a RadialGradient that fades to fully
// transparent at the edge, via react-native-svg — already a dependency used
// elsewhere in the app). That gives the same soft, edgeless glow look
// without a native blur filter at all, so there's no offscreen-buffer
// behavior to differ between platforms.
//
// Teleport note: on top of the constant subtle "breathing" pulse, each blob
// now also periodically fades fully to invisible and reappears at a new,
// randomized spot on screen — rather than breathing forever in one fixed
// place. The new spot is derived deterministically from elapsed time (a
// seeded pseudo-random keyed on the blob + a cycle index), not
// Math.random() at render time, so it's stable within a cycle and only
// changes when a new cycle begins.

import { useEffect, useMemo, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Defs, RadialGradient, Stop, Circle } from 'react-native-svg';
import { colors } from '../theme/colors';
import { useScreenSize } from '../theme/screenSize';

const TICK_MS = 100;

// Three blooms, per CLAUDE.md: dusty rose (bottom-left-ish), muted purple
// (right-side-ish), muted warm brown (bottom-center-ish) — roaming/breathing
// positions rather than the doc's literal fixed percentages, reusing this
// file's existing teleport system rather than pinning them statically, since
// the doc explicitly allows keeping "a subtle animation" here.
function buildBlobs(width, height) {
  return [
    {
      colors: [colors.nebulaRose, '#3D1A29'],
      size: width * 0.95,
      breatheDuration: 8000,
      breatheDelay: 0,
      minScale: 0.85,
      maxScale: 1.15,
      minOpacity: 0.35,
      maxOpacity: 0.58,
      blur: 75,
      seed: 11,
      cycleMs: 17000,
      holdRatio: 0.62,
    },
    {
      colors: [colors.nebulaPurple, '#20102A'],
      size: width * 0.85,
      breatheDuration: 9500,
      breatheDelay: 900,
      minScale: 0.82,
      maxScale: 1.12,
      minOpacity: 0.26,
      maxOpacity: 0.46,
      blur: 75,
      seed: 29,
      cycleMs: 19500,
      holdRatio: 0.6,
    },
    {
      colors: [colors.nebulaOrange, '#3D2515'],
      size: width * 0.7,
      breatheDuration: 10000,
      breatheDelay: 1600,
      minScale: 0.82,
      maxScale: 1.1,
      minOpacity: 0.15,
      maxOpacity: 0.3,
      blur: 80,
      seed: 47,
      cycleMs: 14500,
      holdRatio: 0.58,
    },
  ];
}

// Matches Easing.inOut(Easing.sin): slow start, slow end, fast middle.
function easeInOutSine(t) {
  const clamped = Math.max(0, Math.min(1, t));
  return -(Math.cos(Math.PI * clamped) - 1) / 2;
}

// Same shape as the original Animated.loop(sequence([timing 0->1, timing
// 1->0])): hold at 0 for `delay`, ease up to 1 over `duration`, ease back
// down to 0 over `duration`, repeat. Used for the constant subtle
// "breathing" scale/opacity pulse (config.breatheDuration/breatheDelay).
function blobProgress(elapsedMs, config) {
  const duration = config.duration ?? config.breatheDuration;
  const delay = config.delay ?? config.breatheDelay;
  const cycleMs = delay + duration * 2;
  const cyclePos = elapsedMs % cycleMs;
  if (cyclePos < delay) return 0;
  const t = cyclePos - delay;
  if (t < duration) return easeInOutSine(t / duration);
  return 1 - easeInOutSine((t - duration) / duration);
}

// Deterministic pseudo-random in [0, 1) from a numeric seed — used instead
// of Math.random() so a blob's teleport position only changes when its
// cycle index changes, not on every render.
function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function positionForCycle(config, cycleIndex, width, height) {
  const rx = seededRandom(config.seed + cycleIndex * 97.13);
  const ry = seededRandom(config.seed + cycleIndex * 57.71 + 13);
  // Allow the same slight off-screen bleed the original fixed positions
  // had, so teleported blobs can still land partly off-edge.
  const left = -config.size * 0.25 + rx * (width - config.size * 0.5);
  const top = -config.size * 0.25 + ry * (height - config.size * 0.5);
  return { top, left };
}

// Where in its teleport cycle the blob currently is: fully visible and
// holding position for most of the cycle, then fading out, teleporting
// (instantly, while invisible), and fading back in at the new spot.
function teleportPhase(elapsedMs, config) {
  const { cycleMs, holdRatio } = config;
  const holdMs = cycleMs * holdRatio;
  const fadeMs = (cycleMs - holdMs) / 2;
  const cycleIndex = Math.floor(elapsedMs / cycleMs);
  const cyclePos = elapsedMs % cycleMs;

  if (cyclePos < holdMs) {
    return { opacityFactor: 1, posIndex: cycleIndex };
  }
  if (cyclePos < holdMs + fadeMs) {
    const t = (cyclePos - holdMs) / fadeMs;
    return { opacityFactor: 1 - t, posIndex: cycleIndex };
  }
  const t = (cyclePos - holdMs - fadeMs) / fadeMs;
  return { opacityFactor: t, posIndex: cycleIndex + 1 };
}

// Higher `blur` config values now control how early the radial gradient
// starts fading (a smaller solid core, more edge softness) rather than a
// literal blur radius — same knob, same intent ("softer/glowier"), just
// applied through gradient stops instead of a filter.
function softnessStop(blur) {
  return Math.max(18, Math.min(48, 58 - blur * 0.45));
}

function Blob({ config, elapsedMs, width, height }) {
  const breathe = blobProgress(elapsedMs, config);
  const scale = config.minScale + (config.maxScale - config.minScale) * breathe;
  const breatheOpacity = config.minOpacity + (config.maxOpacity - config.minOpacity) * breathe;

  const { opacityFactor, posIndex } = teleportPhase(elapsedMs, config);
  const { top, left } = positionForCycle(config, posIndex, width, height);
  const opacity = breatheOpacity * opacityFactor;
  const gradientId = `blob-grad-${config.seed}`;
  const coreStop = softnessStop(config.blur);

  return (
    <View
      style={{
        position: 'absolute',
        top,
        left,
        width: config.size,
        height: config.size,
        opacity,
        transform: [{ scale }],
      }}
    >
      <Svg width="100%" height="100%" viewBox="0 0 100 100">
        <Defs>
          <RadialGradient id={gradientId} cx="50%" cy="50%" r="50%">
            <Stop offset="0%" stopColor={config.colors[0]} stopOpacity={1} />
            <Stop offset={`${coreStop}%`} stopColor={config.colors[0]} stopOpacity={0.65} />
            <Stop offset={`${Math.min(96, coreStop + 30)}%`} stopColor={config.colors[1]} stopOpacity={0.22} />
            <Stop offset="100%" stopColor={config.colors[1]} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx="50" cy="50" r="50" fill={`url(#${gradientId})`} />
      </Svg>
    </View>
  );
}

export default function AnimatedGradientBackground() {
  const { width, height } = useScreenSize();
  const blobs = useMemo(() => buildBlobs(width, height), [width, height]);
  const [elapsedMs, setElapsedMs] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const id = setInterval(() => {
      setElapsedMs(Date.now() - start);
    }, TICK_MS);
    return () => clearInterval(id);
  }, []);

  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      {/* Base fill — near-black top-to-bottom gradient per CLAUDE.md
          (linear-gradient(180deg, #0e0810 0%, #170a14 60%)), not a flat
          navyBase fill like the earlier Aurora version used. */}
      <LinearGradient
        colors={[colors.nebulaBaseTop, colors.nebulaBaseBottom]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        locations={[0, 0.6]}
        style={StyleSheet.absoluteFillObject}
      />
      {blobs.map((b, i) => (
        <Blob key={i} config={b} elapsedMs={elapsedMs} width={width} height={height} />
      ))}
    </View>
  );
}
