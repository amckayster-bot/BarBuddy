// EventCard.js
//
// Events tab's vertical list row (sorted by start time by the caller — see
// EventsScreen.js). Per CLAUDE.md: a category-color dot (reusing the
// existing Search category color system), the specific event type as plain
// text, and the amber "N going" pulse.
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { CATEGORY_DEFS } from '../data/searchCategories';

function categoryColor(key) {
  return CATEGORY_DEFS.find((c) => c.key === key)?.color || colors.amber;
}

export default function EventCard({ event }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('EventDetail', { eventId: event.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={[styles.dot, { backgroundColor: categoryColor(event.category) }]} />
      <View style={styles.text}>
        <Text style={styles.title} numberOfLines={1}>
          {event.title}
        </Text>
        <Text style={styles.meta} numberOfLines={1}>
          {event.eventType} · {event.venueName}
        </Text>
      </View>
      <View style={styles.right}>
        <Text style={styles.time}>{event.startLabel}</Text>
        <View style={styles.pulse}>
          <View style={styles.pulseDot} />
          <Text style={styles.pulseText}>{event.goingTonight} going</Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 13,
    marginBottom: 10,
  },
  pressed: {
    opacity: 0.85,
  },
  dot: {
    width: 9,
    height: 9,
    borderRadius: 4.5,
  },
  text: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14.5,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textMuted,
  },
  right: {
    alignItems: 'flex-end',
  },
  time: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.textPrimary,
    marginBottom: 4,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  pulseDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 11,
    color: colors.amber,
  },
});
