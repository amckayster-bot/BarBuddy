// leafletMapHtml.js
//
// Shared Leaflet + CARTO "Dark Matter" HTML builder — used by both the full
// interactive MapScreen and the small read-only Home preview
// (MapPlaceholder), so the two maps look and behave consistently instead of
// each hand-rolling their own copy. CARTO's dark tiles are OpenStreetMap
// data (real streets/roads included) styled dark to match the app's navy
// theme, free, no API key required.
//
// `highlightMarker` renders one special pin (a glowing ring + dot, colored
// via `highlightMarker.color`) distinct from the rating-badge markers used
// for everything in `markers` — e.g. TD Garden's amber "main landmark" pin
// on the full map, or the Home preview's red "you are here" dot. Both are
// the same rendering trick, just different colors/meanings.
//
// Each entry in `markers` is expected to carry `rating` and `color` (see
// mapCoords.js's venueMarkers()) — every venue pin on the map is now a
// small colored badge showing that venue's rating, colored on the same
// red/orange/yellow/green scale used for rating badges elsewhere in the
// app, rather than Leaflet's plain default blue pin.
export function buildLeafletMapHtml({ center, zoom, markers = [], highlightMarker, interactive = true }) {
  const markerJs = markers
    .map((m) => {
      const ratingText = typeof m.rating === 'number' ? m.rating.toFixed(1) : '?';
      const iconJs = `L.divIcon({
        className: '',
        html: '<div class="rating-pin" style="background:${m.color ?? '#E3A857'}"><span>${ratingText}</span></div>',
        iconSize: [30, 30],
        iconAnchor: [15, 15],
      })`;
      const popupText = `<b>${m.name}</b><br/>${m.category} · ${m.neighborhood}<br/>★ ${ratingText}`;
      return `L.marker([${m.lat}, ${m.lng}], { icon: ${iconJs} }).addTo(map).bindPopup(${JSON.stringify(popupText)});`;
    })
    .join('\n');

  const highlightJs = highlightMarker
    ? `
    var highlightIcon = L.divIcon({
      className: '',
      html: '<div class="hl-ring"><div class="hl-dot"></div></div>',
      iconSize: [${highlightMarker.size ?? 28}, ${highlightMarker.size ?? 28}],
      iconAnchor: [${(highlightMarker.size ?? 28) / 2}, ${(highlightMarker.size ?? 28) / 2}],
    });
    L.marker([${highlightMarker.lat}, ${highlightMarker.lng}], { icon: highlightIcon, zIndexOffset: 1000 })
      .addTo(map)${
        highlightMarker.label
          ? `.bindPopup(${JSON.stringify(highlightMarker.label)})${highlightMarker.openPopup ? '.openPopup()' : ''}`
          : ''
      };
  `
    : '';

  const interactionFlags = interactive
    ? { zoomControl: true, dragging: true, touchZoom: true, scrollWheelZoom: true, doubleClickZoom: true }
    : {
        zoomControl: false,
        dragging: false,
        touchZoom: false,
        scrollWheelZoom: false,
        doubleClickZoom: false,
        boxZoom: false,
        keyboard: false,
        attributionControl: false,
      };
  const optionsJs = Object.entries(interactionFlags)
    .map(([k, v]) => `${k}: ${v}`)
    .join(', ');

  const dotSize = highlightMarker?.size ?? 28;
  const ringColor = highlightMarker?.color ? `${highlightMarker.color}40` : 'rgba(227,168,87,0.25)';
  const dotColor = highlightMarker?.color ?? '#E3A857';

  return `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    html, body, #map { height: 100%; margin: 0; padding: 0; background: #0C0F16; }
    .leaflet-popup-content-wrapper { background: #171B24; color: #F5F3EF; border: 1px solid #2A2F3A; }
    .leaflet-popup-content { font-family: -apple-system, sans-serif; font-size: 13px; }
    .leaflet-popup-tip { background: #171B24; }
    .hl-ring {
      width: ${dotSize}px; height: ${dotSize}px; border-radius: ${dotSize / 2}px;
      background: ${ringColor};
      display: flex; align-items: center; justify-content: center;
    }
    .hl-dot {
      width: ${dotSize / 2}px; height: ${dotSize / 2}px; border-radius: ${dotSize / 4}px;
      background: ${dotColor};
      border: 2px solid #0C0F16;
    }
    .rating-pin {
      width: 30px; height: 30px; border-radius: 15px;
      display: flex; align-items: center; justify-content: center;
      border: 2px solid #0C0F16;
      box-shadow: 0 1px 4px rgba(0,0,0,0.5);
    }
    .rating-pin span {
      font-family: -apple-system, sans-serif;
      font-size: 11px;
      font-weight: 700;
      color: #0C0F16;
    }
  </style>
</head>
<body>
  <div id="map"></div>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>
    var map = L.map('map', { ${optionsJs} }).setView([${center.lat}, ${center.lng}], ${zoom});
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 20,
    }).addTo(map);
    ${highlightJs}
    ${markerJs}
  </script>
</body>
</html>`;
}
