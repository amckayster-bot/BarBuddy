// DealsSection.js
//
// "Deals" row on Home, above Need Inspiration and Top Ten — for the segment
// of people whose main question isn't "what's nearby" but "what's nearby
// with something good going on right now." Same horizontal-scroll card
// pattern as Near You (see MiniCard), but with a deal badge/tag instead of
// category+distance, and a distinct accent color (green — money/savings —
// deliberately different from amber, which stays reserved for the "happening
// now" attendance signal elsewhere in the app) so it reads as its own kind
// of card at a glance.
//
// Now wrapped in the same full-width dark banner treatment as Near You (see
// NearYouSection.js) — 60% opacity navySurface, top/bottom border, own
// section label inside the banner — instead of living directly on Home's
// plain background, so the two horizontal-scroll modules on Home read as
// the same family of component.
//
// Photos get a subtle top-to-bottom gradient (20% black at the top fading
// to fully transparent at the bottom) so the tag/Today badges sit on a
// touch of contrast without looking like a heavy-handed dark overlay —
// kept deliberately light (20%, not 50%+) to stay elegant rather than
// muddy the photo underneath.
//
// Swipe-conflict note: like Near You, this is a nested horizontal scroller
// that used to fight with SwipeableTabs' own left/right page swipe (see the
// nested-horizontal-scroll note in SwipeableTabs.js). Same two-layer fix:
// gesture-handler's ScrollView instead of RN's, plus the onTouchStart/
// onTouchEnd/onTouchCancel flag to TabPagerContext as extra insurance.
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';
import { useTabPager } from '../context/TabPagerContext';

const BANNER_PADDING = spacing.lg;

function DealCard({ deal }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('VenueDetail', { venueId: deal.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.photoWrap}>
        <Image source={deal.photo} style={styles.photo} />
        <LinearGradient
          colors={['rgba(0,0,0,0.2)', 'rgba(0,0,0,0)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFillObject}
          pointerEvents="none"
        />
        <View style={styles.tagBadge}>
          <Text style={styles.tagBadgeText}>{deal.tag}</Text>
        </View>
        {deal.isActiveToday && (
          <View style={styles.todayBadge}>
            <Text style={styles.todayBadgeText}>Today</Text>
          </View>
        )}
      </View>
      <Text style={styles.name} numberOfLines={1}>
        {deal.name}
      </Text>
      <Text style={styles.dealText} numberOfLines={2}>
        {deal.text}
      </Text>
      <Text style={styles.meta} numberOfLines={1}>
        {deal.neighborhood}
        {deal.endsLabel ? ` · ${deal.endsLabel}` : ''}
      </Text>
    </Pressable>
  );
}

export default function DealsSection({ deals }) {
  const { setInnerScrollActive } = useTabPager();

  return (
    <View style={styles.banner}>
      <Text style={styles.label}>Deals</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.content}
        onTouchStart={() => setInnerScrollActive(true)}
        onTouchEnd={() => setInnerScrollActive(false)}
        onTouchCancel={() => setInnerScrollActive(false)}
      >
        {deals.map((deal) => (
          <DealCard key={deal.id} deal={deal} />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  // Same shape as NearYouSection's banner — no border radius/side borders
  // since it's meant to bleed full-width (the negative horizontal margin
  // that achieves that lives on the wrapping section in HomeScreen.js).
  banner: {
    backgroundColor: 'rgba(23,27,36,0.6)',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
    paddingVertical: BANNER_PADDING,
  },
  label: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
    marginBottom: 12,
    marginHorizontal: BANNER_PADDING,
  },
  content: {
    gap: spacing.md,
    paddingHorizontal: BANNER_PADDING,
    // Small vertical padding so the pressed-state opacity/shadow on the
    // first/last card doesn't read as clipped against the row's own edge.
    paddingVertical: 4,
  },
  card: {
    width: 168,
  },
  pressed: {
    opacity: 0.85,
  },
  photoWrap: {
    height: 100,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 8,
    backgroundColor: colors.navySurface,
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  tagBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: colors.ratingGreen,
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  tagBadgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 10.5,
    color: colors.navyBase,
  },
  // Amber, not green — this is the app's one "happening right now" signal
  // (see theme/colors.js), and "this deal is live today" is exactly that
  // meaning, distinct from the tag badge's "what kind of deal this is."
  todayBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: colors.amber,
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  todayBadgeText: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 10.5,
    color: colors.navyBase,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  dealText: {
    fontFamily: fonts.bodyRegular,
    fontSize: 12,
    color: colors.textPrimary,
    opacity: 0.85,
    lineHeight: 16,
    marginBottom: 3,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
  },
});
