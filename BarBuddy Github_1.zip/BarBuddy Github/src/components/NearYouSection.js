// NearYouSection.js
//
// Home's "Near You" scrolling wheel — per CLAUDE.md's locked "Home Screen
// (FINAL)" spec: a fixed-height container showing exactly 3 rows at a time,
// vertically scrollable with scroll-snap, holding all 9 fixture venues.
// Deliberately NOT a horizontal carousel (that was the previous
// implementation, superseded this round) — this is a distinct interaction
// pattern the doc calls out on purpose. Soft fade gradients at the top/
// bottom edges hint that more rows exist above/below than are currently
// visible, and a caption underneath spells that out in text too.
//
// Rows sit directly on the page's own nebula background (no enclosing
// dark-banner panel like the old carousel had) — each row is its own small
// card instead, matching the template exactly.
//
// Gesture note: unlike the old horizontal carousel, this doesn't need any
// of the swipe-conflict handling SwipeableTabs.js's nested-horizontal-
// scroll note describes (gesture-handler ScrollView, innerScrollActive
// flag, etc.) — the page pager's Gesture.Pan is configured with
// failOffsetY, so purely vertical scrolling here never has anything to
// negotiate with it in the first place. Plain RN ScrollView is enough.
import { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';

const VISIBLE_ROWS = 3;
const ROW_HEIGHT = 68;
const ROW_GAP = 8;
const ROW_INTERVAL = ROW_HEIGHT + ROW_GAP;
const WHEEL_HEIGHT = ROW_HEIGHT * VISIBLE_ROWS + ROW_GAP * (VISIBLE_ROWS - 1); // 204
const FADE_HEIGHT = 22;

function WheelRow({ place, isLast }) {
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={() => navigation.navigate('VenueDetail', { venueId: place.id })}
      style={({ pressed }) => [styles.row, isLast && styles.rowLast, pressed && styles.rowPressed]}
    >
      <View style={styles.rowText}>
        <Text style={styles.rowName} numberOfLines={1}>
          {place.name}
        </Text>
        <Text style={styles.rowMeta} numberOfLines={1}>
          {place.category}
        </Text>
      </View>
      <Text style={styles.rowDistance}>{place.distance}</Text>
    </Pressable>
  );
}

export default function NearYouSection({ places }) {
  const total = places.length;
  // expo-linear-gradient needs concrete colors, not a CSS "transparent"
  // keyword — derive a fully-transparent variant of the base gradient's
  // dark tone so the fade blends into whatever's behind it (the page
  // background, not a card panel) rather than fading to black.
  const fadeColors = useMemo(() => [colors.nebulaBaseBottom, `${colors.nebulaBaseBottom}00`], []);

  return (
    <View style={styles.section}>
      <View style={styles.headRow}>
        <Text style={styles.label}>Near you</Text>
        <Text style={styles.seeAll}>See all</Text>
      </View>

      <View style={styles.wheelWrap}>
        <ScrollView
          style={styles.wheel}
          showsVerticalScrollIndicator={false}
          snapToInterval={ROW_INTERVAL}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {places.map((place, i) => (
            <WheelRow key={place.id} place={place} isLast={i === total - 1} />
          ))}
        </ScrollView>
        <LinearGradient
          colors={fadeColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[styles.fade, styles.fadeTop]}
          pointerEvents="none"
        />
        <LinearGradient
          colors={fadeColors.slice().reverse()}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[styles.fade, styles.fadeBottom]}
          pointerEvents="none"
        />
      </View>
      <Text style={styles.hint}>
        {VISIBLE_ROWS} of {total} shown · scroll for more
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: spacing.xxl,
  },
  headRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  // 16px per CLAUDE.md's "Section labels: 16px, Inter 600, uppercase" spec
  // — the raw template's own CSS uses 13px here, but the doc's explicit
  // written token takes precedence, and it keeps this label sized the same
  // as Featured/Map's labels elsewhere on this same screen.
  label: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.92,
  },
  // Visual only for now — no ranked-list/"see all" destination screen
  // exists yet (same reasoning as the Browse row's utility tiles).
  seeAll: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.amber,
  },
  wheelWrap: {
    position: 'relative',
  },
  wheel: {
    height: WHEEL_HEIGHT,
  },
  row: {
    height: ROW_HEIGHT,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.09)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    paddingHorizontal: 14,
    marginBottom: ROW_GAP,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rowLast: {
    marginBottom: 0,
  },
  rowPressed: {
    opacity: 0.85,
  },
  rowText: {
    flex: 1,
    minWidth: 0,
    marginRight: 10,
  },
  rowName: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 13.5,
    color: colors.textPrimary,
  },
  rowMeta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
    marginTop: 2,
  },
  rowDistance: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
  },
  fade: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: FADE_HEIGHT,
  },
  fadeTop: {
    top: 0,
  },
  fadeBottom: {
    bottom: 0,
  },
  hint: {
    textAlign: 'center',
    fontFamily: fonts.bodyRegular,
    fontSize: 10,
    color: '#7A6F76',
    marginTop: 6,
  },
});
