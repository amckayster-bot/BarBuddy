// CompactSearchBar.js
//
// Home's "Compact search bar" — per CLAUDE.md's Home Screen item 2, a
// single-line pill sitting directly below the greeting header, above
// Featured. Deliberately quiet: no icon-heavy decoration, sized to read as
// one line, not a boxed section with its own header/label.
//
// Tapping/typing opens a dropdown (recent searches + quick category
// shortcuts, reusing Search's own CATEGORY_DEFS color system), rendered as
// an absolutely-positioned overlay that floats above the rest of Home's
// content — it never pushes Featured or anything below it down the page.
// No new dependency needed for the reveal animation: same manual RAF +
// plain state approach as the rest of the app (see
// AnimatedGradientBackground.js's animation-driver note on why `Animated`
// isn't used here).
//
// This is a shortcut INTO Search, not a second search implementation —
// submitting hands the text off through SearchFilterContext's
// submitSearchQuery (SearchScreen.js picks it up and clears it), then
// switches to the Search tab via TabPagerContext's goToName. Plain
// navigation.navigate('Search') would NOT work here — SwipeableTabs is a
// custom swipe pager, not a real React Navigation tab navigator, so
// goToName is the actual mechanism (see SwipeableTabs.js).
//
// Tap-away-to-close: HomeScreen.js's ScrollView needs
// keyboardShouldPersistTaps="handled" for this to behave correctly — with
// RN's default ("never"), a tap on one of this dropdown's own Pressables
// (a recent search, a category chip) while the text input is focused would
// get swallowed as a "dismiss the keyboard first" tap instead of actually
// registering. "handled" lets interactive elements inside the dropdown
// register their press immediately, while a tap on any non-interactive
// area still blurs the input (via onBlur below) and closes the dropdown —
// exactly the "tap away to dismiss" behavior asked for, with no extra
// full-screen scrim view needed.
import { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';
import { CATEGORY_DEFS } from '../data/searchCategories';
import { useSearchFilters } from '../context/SearchFilterContext';
import { useTabPager } from '../context/TabPagerContext';

const REVEAL_MS = 180;

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

export default function CompactSearchBar() {
  const { submitSearchQuery, recentSearches, ensureCategoryActive } = useSearchFilters();
  const { goToName } = useTabPager();
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!open) {
      setElapsed(0);
      return undefined;
    }
    startRef.current = null;
    const step = (ts) => {
      if (startRef.current == null) startRef.current = ts;
      const t = ts - startRef.current;
      setElapsed(t);
      if (t < REVEAL_MS) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [open]);

  const revealT = easeOutCubic(Math.min(1, elapsed / REVEAL_MS));
  const dropdownStyle = {
    opacity: revealT,
    transform: [{ translateY: (1 - revealT) * -8 }],
  };

  const goToSearch = (query) => {
    submitSearchQuery(query);
    setOpen(false);
    inputRef.current?.blur();
    goToName('Search');
  };

  const handleSubmit = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    goToSearch(trimmed);
  };

  const handleShortcut = (key) => {
    ensureCategoryActive(key);
    setOpen(false);
    inputRef.current?.blur();
    goToName('Search');
  };

  return (
    // zIndex/elevation so the dropdown draws above Featured and everything
    // else below it in Home's content — it's a sibling in normal document
    // flow (this whole component only ever takes up one pill's worth of
    // height), the dropdown itself is what's pulled out of flow via
    // `position: absolute`.
    <View style={styles.wrap}>
      <View style={[styles.pill, open && styles.pillActive]}>
        <Svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
          <Circle cx={11} cy={11} r={7} />
          <Path d="M21 21l-4.3-4.3" />
        </Svg>
        <TextInput
          ref={inputRef}
          value={text}
          onChangeText={setText}
          onFocus={() => setOpen(true)}
          onBlur={() => setOpen(false)}
          onSubmitEditing={handleSubmit}
          placeholder="Search bars, clubs, events..."
          placeholderTextColor={colors.textMuted}
          style={styles.input}
          returnKeyType="search"
        />
      </View>

      {open && (
        <View style={[styles.dropdown, dropdownStyle]}>
          {recentSearches.length > 0 && (
            <View style={styles.dropdownSection}>
              <Text style={styles.dropdownLabel}>Recent</Text>
              {recentSearches.map((q) => (
                <Pressable key={q} onPress={() => goToSearch(q)} style={styles.recentRow} hitSlop={4}>
                  <Svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}>
                    <Circle cx={12} cy={12} r={8} />
                    <Path d="M12 8v4l2.5 2.5" />
                  </Svg>
                  <Text style={styles.recentText} numberOfLines={1}>
                    {q}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          <View style={styles.dropdownSection}>
            <Text style={styles.dropdownLabel}>Quick Categories</Text>
            <View style={styles.chipRow}>
              {CATEGORY_DEFS.map((c) => (
                <Pressable
                  key={c.key}
                  onPress={() => handleShortcut(c.key)}
                  style={[styles.chip, { borderColor: c.fill, backgroundColor: `${c.fill}1F` }]}
                >
                  <View style={[styles.chipDot, { backgroundColor: c.color }]} />
                  <Text style={[styles.chipText, { color: c.color }]}>{c.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'relative',
    zIndex: 30,
    elevation: 30,
    marginBottom: spacing.xl,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    height: 42,
    paddingHorizontal: 14,
    borderRadius: 21,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: colors.border,
  },
  pillActive: {
    borderColor: 'rgba(227,168,87,0.5)',
  },
  input: {
    flex: 1,
    padding: 0,
    fontFamily: fonts.bodyRegular,
    fontSize: 14,
    color: colors.textPrimary,
  },
  dropdown: {
    position: 'absolute',
    top: 50,
    left: 0,
    right: 0,
    backgroundColor: colors.navySurface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 16,
    padding: 14,
  },
  dropdownSection: {
    marginBottom: 14,
  },
  dropdownLabel: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.3,
    color: colors.textMuted,
    marginBottom: 8,
  },
  recentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    paddingVertical: 7,
  },
  recentText: {
    flex: 1,
    fontFamily: fonts.bodyRegular,
    fontSize: 13.5,
    color: colors.textPrimary,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  chipDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  chipText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
  },
});
