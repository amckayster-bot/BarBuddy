// DateStrip.js
//
// Events tab's horizontal date selector — Today/Tomorrow/dates, per
// CLAUDE.md's Events screen skeleton spec. Visual + functional (picking a
// day filters the vertical list below), but doesn't touch any backend —
// same fixture data underneath either way.
//
// This is a HORIZONTAL scroller nested inside EventsScreen's vertical
// scroll, which is itself nested inside the horizontally-swipeable tab
// pager (SwipeableTabs.js) — the exact nested-horizontal-scroll conflict
// Near You/Deals used to hit back when they were carousels. Same fix:
// gesture-handler's own ScrollView (not RN core's) plus flagging
// TabPagerContext's setInnerScrollActive on touch, so a drag here can never
// get mistaken for a page-swipe.
import { Pressable, StyleSheet, Text } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { dayLabel } from '../data/events';
import { useTabPager } from '../context/TabPagerContext';

const DAYS = [0, 1, 2, 3, 4, 5, 6];

export default function DateStrip({ selected, onSelect }) {
  const { setInnerScrollActive } = useTabPager();

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.row}
      onTouchStart={() => setInnerScrollActive(true)}
      onTouchEnd={() => setInnerScrollActive(false)}
      onTouchCancel={() => setInnerScrollActive(false)}
    >
      {DAYS.map((d) => {
        const active = d === selected;
        return (
          <Pressable key={d} onPress={() => onSelect(d)} style={[styles.pill, active && styles.pillActive]}>
            <Text style={[styles.label, active && styles.labelActive]}>{dayLabel(d)}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: {
    gap: 8,
    paddingVertical: 2,
  },
  pill: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  pillActive: {
    borderColor: colors.amber,
    backgroundColor: 'rgba(227,168,87,0.14)',
  },
  label: {
    fontFamily: fonts.bodyMedium,
    fontSize: 13,
    color: colors.textMuted,
  },
  labelActive: {
    fontFamily: fonts.bodySemiBold,
    color: colors.amber,
  },
});
