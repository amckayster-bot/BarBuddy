// TrendingRail.js
//
// Events tab's "Trending Tonight" horizontal rail, per CLAUDE.md's Events
// screen skeleton spec — the highest-attendance events happening today.
// Cards reuse the same category-color-dot + amber "N going" pulse pattern
// as the vertical list below (EventCard.js), just in a photo-card layout.
//
// Same nested-horizontal-scroll situation as DateStrip.js above it on the
// page (horizontal scroller inside a vertical scroll inside the
// horizontally-swipeable tab pager) — gesture-handler's ScrollView +
// TabPagerContext's setInnerScrollActive flag, see that file's comment for
// the full reasoning.
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import { CATEGORY_DEFS } from '../data/searchCategories';
import { useTabPager } from '../context/TabPagerContext';

function categoryColor(key) {
  return CATEGORY_DEFS.find((c) => c.key === key)?.color || colors.amber;
}

function TrendingCard({ event }) {
  const navigation = useNavigation();
  return (
    <Pressable
      onPress={() => navigation.navigate('EventDetail', { eventId: event.id })}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <Image source={{ uri: event.photo }} style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={['rgba(12,15,22,0)', 'rgba(12,15,22,0.92)']}
        locations={[0.35, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.dotRow}>
        <View style={[styles.dot, { backgroundColor: categoryColor(event.category) }]} />
        <Text style={styles.eventType} numberOfLines={1}>
          {event.eventType}
        </Text>
      </View>
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>
          {event.title}
        </Text>
        <Text style={styles.venue} numberOfLines={1}>
          {event.venueName}
        </Text>
        <View style={styles.pulse}>
          <View style={styles.pulseDot} />
          <Text style={styles.pulseText}>{event.goingTonight} going</Text>
        </View>
      </View>
    </Pressable>
  );
}

export default function TrendingRail({ events }) {
  const { setInnerScrollActive } = useTabPager();

  if (!events.length) return null;

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.row}
      onTouchStart={() => setInnerScrollActive(true)}
      onTouchEnd={() => setInnerScrollActive(false)}
      onTouchCancel={() => setInnerScrollActive(false)}
    >
      {events.map((event) => (
        <TrendingCard key={event.id} event={event} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: {
    gap: 12,
    paddingVertical: 2,
  },
  card: {
    width: 168,
    height: 130,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
  },
  pressed: {
    opacity: 0.85,
  },
  dotRow: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  eventType: {
    flexShrink: 1,
    fontFamily: fonts.bodyMedium,
    fontSize: 10.5,
    color: colors.textPrimary,
  },
  content: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    right: 10,
  },
  title: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  venue: {
    fontFamily: fonts.bodyRegular,
    fontSize: 11,
    color: colors.textMuted,
    marginBottom: 5,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  pulseDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 10.5,
    color: colors.amber,
  },
});
