// FeaturedCard.js
//
// Home's Featured card — the one deliberate exception to CLAUDE.md's normal
// Venue/Event Detail transition rules. Tapping it does NOT trigger the
// photo-enlarge transition; instead the detail text (name, category/
// neighborhood, rating) fades in top-to-bottom in place, over the
// still-static-size photo. Per the confirmed answer, once that reveal
// finishes it continues on into the real Venue Detail screen (with that
// screen's own normal photo-enlarge entrance) after a short pause — so
// Featured still works as a real entry point into a venue, just with this
// one extra preview step in front of it. `skipEntryAnimation` isn't passed
// on that navigate() call specifically because Venue Detail's transition
// SHOULD play normally at that point — this in-place reveal is a separate,
// earlier animation that already finished.
//
// The amber "N going tonight" pulse is left out of the reveal sequence on
// purpose — same as Venue/Event Detail, it's an ambient "happening now"
// signal (always visible), not descriptive detail text.
import { useEffect, useRef, useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/colors';
import { fonts } from '../theme/typography';
import PhotoTag from './PhotoTag';
import StarRating from './StarRating';

const BLOCK_MS = 260;
const BLOCK_STAGGER_MS = 90;
const BLOCK_COUNT = 3; // name, meta, rating
const HOLD_MS = 650; // time to let the reveal actually be read before continuing on

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

export default function FeaturedCard({ place }) {
  const navigation = useNavigation();
  const [revealed, setRevealed] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  const holdTimerRef = useRef(null);

  useEffect(() => {
    if (!revealed) return undefined;
    const totalMs = BLOCK_STAGGER_MS * (BLOCK_COUNT - 1) + BLOCK_MS;
    startRef.current = null;

    const step = (ts) => {
      if (startRef.current == null) startRef.current = ts;
      const t = ts - startRef.current;
      setElapsed(t);
      if (t < totalMs) {
        rafRef.current = requestAnimationFrame(step);
      } else {
        holdTimerRef.current = setTimeout(() => {
          navigation.navigate('VenueDetail', { venueId: place.id });
        }, HOLD_MS);
      }
    };
    rafRef.current = requestAnimationFrame(step);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    };
  }, [revealed, navigation, place.id]);

  const getBlockStyle = (index) => {
    const delay = index * BLOCK_STAGGER_MS;
    const t = easeOutCubic(Math.min(1, Math.max(0, (elapsed - delay) / BLOCK_MS)));
    return { opacity: t, transform: [{ translateY: (1 - t) * 10 }] };
  };

  const handlePress = () => {
    if (revealed) return;
    setRevealed(true);
  };

  return (
    <Pressable
      onPress={handlePress}
      disabled={revealed}
      style={({ pressed }) => [styles.card, pressed && !revealed && styles.pressed]}
    >
      <Image source={place.photo} style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={['rgba(12,15,22,0)', 'rgba(12,15,22,0.94)']}
        locations={[0.38, 1]}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.tagRow}>
        <PhotoTag label={place.ageAccess} />
      </View>
      <View style={styles.content}>
        {revealed && (
          <>
            <Text style={[styles.name, getBlockStyle(0)]}>{place.name}</Text>
            <Text style={[styles.meta, getBlockStyle(1)]}>
              {place.category} · {place.neighborhood}
            </Text>
            <View style={[styles.ratingRow, getBlockStyle(2)]}>
              <StarRating rating={place.rating} size={12} />
              <Text style={styles.ratingNum}>{place.rating.toFixed(1)}</Text>
            </View>
          </>
        )}
        {!revealed && <Text style={styles.hint}>Tap for details</Text>}
        <View style={styles.pulse}>
          <View style={styles.dot} />
          <Text style={styles.pulseText}>{place.attending} going tonight</Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.85,
  },
  card: {
    height: 220,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.navySurface,
  },
  tagRow: {
    position: 'absolute',
    top: 14,
    left: 14,
  },
  content: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    right: 16,
  },
  name: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 20,
    color: colors.textPrimary,
    marginBottom: 4,
  },
  meta: {
    fontFamily: fonts.bodyRegular,
    fontSize: 13,
    color: colors.textMuted,
    marginBottom: 8,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  ratingNum: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 12.5,
    color: colors.textPrimary,
  },
  hint: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.textMuted,
    marginBottom: 10,
  },
  pulse: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.amber,
    shadowColor: colors.amber,
    shadowOpacity: 0.7,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
  },
  pulseText: {
    fontFamily: fonts.bodyMedium,
    fontSize: 12,
    color: colors.amber,
  },
});
