// BrowseRow.js
//
// Home's "Browse" section — per the latest round of feedback, back to a
// single horizontal row (not the 2-column grid from the previous round),
// with every tile built the exact same way now: a solid/gradient color
// fill, a small matching icon, and a label. The old two-tier system
// (translucent amber-outline "utility" tiles vs. vibrant-filled "category"
// tiles) is gone — Deals and Top Places now get their own filled colors and
// icons just like Bars/Clubs/etc., so the whole row reads as one consistent
// tile family instead of two different styles living side by side.
//
// Order: Top Places, Deals, then the category tiles, then Bookmarked last
// (renamed from "Saved" — same destination, SavedScreen.js, just a label/
// position change here).
//
// Color choices for the non-category tiles: Top Places uses amber, which
// the design system already reserves specifically for "ranking numerals"
// among its allowed amber uses (see theme/colors.js) — a ranked-places tile
// is exactly that use case. Deals gets its own warm orange (distinct from
// amber, borrowed from the existing ratingOrange token) for a "hot right
// now" read. Bookmarked gets a neutral slate — deliberately NOT a vibrant
// category color, since it isn't a venue category, just colored solidly
// like everything else per this round's "all filled in with a color" note.
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle, Path, Polygon, Rect } from 'react-native-svg';
import { colors, spacing } from '../theme/colors';
import { fonts } from '../theme/typography';

const ICON_COLOR = '#FFFFFF';

function TileIcon({ name }) {
  switch (name) {
    case 'top-places':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill={ICON_COLOR}>
          <Polygon points="12 2 15 9 22 9.5 17 14.5 18.5 22 12 18 5.5 22 7 14.5 2 9.5 9 9" />
        </Svg>
      );
    case 'deals':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Path d="M20.59 13.41L11 3.83A2 2 0 009.59 3.24L4 3a1 1 0 00-1 1l.24 5.59a2 2 0 00.59 1.41l9.58 9.58a2 2 0 002.83 0l4.35-4.35a2 2 0 000-2.82z" />
          <Circle cx={8} cy={8} r={1.4} fill={ICON_COLOR} stroke="none" />
        </Svg>
      );
    case 'bars':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Path d="M4 4h16l-6.5 8v6h3v2H7.5v-2h3v-6z" />
        </Svg>
      );
    case 'clubs':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Circle cx={9} cy={17} r={2.4} />
          <Circle cx={18} cy={15} r={2.4} />
          <Path d="M11.4 17V4.5l8-1.5v10" />
        </Svg>
      );
    case 'lounges':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Path d="M4 12v5a1 1 0 001 1h1a1 1 0 001-1v-1h10v1a1 1 0 001 1h1a1 1 0 001-1v-5" />
          <Path d="M5 12V9a2 2 0 012-2h10a2 2 0 012 2v3" />
          <Path d="M4 12h16" />
        </Svg>
      );
    case 'breweries':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Rect x={4} y={7} width={12} height={13} rx={1.5} />
          <Path d="M16 10h2a2 2 0 012 2v3a2 2 0 01-2 2h-2" />
          <Path d="M7 4v3M10 4v3M13 4v3" />
        </Svg>
      );
    case 'live-music':
      return (
        <Svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={ICON_COLOR} strokeWidth={2}>
          <Rect x={9} y={2} width={6} height={11} rx={3} />
          <Path d="M5 11a7 7 0 0014 0M12 18v4M9 22h6" />
        </Svg>
      );
    case 'bookmarked':
      return (
        <Svg width={17} height={17} viewBox="0 0 24 24" fill={ICON_COLOR}>
          <Path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z" />
        </Svg>
      );
    default:
      return null;
  }
}

const TILES = [
  { key: 'top-places', label: 'Top Places', colors: ['#F0B429', '#B9821A'] },
  { key: 'deals', label: 'Deals', colors: ['#FF8A3D', '#B85A1E'] },
  { key: 'bars', label: 'Bars', colors: ['#E15C3F', '#8C3520'] },
  { key: 'clubs', label: 'Clubs', colors: ['#D63E8F', '#7A2A5C'] },
  { key: 'lounges', label: 'Lounges', colors: ['#8B5CF6', '#4E3494'] },
  { key: 'breweries', label: 'Breweries', colors: ['#2FA37A', '#1B6349'] },
  { key: 'live-music', label: 'Live Music', colors: ['#3E8EDE', '#245685'] },
  { key: 'bookmarked', label: 'Bookmarked', colors: ['#6B7280', '#3A4048'] },
];

// Only "Bookmarked" has a real destination right now (SavedScreen.js, added
// alongside the bookmark button on Venue/Event Detail). The rest stay
// visual only, same as before — no ranked-list/deals-list/category-filtered
// screens exist yet.
const NAV_TARGETS = {
  bookmarked: 'Saved',
};

function Tile({ tile, onPress }) {
  const content = (
    <>
      <TileIcon name={tile.key} />
      <Text style={styles.tileText}>{tile.label}</Text>
    </>
  );

  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [pressed && styles.tilePressed]}>
        <LinearGradient colors={tile.colors} start={{ x: 0.15, y: 0 }} end={{ x: 0.85, y: 1 }} style={styles.tile}>
          {content}
        </LinearGradient>
      </Pressable>
    );
  }

  return (
    <LinearGradient colors={tile.colors} start={{ x: 0.15, y: 0 }} end={{ x: 0.85, y: 1 }} style={styles.tile}>
      {content}
    </LinearGradient>
  );
}

export default function BrowseRow() {
  const navigation = useNavigation();

  return (
    <View style={styles.section}>
      <Text style={styles.label}>Browse</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        {TILES.map((tile) => {
          const target = NAV_TARGETS[tile.key];
          return (
            <Tile key={tile.key} tile={tile} onPress={target ? () => navigation.navigate(target) : undefined} />
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: spacing.xxl,
  },
  // 16px per CLAUDE.md's "Section labels: 16px, Inter 600, uppercase" spec.
  label: {
    fontFamily: fonts.bodySemiBold,
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    opacity: 0.85,
    marginBottom: 10,
  },
  // Back to a single scrolling row within Home's normal 16px content
  // gutter — same pattern as SearchScreen.js's category pill row.
  row: {
    gap: 10,
    paddingVertical: 4,
  },
  tile: {
    width: 108,
    height: 80,
    borderRadius: 18,
    padding: 12,
    justifyContent: 'space-between',
  },
  tilePressed: {
    opacity: 0.8,
  },
  tileText: {
    fontFamily: fonts.displaySemiBold,
    fontSize: 12.5,
    color: '#fff',
  },
});
