// useDetailReveal.js
//
// Shared entrance-animation driver for Venue Detail and Event Detail — per
// CLAUDE.md's new "Venue/Event Detail — Transition & Structure Rules"
// section. Both screens are built from the same content blocks in the same
// order (Name -> Rating -> Description+Atmosphere -> Location -> Reviews ->
// "I'm Going" button), so this hook is the one place that owns the timing —
// screen-specific JSX just asks "what should block N look like right now."
//
// Two things happen on mount:
//   1. The hero photo "lands" — it starts slightly inset (small side/top
//      margin, rounded corners) and animates open to near edge-to-edge over
//      HERO_MS. This stands in for the mockup's cross-screen "photo enlarges
//      to fill the screen" shared-element transition without actually
//      needing one: rather than measuring the tapped card's on-screen
//      position and animating a copy of the photo across two different
//      screens (which would need either react-native-reanimated's shared
//      transitions or a dedicated shared-element library — a new dependency
//      this round deliberately avoids, see CLAUDE_2.md's "confirm before
//      installing" note), the photo simply starts small-and-inset the
//      instant this screen mounts and grows into place. Visually reads as
///     "the photo just enlarged," without any cross-screen measurement.
//   2. Once the hero settles, each content block fades in top-to-bottom in
//      sequence (staggered by BLOCK_STAGGER_MS), matching the doc's named
//      order.
//
// Same manual requestAnimationFrame + plain React state approach as the
// rest of the app's animation (SwipeableTabs.js, VenueActionBar.js,
// AnimatedGradientBackground.js) — RN's `Animated` API is confirmed broken
// in this exact Expo SDK 54 setup, so nothing here reaches for it.
import { useEffect, useRef, useState } from 'react';

const HERO_MS = 380;
const BLOCK_MS = 260;
const BLOCK_STAGGER_MS = 90;
const HERO_INSET_MARGIN = 14; // px side margin the photo starts with, closing to 0 (edge-to-edge) as it "lands"
const HERO_INSET_RADIUS = 22; // corner radius the photo starts with, closing to 0 to match

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

// blockCount: how many staggered content blocks follow the hero.
// skipHero: Home's Featured-card exception is the one place in the app that
// should NOT get the photo-enlarge treatment — passing this renders the
// hero fully "landed" immediately and starts the block stagger right away.
export function useDetailReveal(blockCount, { skipHero = false } = {}) {
  const [elapsed, setElapsed] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(null);

  useEffect(() => {
    startRef.current = null;
    const totalMs = (skipHero ? 0 : HERO_MS) + BLOCK_STAGGER_MS * Math.max(0, blockCount - 1) + BLOCK_MS;

    const step = (ts) => {
      if (startRef.current == null) startRef.current = ts;
      const t = ts - startRef.current;
      setElapsed(t);
      if (t < totalMs) {
        rafRef.current = requestAnimationFrame(step);
      }
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // blockCount/skipHero are fixed for the lifetime of a given screen
    // instance in practice (they describe the screen's own layout), so this
    // intentionally only reruns if a screen legitimately changes shape.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blockCount, skipHero]);

  const heroT = skipHero ? 1 : easeOutCubic(Math.min(1, elapsed / HERO_MS));
  const heroStyle = {
    marginHorizontal: HERO_INSET_MARGIN * (1 - heroT),
    marginTop: (HERO_INSET_MARGIN * 0.6) * (1 - heroT),
    borderRadius: HERO_INSET_RADIUS * (1 - heroT),
  };

  const getBlockStyle = (index) => {
    const delay = (skipHero ? 0 : HERO_MS) + index * BLOCK_STAGGER_MS;
    const localT = easeOutCubic(Math.min(1, Math.max(0, (elapsed - delay) / BLOCK_MS)));
    return {
      opacity: localT,
      transform: [{ translateY: (1 - localT) * 14 }],
    };
  };

  // Convenience for anything (like the sticky "I'm Going" bar) that needs a
  // plain yes/no rather than an interpolated style, e.g. to flip
  // pointerEvents off until it's actually visible.
  const isBlockRevealed = (index) => getBlockStyle(index).opacity >= 0.999;

  return { heroStyle, getBlockStyle, isBlockRevealed };
}
