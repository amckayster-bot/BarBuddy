// "Late City Minimal" design tokens — approved, see project CLAUDE.md.
export const colors = {
  navyBase: '#0C0F16',
  navySurface: '#171B24',
  amber: '#E3A857',
  textPrimary: '#F5F3EF',
  textMuted: '#8A8F9C',
  border: '#2A2F3A',

  // Muted nebula background (background only — see
  // AnimatedGradientBackground.js) — dusty rose / muted purple / muted warm
  // brown blooms over a near-black base, per CLAUDE.md's locked "Design
  // System" spec. This supersedes the earlier, more vividly-colored Aurora
  // version (which used a brighter red/orange accent pair) — kept the same
  // token names where a direct successor exists (nebulaOrange -> the new
  // muted brown) so call sites elsewhere in the app didn't need touching.
  // Deliberately distinct hues from `amber`: amber stays reserved for
  // functional "happening now" signals and must never appear decoratively.
  nebulaRose: '#7A3350',
  nebulaPurple: '#4A1F5C',
  nebulaOrange: '#8C503C', // muted warm brown — see note above
  nebulaBaseTop: '#0e0810',
  nebulaBaseBottom: '#170a14',

  // Rating badge scale (Top Ten list) — a different functional signal from
  // amber, so it gets its own tokens rather than borrowing amber's hex.
  ratingRed: '#E5484D',
  ratingOrange: '#FF8A3D',
  ratingYellow: '#F0B429',
  ratingGreen: '#4CD37A',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 30,
};
