import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import SwipeableTabs from './SwipeableTabs';
import VenueDetailScreen from '../screens/VenueDetailScreen';
import EventDetailScreen from '../screens/EventDetailScreen';
import SavedScreen from '../screens/SavedScreen';
import MapScreen from '../screens/MapScreen';
import { SearchFilterProvider } from '../context/SearchFilterContext';
import { SavedProvider } from '../context/SavedContext';

const Stack = createNativeStackNavigator();

// The 5 main tabs (Home/Search/ForYou/Events/Profile) used to be a real
// `@react-navigation/bottom-tabs` navigator. That's been replaced with
// SwipeableTabs — a custom pager supporting velocity-following swipe
// left/right between tabs, which bottom-tabs has no built-in support for
// (see SwipeableTabs.js for the full reasoning/tradeoffs). It's still
// mounted as a single Stack.Screen here, so VenueDetail/EventDetail/Saved/
// Map pushing over it and covering the tab bar works exactly as before.
//
// VenueDetail/EventDetail/Saved are root-level stack screens (not nested in
// the tabs) so they cover the tab bar entirely when pushed — matches the
// mockup, which has its own sticky action bar (VenueDetail/EventDetail) or
// its own back button (Saved) as the bottom/top UI instead.
export default function RootNavigator() {
  return (
    <SafeAreaProvider>
      {/* Wraps everything (not just the tabs) so any future screen — not
          only Home and Search — can read/drive the same category filters
          without re-plumbing this later. SavedProvider sits alongside it
          for the same reason: the bookmark button lives on Venue/Event
          Detail, but the Saved list it feeds lives under Home's Browse
          row — both need the same in-memory saved-ids state. */}
      <SearchFilterProvider>
        <SavedProvider>
          <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
              <Stack.Screen name="MainTabs" component={SwipeableTabs} />
              <Stack.Screen name="VenueDetail" component={VenueDetailScreen} />
              <Stack.Screen name="EventDetail" component={EventDetailScreen} />
              <Stack.Screen name="Saved" component={SavedScreen} />
              <Stack.Screen name="Map" component={MapScreen} />
            </Stack.Navigator>
          </NavigationContainer>
        </SavedProvider>
      </SearchFilterProvider>
    </SafeAreaProvider>
  );
}
