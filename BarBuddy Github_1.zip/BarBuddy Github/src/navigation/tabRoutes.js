// tabRoutes.js
//
// Single source of truth for the 5 main tabs — shared by SwipeableTabs (the
// custom swipe pager that renders them) and BottomNav (the tab bar), so
// their order/names/icons/labels can never drift apart from each other.
import HomeScreen from '../screens/HomeScreen';
import SearchScreen from '../screens/SearchScreen';
import ForYouScreen from '../screens/ForYouScreen';
import EventsScreen from '../screens/EventsScreen';
import ProfileScreen from '../screens/ProfileScreen';

// "Assistant" renamed to "Profile" per CLAUDE.md — the AI itinerary planner
// this tab used to point at is unaffected, it just lives under "For You"
// instead (ForYouScreen.js). ProfileScreen.js is a genuinely new
// account/settings screen, not the old AssistantScreen relabeled — that
// file is now unused (see AssistantScreen.js's own note).
export const TAB_ROUTES = [
  { name: 'Home', component: HomeScreen, iconName: 'home', label: 'Home' },
  { name: 'Search', component: SearchScreen, iconName: 'search', label: 'Search' },
  { name: 'ForYou', component: ForYouScreen, iconName: 'foryou', label: 'For You' },
  { name: 'Events', component: EventsScreen, iconName: 'events', label: 'Events' },
  { name: 'Profile', component: ProfileScreen, iconName: 'profile', label: 'Profile' },
];
