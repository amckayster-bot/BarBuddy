// SwipeableTabs.js
//
// Custom swipeable page container for the 5 main tabs — replaces
// React Navigation's bottom-tabs navigator, which switches tabs with an
// instant cut and has no built-in swipe gesture.
//
// Gesture engine note (rebuilt this round): this used to be driven entirely
// by RN core's PanResponder, with a manual dx/dy-ratio check standing in for
// "is this drag meant for the page-swipe or for something nested inside a
// tab." That worked in the simulator but was still letting page-swipes win
// over Near You's/Deals' own horizontal scrolling on a real iOS device, and
// felt choppy — PanResponder's gesture recognition is a pure-JS system that
// has to round-trip every touch event over the bridge before it can decide
// who "wins" a gesture, which is a real ceiling on top of whatever
// contributes to jank elsewhere.
//
// This is now built on react-native-gesture-handler's Gesture API instead:
// Gesture.Pan() here, and the two inner horizontal carousels (Near You,
// Deals) now render gesture-handler's own <ScrollView> rather than RN's —
// putting both sides of every nested-scroll conflict inside the same
// native-level gesture-recognition system, instead of RN's ScrollView (its
// own separate native recognizer) fighting a plain JS responder. The
// translateX that actually drives the visual position is still plain React
// state updated via requestAnimationFrame for the settle animation — same
// proven pattern as the rest of this app (see AnimatedGradientBackground.js's
// animation-driver note; RN's `Animated` API is confirmed broken in this
// exact Expo SDK setup) — react-native-reanimated was deliberately left out
// of this round to avoid its babel-plugin/New Architecture requirements on
// top of an already-large change; if it's still not smooth enough after
// this, that's the natural next step.
//
// Setup this needs on the device (not done automatically by this file):
//   1. `npx expo install react-native-gesture-handler` (updates
//      package.json/lock to the exact version this Expo SDK expects — don't
//      hand-edit the version, that command picks it).
//   2. `import 'react-native-gesture-handler'` as the very first line of
//      index.js (already added).
//   3. The app root wrapped in <GestureHandlerRootView> (already added, in
//      App.js).
//
// All 5 tab screens are rendered side by side in one wide row and slid via
// a single `transform: translateX` — dragging follows the finger 1:1, and
// on release the page settles to whichever tab the drag/velocity implies,
// with the settle *speed* scaled to how fast the release was (a hard flick
// snaps quickly; a slow drag-and-release settles at a normal pace) — that's
// the "follows the speed and velocity of the user" ask. Since all 5 stay
// mounted simultaneously (needed so the adjacent page is actually there to
// slide into view), each one keeps its own state across tab switches, same
// as React Navigation's default tab behavior.
//
// Nested-horizontal-scroll note: on top of switching the carousels to
// gesture-handler's ScrollView, each one still flags "a touch is down on
// me" via TabPagerContext's setInnerScrollActive (onTouchStart/onTouchEnd —
// fire immediately on touch, ahead of any drag threshold), which flips this
// Pan gesture's `.enabled()` off for the duration of that touch. Belt and
// suspenders: the gesture-handler-level fix should be the real one, this
// context flag is cheap extra insurance against the exact bug that shipped
// twice already.
//
// Perf note (kept from the previous round): all 5 tab screens stay mounted,
// each with its own animated gradient background and scroll content.
// TabPage below is memoized with no props that change during a drag
// (translateX lives on the ancestor `track` View's style only), so a drag
// only re-renders the cheap outer Views, not the tab content underneath.
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { useScreenWidth } from '../theme/screenSize';
import { TabPagerContext } from '../context/TabPagerContext';
import { TAB_ROUTES } from './tabRoutes';
import BottomNav from '../components/BottomNav';

const TabPage = memo(function TabPage({ Screen }) {
  return <Screen />;
});

// How far (as a fraction of screen width) a drag has to travel before it
// counts as "far enough" to change pages on release, even without a fast
// flick.
const DISTANCE_RATIO = 0.32;
// How fast (px/ms) a release has to be moving to count as a deliberate
// flick, changing pages even on a short drag. gesture-handler reports
// velocity in px/second, so this gets compared against velocityX / 1000.
const VELOCITY_THRESHOLD = 0.35;
// Settle duration is distance / speed, clamped to this range — fast flicks
// still take a little time (feels intentional, not instant-teleport), slow
// releases still settle promptly rather than drifting forever.
const SETTLE_MIN_MS = 180;
const SETTLE_MAX_MS = 420;
// How much a drag past the first/last page resists, so hitting the edge
// feels like a soft rubber-band rather than a hard wall.
const EDGE_RESISTANCE = 0.35;
// How many horizontal px of movement it takes before the gesture "activates"
// (i.e. actually starts paging) vs. how many vertical px cause it to bow out
// entirely — evaluated natively by gesture-handler's own recognizer, not
// polled from JS, which is what makes this meaningfully more reliable than
// the old PanResponder dx/dy check at telling a page-swipe apart from a
// vertical scroll or a nested horizontal scroll.
const ACTIVE_OFFSET_X = 10;
const FAIL_OFFSET_Y = 8;

function easeOutCubic(t) {
  const c = Math.max(0, Math.min(1, t));
  return 1 - (1 - c) ** 3;
}

export default function SwipeableTabs() {
  const width = useScreenWidth();
  const count = TAB_ROUTES.length;
  const [activeIndex, setActiveIndex] = useState(0);
  const [renderX, setRenderX] = useState(0);
  // Whether any nested horizontal scroller currently has a touch down on it
  // — see the file-level nested-horizontal-scroll note. Real state (not
  // just a ref) because it needs to trigger recomputing the Gesture object
  // below via `.enabled()`.
  const [innerScrollActive, setInnerScrollActiveState] = useState(false);

  const xRef = useRef(0); // current visual translateX, source of truth for the gesture math
  const gestureStartXRef = useRef(0);
  const activeIndexRef = useRef(0); // mirrors activeIndex in a ref so gesture callbacks always read the latest value
  const animRafRef = useRef(null);

  const setInnerScrollActive = useCallback((active) => {
    setInnerScrollActiveState(active);
  }, []);

  useEffect(() => {
    activeIndexRef.current = activeIndex;
  }, [activeIndex]);

  const baseXFor = useCallback((index) => -index * width, [width]);

  const stopAnim = useCallback(() => {
    if (animRafRef.current) cancelAnimationFrame(animRafRef.current);
    animRafRef.current = null;
  }, []);

  // velocityPxPerMs comes straight from the gesture (0 for a programmatic
  // jump, e.g. a BottomNav tap) — the higher it is, the faster the settle,
  // which is what makes a hard flick feel like it's still carrying its own
  // momentum into the snap rather than every transition taking the same
  // fixed duration regardless of how the user released it.
  //
  // Stabilized with useCallback (along with goToIndex/goToName below) so
  // BottomNav — memoized in BottomNav.js — actually gets to skip re-renders
  // during a drag instead of receiving a new onIndexChange function
  // identity every frame.
  const animateTo = useCallback(
    (targetIndex, velocityPxPerMs = 0) => {
      stopAnim();
      const from = xRef.current;
      const to = baseXFor(targetIndex);
      const distance = Math.abs(to - from);
      const speed = Math.max(0.35, Math.min(1.8, Math.abs(velocityPxPerMs) || 0.7));
      const duration = distance === 0 ? 0 : Math.max(SETTLE_MIN_MS, Math.min(SETTLE_MAX_MS, distance / speed));

      if (duration === 0) {
        xRef.current = to;
        setRenderX(to);
        setActiveIndex(targetIndex);
        return;
      }

      let startTs = null;
      const step = (ts) => {
        if (startTs == null) startTs = ts;
        const t = Math.min(1, (ts - startTs) / duration);
        const eased = easeOutCubic(t);
        const x = from + (to - from) * eased;
        xRef.current = x;
        setRenderX(x);
        if (t < 1) {
          animRafRef.current = requestAnimationFrame(step);
        } else {
          xRef.current = to;
          setRenderX(to);
          setActiveIndex(targetIndex);
        }
      };
      animRafRef.current = requestAnimationFrame(step);
    },
    [baseXFor, stopAnim]
  );

  const goToIndex = useCallback(
    (index) => {
      animateTo(Math.max(0, Math.min(count - 1, index)));
    },
    [animateTo, count]
  );

  const goToName = useCallback(
    (name) => {
      const idx = TAB_ROUTES.findIndex((r) => r.name === name);
      if (idx >= 0) goToIndex(idx);
    },
    [goToIndex]
  );

  useEffect(() => () => stopAnim(), []);

  const panGesture = useMemo(
    () =>
      Gesture.Pan()
        .activeOffsetX([-ACTIVE_OFFSET_X, ACTIVE_OFFSET_X])
        .failOffsetY([-FAIL_OFFSET_Y, FAIL_OFFSET_Y])
        .enabled(!innerScrollActive)
        .onStart(() => {
          stopAnim();
          gestureStartXRef.current = xRef.current;
        })
        .onUpdate((e) => {
          let next = gestureStartXRef.current + e.translationX;
          const max = baseXFor(0);
          const min = baseXFor(count - 1);
          if (next > max) next = max + (next - max) * EDGE_RESISTANCE;
          if (next < min) next = min + (next - min) * EDGE_RESISTANCE;
          xRef.current = next;
          setRenderX(next);
        })
        .onEnd((e) => {
          const current = activeIndexRef.current;
          const from = baseXFor(current);
          const delta = xRef.current - from; // negative = dragged toward the next tab
          const velocityPxPerMs = e.velocityX / 1000;
          const farEnough = Math.abs(delta) > width * DISTANCE_RATIO;
          const fastEnough = Math.abs(velocityPxPerMs) > VELOCITY_THRESHOLD;

          let target = current;
          if (delta < 0 && (farEnough || (fastEnough && velocityPxPerMs < 0))) {
            target = current + 1;
          } else if (delta > 0 && (farEnough || (fastEnough && velocityPxPerMs > 0))) {
            target = current - 1;
          }
          target = Math.max(0, Math.min(count - 1, target));
          animateTo(target, Math.abs(velocityPxPerMs));
        })
        .onFinalize((_e, success) => {
          // success is false when the gesture was cancelled/interrupted
          // rather than ending normally — onEnd already handled the normal
          // case, this just makes sure a cancelled drag still settles back
          // onto a real page instead of being left mid-slide.
          if (!success) animateTo(activeIndexRef.current);
        }),
    [count, width, innerScrollActive, baseXFor, stopAnim, animateTo]
  );

  const ctxValue = useMemo(
    () => ({ activeIndex, goToIndex, goToName, setInnerScrollActive }),
    [activeIndex, goToName, goToIndex, setInnerScrollActive]
  );

  return (
    <TabPagerContext.Provider value={ctxValue}>
      <View style={styles.fill}>
        <View style={styles.clip}>
          <GestureDetector gesture={panGesture}>
            <View style={[styles.track, { width: width * count, transform: [{ translateX: renderX }] }]}>
              {TAB_ROUTES.map((route) => (
                <View key={route.name} style={{ width }}>
                  <TabPage Screen={route.component} />
                </View>
              ))}
            </View>
          </GestureDetector>
        </View>
        <BottomNav activeIndex={activeIndex} onIndexChange={goToIndex} />
      </View>
    </TabPagerContext.Provider>
  );
}

const styles = StyleSheet.create({
  fill: {
    flex: 1,
  },
  clip: {
    flex: 1,
    overflow: 'hidden',
  },
  track: {
    flex: 1,
    flexDirection: 'row',
  },
});
