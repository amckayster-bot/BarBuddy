// Must be the very first import in the whole app — react-native-gesture-
// handler needs to run its own setup before anything else touches native
// event handling, especially on Android. See SwipeableTabs.js for why this
// got added (rebuilt the page pager on top of it).
import 'react-native-gesture-handler';

import { registerRootComponent } from 'expo';

import App from './App';

// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in Expo Go or in a native build,
// the environment is set up appropriately
registerRootComponent(App);
